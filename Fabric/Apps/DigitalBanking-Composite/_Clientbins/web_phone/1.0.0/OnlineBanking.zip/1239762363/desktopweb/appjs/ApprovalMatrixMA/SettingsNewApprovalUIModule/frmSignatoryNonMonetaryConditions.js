define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmSignatoryNonMonetaryConditions", function() {
    return function(controller) {
        function addWidgetsfrmSignatoryNonMonetaryConditions() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxLogoAndActionsWrapper": {
                        "width": "1366dp"
                    },
                    "flxMenuContainer": {
                        "width": "100%"
                    },
                    "flxMenuWrapper": {
                        "width": "1366dp"
                    },
                    "imgKony": {
                        "centerX": "viz.val_cleared",
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "90px",
                "id": "flxAckHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": "5dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknLabel42424224pxlight",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.Signatory.GroupDelete\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeft.add(flxImgContainer, lblSuccessMessage);
            var flxImgClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxImgClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "92%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgClose.add(imgClose);
            flxAckHeader.add(flxLeft, flxImgClose);
            var lblApprovalMatrixHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Foreign Exchange"
                },
                "id": "lblApprovalMatrixHeader",
                "isVisible": true,
                "left": "83dp",
                "skin": "sknlblUserName",
                "text": "Approval Matrix- Create New Rule - Approval Condition & Rule",
                "top": "21dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxAcknowledgementPopup = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxAcknowledgementPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementPopup.setDefaultUnit(kony.flex.DP);
            var imgAckNotification = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgAckNotification",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "bulk_billpay_success.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAckNotificationContent = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAckNotificationContent",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP24px",
                "text": "Approval Rule has been successfully created. ",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgAckClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgAckClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "100dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowledgementPopup.add(imgAckNotification, lblAckNotificationContent, imgAckClose);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContractContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80px",
                "id": "flxContractContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountName = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountName.add(lblAccountNameHeader, lblAccountNameValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.customerName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Kony India Pvt Limited-kalyani1SB",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxContractContainer.add(flxAccountName, flxCustomerName, flxCustomerID, flxContract);
            var flxApprovalConditionContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "725dp",
                "id": "flxApprovalConditionContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "55dp",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.CreateRule\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHeaderSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "0.50%",
                "id": "flxHeaderSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "48dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeperator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeperator.add();
            flxHeaderContainer.add(lblCustomerLevelHeader, lblHeaderSeparator, flxHeaderSeperator);
            var flxApprovalConditionDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "55dp",
                "id": "flxApprovalConditionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionDetails.setDefaultUnit(kony.flex.DP);
            var flxFeatureActionRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "25%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxFeatureActionRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatureActionRow1.setDefaultUnit(kony.flex.DP);
            var lblFeatureAction = new kony.ui.Label({
                "id": "lblFeatureAction",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.FeatureAction\")",
                "top": "0dp",
                "width": "23%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFeatureActionValue = new kony.ui.Label({
                "id": "lblFeatureActionValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Cheque Management - Create Check Book request",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeatureActionRow1.add(lblFeatureAction, lblFeatureActionValue);
            var FlxActionLevelRow = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "FlxActionLevelRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlxActionLevelRow.setDefaultUnit(kony.flex.DP);
            var lblActionLevel = new kony.ui.Label({
                "height": "17dp",
                "id": "lblActionLevel",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.actionLevel\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblActionLevelValue = new kony.ui.Label({
                "height": "17dp",
                "id": "lblActionLevelValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Account",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxActionLevelRow.add(lblActionLevel, lblActionLevelValue);
            flxApprovalConditionDetails.add(flxFeatureActionRow1, FlxActionLevelRow);
            var flxEnableApproval = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxEnableApproval",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnableApproval.setDefaultUnit(kony.flex.DP);
            var flxFeatureActionApprovalHdr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxFeatureActionApprovalHdr",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknbgF9F9F9topbottomBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatureActionApprovalHdr.setDefaultUnit(kony.flex.DP);
            var lblApprovalRequiredHdr = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblApprovalRequiredHdr",
                "isVisible": true,
                "left": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalRequired\")",
                "top": "0dp",
                "width": "230dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalConditionHdr = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblApprovalConditionHdr",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalcondition\")",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalConditionAction = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblApprovalConditionAction",
                "isVisible": false,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.Approvals.Action\")",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeatureActionApprovalHdr.add(lblApprovalRequiredHdr, lblApprovalConditionHdr, lblApprovalConditionAction);
            var flxFeatureActionApprovalValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxFeatureActionApprovalValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatureActionApprovalValues.setDefaultUnit(kony.flex.DP);
            var imgEnableCondition = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgEnableCondition",
                "isVisible": true,
                "left": "30dp",
                "skin": "slImage",
                "src": "inactive.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalCondition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxApprovalCondition",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "220dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "250dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalCondition.setDefaultUnit(kony.flex.DP);
            var lblViewEditCondition = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblViewEditCondition",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "N/A",
                "top": "0dp",
                "width": "220dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddCondition = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtn4176a4NoBorder",
                "id": "btnAddCondition",
                "isVisible": false,
                "left": "0dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.AddCondition\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalCondition.add(lblViewEditCondition, btnAddCondition);
            var imgDeleteAction = new kony.ui.Image2({
                "height": "25dp",
                "id": "imgDeleteAction",
                "isVisible": false,
                "left": "60dp",
                "skin": "slImage",
                "src": "delete.png",
                "top": "13dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeatureActionApprovalValues.add(imgEnableCondition, flxApprovalCondition, imgDeleteAction);
            flxEnableApproval.add(flxFeatureActionApprovalHdr, flxFeatureActionApprovalValues);
            var lblSepDetails = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSepDetails",
                "isVisible": true,
                "left": "0",
                "skin": "sknSeparatore3e3e3",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxViewEditHeade = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "55dp",
                "id": "flxViewEditHeade",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEditHeade.setDefaultUnit(kony.flex.DP);
            var lblViewEditHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblViewEditHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.ViewEditApprovalCondition\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxViewEditHdrSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "0.50%",
                "id": "flxViewEditHdrSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "48dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEditHdrSeperator.setDefaultUnit(kony.flex.DP);
            flxViewEditHdrSeperator.add();
            flxViewEditHeade.add(lblViewEditHeader, flxViewEditHdrSeperator);
            var flxApprovalDetailsContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "350dp",
                "id": "flxApprovalDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "21dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxConditionSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionSection",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "132dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "69dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionSection.setDefaultUnit(kony.flex.DP);
            var flxConditionHdr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxConditionHdr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxE9E9E9Bdr1PxRds5Px",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionHdr.setDefaultUnit(kony.flex.DP);
            var lblConditoinHdr = new kony.ui.Label({
                "id": "lblConditoinHdr",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Condition 1",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDeleteCondition = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "id": "btnDeleteCondition",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "text": "Button",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionHdr.add(lblConditoinHdr, btnDeleteCondition);
            var flxCreateApprovalCondition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateApprovalCondition",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxffffffnoborder",
                "top": "0",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknsegf7f7f7hover"
            });
            flxCreateApprovalCondition.setDefaultUnit(kony.flex.DP);
            var flxApprovalConditionValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalConditionValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionValue.setDefaultUnit(kony.flex.DP);
            var flxConditionInputs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "160dp",
                "id": "flxConditionInputs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 20,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionInputs.setDefaultUnit(kony.flex.DP);
            var flxRequiredApprovals = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxRequiredApprovals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "200dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequiredApprovals.setDefaultUnit(kony.flex.DP);
            var lblRequiredApprovalsHdr = new kony.ui.Label({
                "id": "lblRequiredApprovalsHdr",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "text": "Required Approvals",
                "top": "20dp",
                "width": "125dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRequiredAppraovalSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxRequiredAppraovalSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "190dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequiredAppraovalSelected.setDefaultUnit(kony.flex.DP);
            var lblRequiredApprovalsCount = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRequiredApprovalsCount",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "4",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRequiredApprovalsDrop = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgRequiredApprovalsDrop",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "listboxuparrow.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRequiredAppraovalSelected.add(lblRequiredApprovalsCount, imgRequiredApprovalsDrop);
            var flxApprovalsDropDown = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "220dp",
                "horizontalScrollIndicator": true,
                "id": "flxApprovalsDropDown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "5dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsDropDown.setDefaultUnit(kony.flex.DP);
            var lblApprovalCount = new kony.ui.Label({
                "id": "lblApprovalCount",
                "isVisible": true,
                "left": "11dp",
                "skin": "slLabel",
                "text": "Label",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalsDropDown.add(lblApprovalCount);
            flxRequiredApprovals.add(lblRequiredApprovalsHdr, flxRequiredAppraovalSelected, flxApprovalsDropDown);
            var flxFromGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxFromGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "320dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "200dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromGroup.setDefaultUnit(kony.flex.DP);
            var lblFromGroupHdr = new kony.ui.Label({
                "id": "lblFromGroupHdr",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "text": "From Group",
                "top": "20dp",
                "width": "125dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFromGroupSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFromGroupSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "200dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromGroupSelected.setDefaultUnit(kony.flex.DP);
            var lblFromGroupSelectedVal = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFromGroupSelectedVal",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Sr. Admin (4)",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFromGroupDrop = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgFromGroupDrop",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "listboxuparrow.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromGroupSelected.add(lblFromGroupSelectedVal, imgFromGroupDrop);
            var flxFromGroupDropDown = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "220dp",
                "horizontalScrollIndicator": true,
                "id": "flxFromGroupDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "81dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFromGroupDropDown.setDefaultUnit(kony.flex.DP);
            var lblFromGroupValue = new kony.ui.Label({
                "id": "lblFromGroupValue",
                "isVisible": true,
                "left": "28dp",
                "skin": "slLabel",
                "text": "Label",
                "top": "27dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromGroupDropDown.add(lblFromGroupValue);
            flxFromGroup.add(lblFromGroupHdr, flxFromGroupSelected, flxFromGroupDropDown);
            var btnDeleteAndCondition = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "id": "btnDeleteAndCondition",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "text": "Delete",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalWarningMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxApprovalWarningMsg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "100dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalWarningMsg.setDefaultUnit(kony.flex.DP);
            var imgWarningIcon = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgWarningIcon",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info.png",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalWarningMsg = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblApprovalWarningMsg",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "This signatory group does not have sufficient approvers",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalWarningMsg.add(imgWarningIcon, lblApprovalWarningMsg);
            flxConditionInputs.add(flxRequiredApprovals, flxFromGroup, btnDeleteAndCondition, flxApprovalWarningMsg);
            flxApprovalConditionValue.add(flxConditionInputs);
            var flxANDText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxANDText",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDText.setDefaultUnit(kony.flex.DP);
            var flxAndVerticalLineTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxAndVerticalLineTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAndVerticalLineTop.setDefaultUnit(kony.flex.DP);
            flxAndVerticalLineTop.add();
            var flxANDLabelContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxANDLabelContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlx424242Rds5pxBdr1px",
                "top": "0dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDLabelContainer.setDefaultUnit(kony.flex.DP);
            var lblANDText = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblANDText",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AND",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxANDLabelContainer.add(lblANDText);
            var flxAndVerticalLineBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxAndVerticalLineBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAndVerticalLineBottom.setDefaultUnit(kony.flex.DP);
            flxAndVerticalLineBottom.add();
            flxANDText.add(flxAndVerticalLineTop, flxANDLabelContainer, flxAndVerticalLineBottom);
            flxCreateApprovalCondition.add(flxApprovalConditionValue, flxANDText);
            var flxANDConditionBtnMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "35dp",
                "id": "flxANDConditionBtnMain",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDConditionBtnMain.setDefaultUnit(kony.flex.DP);
            var flxANDBtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxANDBtn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlx003C7DBdr1PxRds5px",
                "top": "0dp",
                "width": "80dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxANDBtn.setDefaultUnit(kony.flex.DP);
            var lblPlusSymbol = new kony.ui.Label({
                "height": "100%",
                "id": "lblPlusSymbol",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl003D79Rds5PxSSPFFFFF26Px",
                "text": "+",
                "top": "0dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAND = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAND",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknLbl29327615px",
                "text": "AND",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxANDBtn.add(lblPlusSymbol, lblAND);
            flxANDConditionBtnMain.add(flxANDBtn);
            flxConditionSection.add(flxConditionHdr, flxCreateApprovalCondition, flxANDConditionBtnMain);
            var flxORText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxORText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORText.setDefaultUnit(kony.flex.DP);
            var flxORVerticalLineTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxORVerticalLineTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORVerticalLineTop.setDefaultUnit(kony.flex.DP);
            flxORVerticalLineTop.add();
            var flxORLabelContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxORLabelContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlx424242Rds5pxBdr1px",
                "top": "0dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORLabelContainer.setDefaultUnit(kony.flex.DP);
            var lblORTest = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblORTest",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "OR",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxORLabelContainer.add(lblORTest);
            var flxORVerticalLineBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxORVerticalLineBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxe3e3e3Border1Px",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxORVerticalLineBottom.setDefaultUnit(kony.flex.DP);
            flxORVerticalLineBottom.add();
            flxORText.add(flxORVerticalLineTop, flxORLabelContainer, flxORVerticalLineBottom);
            var flxConditionPartMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionPartMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionPartMain.setDefaultUnit(kony.flex.DP);
            flxConditionPartMain.add();
            var btnAddNewCondition = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "40dp",
                "id": "btnAddNewCondition",
                "isVisible": false,
                "left": "20dp",
                "skin": "ICSknBtnSSPRegular003E7515Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.AddORCondition\")",
                "top": "25dp",
                "width": "200dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsContainer.add(flxConditionSection, flxORText, flxConditionPartMain, btnAddNewCondition);
            var flxBackContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "130dp",
                "id": "flxBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainer.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparator",
                "isVisible": true,
                "left": "20dp",
                "right": "20dp",
                "skin": "sknSeparatore3e3e3",
                "top": "5dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "240dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnConfirmSave = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "40dp",
                "id": "btnConfirmSave",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknContinueEnabled",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.save\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDeleteRule = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnDeleteRule",
                "isVisible": true,
                "right": "460dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.headerDeleteRule\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainer.add(lblBottomSeparator, btnCancel, btnConfirmSave, btnDeleteRule);
            flxApprovalConditionContainer.add(flxHeaderContainer, flxApprovalConditionDetails, flxEnableApproval, lblSepDetails, flxViewEditHeade, flxApprovalDetailsContainer, flxBackContainer);
            var flxSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "1200dp",
                "id": "flxSignatoryGroups",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainerSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderContainerSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeaderrSignatoryGroups = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeaderrSignatoryGroups",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.viewManage\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparatorrSignatoryGroups = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparatorrSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCreateNewGroup = new kony.ui.Button({
                "centerY": "50%",
                "height": "30dp",
                "id": "btnCreateNewGroup",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignaotryGoup.CreateNewGroup\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.add(lblCustomerLevelHeaderrSignatoryGroups, lblHeaderSeparatorrSignatoryGroups, btnCreateNewGroup);
            var flxSearchContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSearchContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchContainer.setDefaultUnit(kony.flex.DP);
            var flxBoxSearchSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBoxSearchSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "width": "95%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearchSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxSearchimgSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchimgSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15px",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "width": "17px",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var imgSearchSignatoryGroups = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgSearchSignatoryGroups",
                "isVisible": true,
                "skin": "slImage",
                "src": "search.png",
                "width": "40dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.add(imgSearchSignatoryGroups);
            var tbxSearchSignatoryGroups = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxa0a0a0Ssp15px",
                "height": "100%",
                "id": "tbxSearchSignatoryGroups",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "42px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.SearchPlaceHolder\")",
                "right": "40px",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxItalic",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "bbSknTbx949494SSP15pxItalic"
            });
            flxBoxSearchSignatoryGroups.add(flxSearchimgSignatoryGroups, tbxSearchSignatoryGroups);
            flxSearchContainer.add(flxBoxSearchSignatoryGroups);
            var flxSegSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSegSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "145dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var segSignatoryGroups = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }]
                    ],
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "minHeight": "250dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnAction": "btnAction",
                    "flxApprovalMatrixContractHeader": "flxApprovalMatrixContractHeader",
                    "flxApprovalMatrixContractRow": "flxApprovalMatrixContractRow",
                    "flxContract": "flxContract",
                    "flxCustomerName": "flxCustomerName",
                    "flxHeadersContainer": "flxHeadersContainer",
                    "flxNoRecords": "flxNoRecords",
                    "imgContractSort": "imgContractSort",
                    "imgCustomerNameSort": "imgCustomerNameSort",
                    "lblActionHeader": "lblActionHeader",
                    "lblBottomSepartor": "lblBottomSepartor",
                    "lblContract": "lblContract",
                    "lblContractHeader": "lblContractHeader",
                    "lblCustomerID": "lblCustomerID",
                    "lblCustomerIDHeader": "lblCustomerIDHeader",
                    "lblCustomerName": "lblCustomerName",
                    "lblCustomerNameHeader": "lblCustomerNameHeader",
                    "lblNoRecords": "lblNoRecords",
                    "lblRowSeparator": "lblRowSeparator",
                    "lblTopSeparator": "lblTopSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.add(segSignatoryGroups);
            var flxBackContainerSignatoryGruops = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainerSignatoryGruops",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparatorSignatoryGruops = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparatorSignatoryGruops",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBackSignatoryGruops = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBackSignatoryGruops",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.add(lblBottomSeparatorSignatoryGruops, btnBackSignatoryGruops);
            flxSignatoryGroups.add(flxHeaderContainerSignatoryGroups, flxSearchContainer, flxSegSignatoryGroups, flxBackContainerSignatoryGruops);
            flxContent.add(flxAckHeader, lblApprovalMatrixHeader, flxAcknowledgementPopup, flxDowntimeWarning, flxContractContainer, flxApprovalConditionContainer, flxSignatoryGroups);
            flxMain.add(flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "103%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "viz.val_cleared",
                        "left": "6dp",
                        "width": "103%"
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "11dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            var flxDeletePopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDeletePopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopup.setDefaultUnit(kony.flex.DP);
            var deletepopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "deletepopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": false
                    },
                    "flxBody": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxDropdown": {
                        "isVisible": false
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "width": "65%"
                    },
                    "flxPopupNew": {
                        "top": "0dp"
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    },
                    "formActionsNew.btnCancel": {
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "text": "No",
                        "top": "viz.val_cleared",
                        "width": "20%"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "left": "viz.val_cleared",
                        "right": "3%",
                        "text": "Next",
                        "top": "viz.val_cleared",
                        "width": "20%"
                    },
                    "formActionsNew.flxMain": {
                        "top": "0dp"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblHeader": {
                        "left": "30dp",
                        "text": "Popup Header"
                    },
                    "lblPopupMsg": {
                        "text": "Popup Message"
                    },
                    "trComments": {
                        "isVisible": true,
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDeletePopup.add(deletepopup);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var cancelpopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "cancelpopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": false
                    },
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "flxPopupNew": {
                        "isVisible": true
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    },
                    "formActionsNew.btnCancel": {
                        "right": "20dp",
                        "text": "No",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "text": "Yes",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblActionLevelLabel": {
                        "isVisible": false
                    },
                    "lblActionLevelValue": {
                        "isVisible": false
                    },
                    "lblHeader": {
                        "left": "30dp",
                        "text": "Cancel"
                    },
                    "lblPopupMsg": {
                        "text": "Changes you made may not be saved,  do you want to discard the changes?",
                        "width": "80%"
                    },
                    "trComments": {
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(cancelpopup);
            var flxConfirmPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxConfirmPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmPopup.setDefaultUnit(kony.flex.DP);
            var confirmpopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "confirmpopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": true
                    },
                    "flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxCommentsWrapper": {
                        "minHeight": "30dp"
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "formActionsNew": {
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnCancel": {
                        "right": "20dp",
                        "text": "No",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "text": "Save",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblCommnets": {
                        "text": "Comments"
                    },
                    "lblHeader": {
                        "left": "30dp",
                        "text": "Create Rule"
                    },
                    "lblPopupMsg": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "text": "The changes will apply to all accounts of the customer, do you want to save?",
                        "top": "22dp",
                        "width": "70%"
                    },
                    "trComments": {
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxConfirmPopup.add(confirmpopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxAcknowledgementPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgAckClose": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "centerY": {
                            "type": "string",
                            "value": "70%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameHeader": {
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "centerY": {
                            "type": "string",
                            "value": "70%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalConditionContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerLevelHeader": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalConditionDetails": {
                        "segmentProps": []
                    },
                    "lblFeatureAction": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureActionValue": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "FlxActionLevelRow": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100.00%"
                        },
                        "segmentProps": []
                    },
                    "lblActionLevel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.approvals.actionLevel",
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblActionLevelValue": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxViewEditHeade": {
                        "segmentProps": []
                    },
                    "flxApprovalDetailsContainer": {
                        "segmentProps": []
                    },
                    "flxConditionSection": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "115%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "text": "Delete",
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "text": "Delete Condition",
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "text": "Are you sure, you want to delete this condition?",
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "65.10%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmPopup": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "65.10%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "width": {
                            "type": "string",
                            "value": "26%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNameValue": {
                        "width": {
                            "type": "string",
                            "value": "73%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "width": {
                            "type": "string",
                            "value": "29%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCustomerHeaderValue": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIDValue": {
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "lblContractValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalConditionContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerLevelHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderSeparator": {
                        "segmentProps": []
                    },
                    "flxApprovalConditionDetails": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeatureActionRow1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureAction": {
                        "width": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": []
                    },
                    "FlxActionLevelRow": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblActionLevel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalRequiredHdr": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblViewEditCondition": {
                        "text": "N/A",
                        "segmentProps": []
                    },
                    "imgDeleteAction": {
                        "isVisible": false,
                        "src": "bin.png",
                        "segmentProps": []
                    },
                    "flxApprovalDetailsContainer": {
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "-37dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "104%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "deletepopup.flxActionLevel": {
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "text": "Delete",
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "text": "Delete Condition",
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "text": "Are you sure, you want to delete this condition?",
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxActionLevel": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblActionLevelLabel": {
                        "segmentProps": []
                    },
                    "cancelpopup.lblActionLevelValue": {
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxActionLevel": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "This is an Account level Feature Action. The changes made will apply to only this account associated with the customer .",
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNameValue": {
                        "width": {
                            "type": "string",
                            "value": "73%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerHeaderValue": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIDValue": {
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "lblContractValue": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalConditionContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderContainer": {
                        "segmentProps": []
                    },
                    "flxApprovalConditionDetails": {
                        "segmentProps": []
                    },
                    "flxFeatureActionRow1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureAction": {
                        "width": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": []
                    },
                    "lblFeatureActionValue": {
                        "segmentProps": []
                    },
                    "FlxActionLevelRow": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblActionLevel": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21%"
                        },
                        "segmentProps": []
                    },
                    "lblActionLevelValue": {
                        "segmentProps": []
                    },
                    "flxEnableApproval": {
                        "segmentProps": []
                    },
                    "flxFeatureActionApprovalHdr": {
                        "segmentProps": []
                    },
                    "lblApprovalRequiredHdr": {
                        "segmentProps": []
                    },
                    "lblApprovalConditionHdr": {
                        "segmentProps": []
                    },
                    "lblApprovalConditionAction": {
                        "segmentProps": []
                    },
                    "flxFeatureActionApprovalValues": {
                        "segmentProps": []
                    },
                    "lblViewEditCondition": {
                        "segmentProps": []
                    },
                    "imgDeleteAction": {
                        "isVisible": false,
                        "src": "bin.png",
                        "segmentProps": []
                    },
                    "flxViewEditHeade": {
                        "segmentProps": []
                    },
                    "lblViewEditHeader": {
                        "segmentProps": []
                    },
                    "flxApprovalDetailsContainer": {
                        "segmentProps": []
                    },
                    "flxConditionSection": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skne3e3e3br3pxradius",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConditionHdr": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxCreateApprovalCondition": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxApprovalConditionValue": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "imgRequiredApprovalsDrop": {
                        "src": "listboxuparrow.png",
                        "segmentProps": []
                    },
                    "flxApprovalsDropDown": {
                        "accessibilityConfig": {},
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknFlx464545Rds3Px",
                        "width": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "zIndex": 1022,
                        "segmentProps": []
                    },
                    "lblApprovalCount": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [6, 0, 0, 0],
                        "skin": "bbSknLbl72727217pxSSP",
                        "text": "4",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "hoverSkin": "ICSknLblF7F7F7SSP17Px",
                        "segmentProps": []
                    },
                    "flxFromGroupDropDown": {
                        "accessibilityConfig": {},
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknFlx464545Rds3Px",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "zIndex": 1022,
                        "segmentProps": []
                    },
                    "lblFromGroupValue": {
                        "accessibilityConfig": {},
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [6, 0, 0, 0],
                        "skin": "bbSknLbl72727217pxSSP",
                        "text": "Manager (4)",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "hoverSkin": "ICSknLblF7F7F7SSP17Px",
                        "segmentProps": []
                    },
                    "btnDeleteAndCondition": {
                        "zIndex": 101,
                        "segmentProps": []
                    },
                    "flxApprovalWarningMsg": {
                        "isVisible": false,
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblApprovalWarningMsg": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxANDText": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxANDConditionBtnMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxORText": {
                        "segmentProps": []
                    },
                    "flxSignatoryGroups": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopup": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "deletepopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "deletepopup.flxDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletepopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "deletepopup.formActionsNew.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "text": "Delete",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "deletepopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Delete Condition",
                        "segmentProps": []
                    },
                    "deletepopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Are you sure, you want to delete this condition?",
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "deletepopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "cancelpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup": {
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.formActionsNew.btnNext": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "cancelpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.flxLogoAndActionsWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.flxMenuContainer": {
                    "width": "100%"
                },
                "customheadernew.flxMenuWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.imgKony": {
                    "centerX": "",
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooternew": {
                    "centerX": "",
                    "left": "6dp",
                    "width": "103%"
                },
                "customfooternew.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "11dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                },
                "deletepopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "deletepopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "deletepopup.flxPopupContainer": {
                    "left": "",
                    "right": "",
                    "width": "65%"
                },
                "deletepopup": {
                    "top": "0dp"
                },
                "deletepopup.formActionsNew": {
                    "top": "0dp"
                },
                "deletepopup.formActionsNew.btnCancel": {
                    "left": "",
                    "right": "20dp",
                    "text": "No",
                    "top": "",
                    "width": "20%"
                },
                "deletepopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "left": "",
                    "right": "3%",
                    "text": "Next",
                    "top": "",
                    "width": "20%"
                },
                "deletepopup.formActionsNew.flxMain": {
                    "top": "0dp"
                },
                "deletepopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "deletepopup.lblHeader": {
                    "left": "30dp",
                    "text": "Popup Header"
                },
                "deletepopup.lblPopupMsg": {
                    "text": "Popup Message"
                },
                "deletepopup.trComments": {
                    "right": "",
                    "top": "12dp"
                },
                "cancelpopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "cancelpopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "cancelpopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "cancelpopup.formActionsNew": {
                    "top": "0dp"
                },
                "cancelpopup.formActionsNew.btnCancel": {
                    "right": "20dp",
                    "text": "No",
                    "top": ""
                },
                "cancelpopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "text": "Yes",
                    "top": ""
                },
                "cancelpopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "cancelpopup.lblHeader": {
                    "left": "30dp",
                    "text": "Cancel"
                },
                "cancelpopup.lblPopupMsg": {
                    "text": "Changes you made may not be saved,  do you want to discard the changes?",
                    "width": "80%"
                },
                "cancelpopup.trComments": {
                    "right": "",
                    "top": "12dp"
                },
                "confirmpopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "confirmpopup.flxCommentsWrapper": {
                    "minHeight": "30dp"
                },
                "confirmpopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "confirmpopup.formActionsNew": {
                    "top": ""
                },
                "confirmpopup.formActionsNew.btnCancel": {
                    "right": "20dp",
                    "text": "No",
                    "top": ""
                },
                "confirmpopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "text": "Save",
                    "top": ""
                },
                "confirmpopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "confirmpopup.lblCommnets": {
                    "text": "Comments"
                },
                "confirmpopup.lblHeader": {
                    "left": "30dp",
                    "text": "Create Rule"
                },
                "confirmpopup.lblPopupMsg": {
                    "centerX": "",
                    "centerY": "",
                    "text": "The changes will apply to all accounts of the customer, do you want to save?",
                    "top": "22dp",
                    "width": "70%"
                },
                "confirmpopup.trComments": {
                    "right": "",
                    "top": "12dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs, flxDeletePopup, flxCancelPopup, flxConfirmPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmSignatoryNonMonetaryConditions,
            "enabledForIdleTimeout": true,
            "id": "frmSignatoryNonMonetaryConditions",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_bfc06c471103419ab343480fc924796d,
            "preShow": function(eventobject) {
                controller.AS_Form_c137e99eb7c84fce8c6885360289ded9(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c98c8dd63e0a456585f45c3929e0db70,
            "retainScrollPosition": false
        }]
    }
});