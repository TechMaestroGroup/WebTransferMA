define("PortfolioManagementMA/WealthPortfolioUIModule/frmTopNews", function() {
    return function(controller) {
        function addWidgetsfrmTopNews() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.myaccounts\")",
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSeperatorheader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorheader",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorheader.setDefaultUnit(kony.flex.DP);
            flxSeperatorheader.add();
            flxHeader.add(customheadernew, flxSeperatorheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")"
                },
                "bottom": "8dp",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "40dp",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgBack",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "back_icon_blue.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtn0273e3SSP15px",
                "id": "btnBack",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknBtn0273e3SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.backToInstrumentDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(imgBack, btnBack);
            var flxErrorInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "11dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxErrorInfo",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "1200dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorInfo.setDefaultUnit(kony.flex.DP);
            var imgErrorInfo = new kony.ui.Image2({
                "centerY": "48%",
                "height": "40dp",
                "id": "imgErrorInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtErrorInfo = new kony.ui.RichText({
                "centerY": "50%",
                "id": "txtErrorInfo",
                "isVisible": true,
                "left": "20dp",
                "linkSkin": "defRichTextLink",
                "skin": "bbSknRtx424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.unavailable\")",
                "top": "0",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorInfo.add(imgErrorInfo, txtErrorInfo);
            var flxPrimaryDetailsRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxPrimaryDetailsRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow.setDefaultUnit(kony.flex.DP);
            var flxLeftContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 6,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainer.setDefaultUnit(kony.flex.DP);
            var flxNews = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNews",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNews.setDefaultUnit(kony.flex.DP);
            var topNews = new com.InfinityOLB.PortfolioManagementMA.topNews({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "topNews",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "flxNews": {
                        "width": "91%"
                    },
                    "lblTopNews": {
                        "left": "30dp"
                    },
                    "topNews": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxNews.add(topNews);
            var flxPagination = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxPagination",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "top": "10dp",
                "width": "65%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var pagination = new com.InfinityOLB.PortfolioManagementMA.pagination({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "pagination",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 10,
                "appName": "PortfolioManagementMA",
                "viewType": "pagination",
                "overrides": {
                    "pagination": {
                        "right": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var pagination_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmTopNews"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmTopNews"]["pagination"]) || {};
            pagination.iconPaginationPreviousEnabled = pagination_data.iconPaginationPreviousEnabled || "{\"img\": \"pagination_back_blue.png\"}";
            pagination.sknPaginationText = pagination_data.sknPaginationText || "{\"$.BREAKPTS.BP1\":\"ICSknLblSSP42424214px\",\"default\":\"ICSknLblSSP42424215px\"}";
            pagination.componentVisibility = pagination_data.componentVisibility || "Show all";
            pagination.iconPaginationNextEnabled = pagination_data.iconPaginationNextEnabled || "{\"img\": \"pagination_blue.png\"}";
            pagination.sknRecordsPerPageLabel = pagination_data.sknRecordsPerPageLabel || "ICSknLblSSP72727215px";
            pagination.BREAKPTS = pagination_data.BREAKPTS || "{\"BP1\":\"640\",\"BP2\":\"1024\",\"BP3\":\"1366\"}";
            pagination.recordsPerPage = pagination_data.recordsPerPage || "4";
            pagination.iconPaginationLastEnabled = pagination_data.iconPaginationLastEnabled || "{\"img\": \"pagination_last_active.png\"}";
            pagination.sknRecordsPerPageListItems = pagination_data.sknRecordsPerPageListItems || "{\"$.BREAKPTS.BP1\":\"ICSknLblSSP72727213px\",\"default\":\"ICSknLblSSP72727215px\"}";
            pagination.iconPaginationFirstEnabled = pagination_data.iconPaginationFirstEnabled || "{\"img\":\"pagination_first_active.png\"}";
            pagination.defaultPageNumber = pagination_data.defaultPageNumber || "1";
            pagination.sknRecordsPerPageSelected = pagination_data.sknRecordsPerPageSelected || "{\"$.BREAKPTS.BP1\":\"ICSknLblSSP42424213px\",\"default\":\"ICSknLblSSP42424215px\"}";
            pagination.paginationText = pagination_data.paginationText || "{\"default\":\"{$.t.currentPage}  of {$.t.totalPages} pages\",\"$.BREAKPTS.BP1\":\"{$.t.currentPage}  of {$.t.totalPages} pages\"}";
            pagination.dropdownExpandIcon = pagination_data.dropdownExpandIcon || "{\"img\": \"dropdown_expand.png\"}";
            pagination.recordsPerPageLabel = pagination_data.recordsPerPageLabel || "{\"default\": \"View:\"} ";
            pagination.iconPaginationPreviousDisabled = pagination_data.iconPaginationPreviousDisabled || "{\"img\": \"pagination_back_inactive.png\"}";
            pagination.recordsPerPageList = pagination_data.recordsPerPageList || "[{\"4\":\"4 Per Page\"},{\"10\":\"10 Per Page\"}]";
            pagination.iconPaginationNextDisabled = pagination_data.iconPaginationNextDisabled || "{\"img\": \"pagination_next_inactive.png\"}";
            pagination.iconPaginationLastDisabled = pagination_data.iconPaginationLastDisabled || "{\"img\":\"pagination_last_inactive.png\"}";
            pagination.iconPaginationFirstDisabled = pagination_data.iconPaginationFirstDisabled || "{\"img\": \"pagination_inactive.png\"}";
            pagination.dropdownCollapseIcon = pagination_data.dropdownCollapseIcon || "{\"img\": \"dropdown_collapse.png\"}";
            flxPagination.add(pagination);
            flxLeftContainer.add(flxNews, flxPagination);
            var flxRightContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "60dp",
                "width": "32.50%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var flxPrimaryActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPrimaryActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i527f59b287e40bd849cd109892d4432,
                "skin": "sknFlxffffffShadowdddcdc",
                "width": "28.48%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryActions.setDefaultUnit(kony.flex.DP);
            var marketIndexDashComp = new com.InfinityOLB.PortfolioManagementMA.marketIndexDashComp({
                "height": "150dp",
                "id": "marketIndexDashComp",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "viewType": "marketIndexDashComp",
                "overrides": {
                    "marketIndexDashComp": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var marketIndexDashComp_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmTopNews"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmTopNews"]["marketIndexDashComp"]) || {};
            marketIndexDashComp.objService = marketIndexDashComp_data.objService || "PortfolioServicing";
            marketIndexDashComp.objName = marketIndexDashComp_data.objName || "MarketData";
            marketIndexDashComp.operation = marketIndexDashComp_data.operation || "getDailyMarket";
            marketIndexDashComp.viewAllBtnStatus = marketIndexDashComp_data.viewAllBtnStatus || "hidden";
            flxPrimaryActions.add(marketIndexDashComp);
            var banner = new com.InfinityOLB.PortfolioManagementMA.banner({
                "height": "175px",
                "id": "banner",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "banner": {
                        "isVisible": false,
                        "top": "20dp"
                    },
                    "flxPagination": {
                        "isVisible": false
                    },
                    "imgBanner": {
                        "src": "nuo_banner_1.png"
                    },
                    "imgPaginationOne": {
                        "src": "slider.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxBannerContainerDesktop = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "175dp",
                "id": "flxBannerContainerDesktop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBannerContainerDesktop.setDefaultUnit(kony.flex.DP);
            var imgBannerDesktop = new kony.ui.Image2({
                "bottom": "10dp",
                "id": "imgBannerDesktop",
                "isVisible": true,
                "left": "10dp",
                "right": "10dp",
                "skin": "slImage",
                "src": "nuo_banner_1.png",
                "top": "10dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBannerContainerDesktop.add(imgBannerDesktop);
            flxRightContainer.add(flxPrimaryActions, banner, flxBannerContainerDesktop);
            flxPrimaryDetailsRow.add(flxLeftContainer, flxRightContainer);
            flxMain.add(flxDowntimeWarning, flxBack, flxErrorInfo, flxPrimaryDetailsRow);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Accounts",
                        "segmentProps": []
                    },
                    "flxSeperatorheader": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxBack": {
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "pagination": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxBack": {
                        "segmentProps": []
                    },
                    "flxErrorInfo": {
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "centerX": {
                            "type": "string",
                            "value": "49.60%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxPagination": {
                        "segmentProps": []
                    },
                    "pagination": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxBannerContainerDesktop": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "flxBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "i18n_text": "i18n.wealth.backToInstrumentDetails",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxErrorInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "topNews.flxNews": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "topNews.lblTopNews": {
                        "left": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "segmentProps": []
                    },
                    "flxPagination": {
                        "segmentProps": []
                    },
                    "pagination": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.80%"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "banner": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxBannerContainerDesktop": {
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgBannerDesktop": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "flxBack": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "pagination": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "banner": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxBannerContainerDesktop": {
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgBannerDesktop": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "topNews.flxNews": {
                    "width": "91%"
                },
                "topNews.lblTopNews": {
                    "left": "30dp"
                },
                "pagination": {
                    "right": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "marketIndexDashComp": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "banner": {
                    "top": "20dp"
                },
                "banner.imgBanner": {
                    "src": "nuo_banner_1.png"
                },
                "banner.imgPaginationOne": {
                    "src": "slider.png"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmTopNews,
            "enabledForIdleTimeout": true,
            "id": "frmTopNews",
            "init": controller.AS_Form_ha83a1a2e18446c18fdef16365b90f41,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "PortfolioManagementMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": true
        }]
    }
});