define("BillPayMA/LoanPayUIModule/frmPayDueAmount", function() {
    return function(controller) {
        function addWidgetsfrmPayDueAmount() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxscrollassist = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "5dp",
                "id": "flxscrollassist",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "44dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxscrollassist.setDefaultUnit(kony.flex.DP);
            flxscrollassist.add();
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxDownTimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDownTimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "30dp",
                "width": "86%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownTimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPLightRich42424217Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.ThereisomeerrorintheserverWecouldnotcompleteyourrequestofaddingtheaccount\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownTimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxMyPaymentAccounts = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "336dp",
                "id": "flxMyPaymentAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "65.37%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "28.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyPaymentAccounts.setDefaultUnit(kony.flex.DP);
            var mypaymentAccounts = new com.InfinityOLB.BillPay.PayDueAmount.mypaymentAccounts({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "mypaymentAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.lblMyPaymentAccounts\")",
                        "left": "30px"
                    },
                    "segMypaymentAccounts": {
                        "data": [{
                            "lblAccountName": "Personal Chekcing....1234",
                            "lblAvailableBalance": "Available Balance",
                            "lblBalance": "$6453.90",
                            "lblLeft": " "
                        }, {
                            "lblAccountName": "Personal Chekcing....1234",
                            "lblAvailableBalance": "Available Balance",
                            "lblBalance": "$6453.90",
                            "lblLeft": " "
                        }, {
                            "lblAccountName": "Personal Chekcing....1234",
                            "lblAvailableBalance": "Available Balance",
                            "lblBalance": "$6453.90",
                            "lblLeft": " "
                        }, {
                            "lblAccountName": "Personal Chekcing....1234",
                            "lblAvailableBalance": "Available Balance",
                            "lblBalance": "$6453.90",
                            "lblLeft": " "
                        }]
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMyPaymentAccounts.add(mypaymentAccounts);
            var flxPayDueAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayDueAmount",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "25dp",
                "width": "58.20%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayDueAmount.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "25dp",
                "id": "lblHeading",
                "isVisible": true,
                "left": "6.07%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.accdetails.payDueAmount\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnByPass = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "35dp",
                "id": "btnByPass",
                "isVisible": true,
                "left": "250dp",
                "skin": "btnSkipNavigation",
                "text": "Skip to Actions",
                "top": "-5dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var PayDueAmount = new com.InfinityOLB.BillPay.PayDueAmount.PayDueAmount({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "PayDueAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "45dp",
                "width": "100%",
                "appName": "BillPayMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "39.08%",
                        "top": "240dp"
                    },
                    "AllForms.RichTextInfo": {
                        "text": "You cannot pay more than the due amount.</br></br>You cannot make  an ad-hoc payment more than 'X' number of times in an year etc.</br></br>You cannot Pay-Off loan for a particular arrangement depending on the rules. E.g. if the account was opened in less than 6 months."
                    },
                    "AllForms.RichTextInfoArabic": {
                        "text": " لا يمكنك دفع أكثر من المبلغ المستحق. </br> </br> لا يمكنك إجراء دفعة مخصصة أكثر من \"X\" عدد المرات في السنة وما إلى ذلك. </br> </br> لا يمكنك الدفع- قرض خارج الترتيب لترتيب معين حسب القواعد. على سبيل المثال إذا تم فتح الحساب في أقل من 6 أشهر."
                    },
                    "AllForms.flxInformationText": {
                        "top": "-2dp"
                    },
                    "AllForms.imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "AllForms.imgToolTip": {
                        "src": "tool_tip.png"
                    },
                    "AllForms.lblInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Info\")"
                    },
                    "CalendarSendDate": {
                        "width": "100%"
                    },
                    "PayDueAmount": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "isVisible": true,
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "45dp",
                        "width": "100%"
                    },
                    "btnCancel": {
                        "bottom": "20dp"
                    },
                    "btnPayAmount": {
                        "bottom": "20dp",
                        "top": "0dp"
                    },
                    "flxAmountDue": {
                        "left": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxAmountOther": {
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxButtons": {
                        "top": "30dp"
                    },
                    "flxCalender": {
                        "clipBounds": false,
                        "height": "40dp"
                    },
                    "flxContent": {
                        "clipBounds": false,
                        "zIndex": 1
                    },
                    "flxDueAmount": {
                        "top": "11dp"
                    },
                    "flxDueDate": {
                        "clipBounds": false
                    },
                    "flxError": {
                        "isVisible": false
                    },
                    "flxHeader": {
                        "isVisible": false
                    },
                    "flxImgInfoIcon": {
                        "left": "44%"
                    },
                    "flxInfoDueAmount": {
                        "isVisible": true
                    },
                    "flxInfoDueDate": {
                        "isVisible": false,
                        "right": "viz.val_cleared"
                    },
                    "flxPayDue": {
                        "clipBounds": false
                    },
                    "flxRadioButtons": {
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxRadioPayDueAmount": {
                        "left": "2.50%"
                    },
                    "flxRadioPayOtherAmount": {
                        "left": "24%"
                    },
                    "flxSeparator2": {
                        "left": "viz.val_cleared",
                        "top": "30dp",
                        "width": "95%"
                    },
                    "flxtxtbox": {
                        "width": "46.60%"
                    },
                    "imgError": {
                        "src": "error_yellow.png"
                    },
                    "imgInfoIcon": {
                        "src": "info_grey.png"
                    },
                    "imgRadioPayDueAmount": {
                        "src": "radio_butn_active.png"
                    },
                    "imgRadioPayOtherAmount": {
                        "src": "icon_radiobtn.png"
                    },
                    "lblDueAmount": {
                        "right": "viz.val_cleared"
                    },
                    "lblDueDate": {
                        "right": "viz.val_cleared"
                    },
                    "lblDueDate1": {
                        "left": "0%",
                        "right": "viz.val_cleared"
                    },
                    "lblDueDate2": {
                        "left": "0%",
                        "right": "viz.val_cleared"
                    },
                    "lblError": {
                        "left": "70dp",
                        "width": "85%"
                    },
                    "lblFrom": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")"
                    },
                    "lblHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.payDueAmount\")"
                    },
                    "lblInfoAmount": {
                        "left": "0%",
                        "right": "viz.val_cleared",
                        "text": "et",
                        "width": "100%"
                    },
                    "lblNote": {
                        "top": "20dp",
                        "zIndex": 1
                    },
                    "lblPayDueAmount": {
                        "left": "6.50%"
                    },
                    "lblPayOtherAmount": {
                        "left": "28%"
                    },
                    "lblSend": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.sendSpaceOn\")",
                        "top": "20dp"
                    },
                    "lblTo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.To\")",
                        "top": "20dp"
                    },
                    "listbxFrom": {
                        "top": "10dp"
                    },
                    "listbxTo": {
                        "top": "10dp"
                    },
                    "tbxAmount": {
                        "left": "0%",
                        "width": "100%"
                    },
                    "tbxOptional": {
                        "top": "10dp",
                        "width": "95.50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPayDueAmount.add(lblHeading, btnByPass, PayDueAmount);
            var flxLoanPayOff = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanPayOff",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "58.20%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanPayOff.setDefaultUnit(kony.flex.DP);
            var lblHeading1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading1",
                "isVisible": true,
                "left": "6.07%",
                "skin": "sknlbl42424217px",
                "text": "Loan Pay-Off",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var btnByPass2 = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "35dp",
                "id": "btnByPass2",
                "isVisible": true,
                "left": "250dp",
                "skin": "btnSkipNavigation",
                "text": "Skip to other payment options",
                "top": "-5dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var LoanPayOff = new com.InfinityOLB.BillPay.PayDueAmount.LoanPayOff({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "LoanPayOff",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "width": "100%",
                "appName": "BillPayMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "3.78%",
                        "top": "530dp"
                    },
                    "AllForms.RichTextInfo": {
                        "left": "7.80%",
                        "top": "0dp"
                    },
                    "AllForms.imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "AllForms.imgToolTip": {
                        "src": "tool_tip.png"
                    },
                    "CalenderPayOffDate": {
                        "isVisible": true,
                        "width": "100%"
                    },
                    "LoanPayOff": {
                        "isVisible": true
                    },
                    "btnCancel": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                        "top": "672px"
                    },
                    "btnCancelDetails": {
                        "bottom": "20dp",
                        "centerX": "viz.val_cleared",
                        "height": "40dp",
                        "left": "viz.val_cleared",
                        "right": "205dp",
                        "top": "0dp",
                        "width": "150dp"
                    },
                    "btnConfirm": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.PAYAMOUNT\")",
                        "top": "672px"
                    },
                    "btnContinueDetails": {
                        "bottom": "20dp",
                        "centerX": "viz.val_cleared",
                        "height": "40dp",
                        "left": "viz.val_cleared",
                        "right": "35dp",
                        "top": "0dp",
                        "width": "150dp"
                    },
                    "flxBottomDetails": {
                        "clipBounds": true,
                        "minHeight": "viz.val_cleared",
                        "top": "0dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxButtons": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "60dp",
                        "left": "0dp",
                        "top": "30dp",
                        "width": "100%",
                        "zIndex": 2,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxCalender": {
                        "clipBounds": false,
                        "width": "45.34%"
                    },
                    "flxContent": {
                        "clipBounds": false
                    },
                    "flxContentDuplicate": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxDetails": {
                        "clipBounds": true,
                        "left": "3.70%",
                        "minHeight": "viz.val_cleared",
                        "top": "20dp"
                    },
                    "flxError": {
                        "height": "62dp",
                        "isVisible": false,
                        "left": "0.00%",
                        "top": "0dp",
                        "width": "100.00%"
                    },
                    "flxHeader": {
                        "isVisible": true
                    },
                    "flxTopDetails": {
                        "bottom": "20dp",
                        "centerX": "50%",
                        "clipBounds": true,
                        "minHeight": "viz.val_cleared",
                        "top": "0dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxTransferTo": {
                        "isVisible": false
                    },
                    "flxWarningMessage": {
                        "height": "50dp"
                    },
                    "imgCheckbox": {
                        "src": "unchecked_box.png"
                    },
                    "imgError": {
                        "src": "error_yellow.png"
                    },
                    "imgInfo": {
                        "src": "info_large.png"
                    },
                    "imgInfoIcon": {
                        "src": "info_grey.png"
                    },
                    "imgInfoIcon1": {
                        "src": "info_grey.png"
                    },
                    "imgInfoflx": {
                        "src": "info_large.png"
                    },
                    "imgLoadingIndicatorTo": {
                        "src": "rb_4_0_ad_loading_indicator.gif"
                    },
                    "imgWarning": {
                        "src": "bluealert_2.png"
                    },
                    "lblActualLoanEndDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.actualLoanEndDateWithColon\")",
                        "left": 30,
                        "top": "10dp"
                    },
                    "lblActualLoanEndDateValue": {
                        "bottom": "viz.val_cleared",
                        "left": 30,
                        "top": "30dp"
                    },
                    "lblAgree": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.termsandconditions\")"
                    },
                    "lblCurrentBalanceLabel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.currentBalance\")",
                        "left": "78.65%",
                        "top": "20dp"
                    },
                    "lblCurrentBalanceValue": {
                        "left": "78.65%",
                        "top": "40dp"
                    },
                    "lblCurrentDueLabel": {
                        "centerX": "viz.val_cleared",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.currentDueWithColon\")",
                        "left": "47.87%",
                        "top": "20dp"
                    },
                    "lblCurrentDueValue": {
                        "centerX": "viz.val_cleared",
                        "left": "47.87%",
                        "top": "40dp"
                    },
                    "lblError": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Pageleveltransactionlevelerrorsappearhere\")",
                        "left": "20dp"
                    },
                    "lblFrom": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblFrom\")"
                    },
                    "lblFromDetails": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")"
                    },
                    "lblHeader": {
                        "centerY": "50%",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.LOANPAYOFF\")",
                        "top": "viz.val_cleared"
                    },
                    "lblLoanEndDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.ActualLoanEndDate\")"
                    },
                    "lblLoanPayOffAmount": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.LoanPayoffAmount\")"
                    },
                    "lblLoanPayOffAmountLabel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.payOffAmountWithColon\")"
                    },
                    "lblNote": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Description\")"
                    },
                    "lblPayOffDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.payOffDateWithColon\")"
                    },
                    "lblPayOffPenality": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.PayoffPenalty\")"
                    },
                    "lblPayOffPenalityLabel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.payOffPenalityWithColon\")"
                    },
                    "lblTo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblTo\")"
                    },
                    "lblToLabel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.to\")",
                        "left": "30dp",
                        "top": "20dp"
                    },
                    "lblToValue": {
                        "left": 30,
                        "top": "35dp"
                    },
                    "lblToValueDetails": {
                        "left": 30,
                        "top": "60dp"
                    },
                    "lblTotalInterestLabel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.totalInterest\")",
                        "left": "78.65%",
                        "top": "10dp"
                    },
                    "lblTotalInterestValue": {
                        "bottom": "viz.val_cleared",
                        "left": "78.65%",
                        "top": "30dp"
                    },
                    "lblTotalPrincipalLabel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.totalPrincipal\")",
                        "left": 350,
                        "top": "10dp"
                    },
                    "lblTotalPrincipalValue": {
                        "bottom": "viz.val_cleared",
                        "left": 350,
                        "top": "30dp"
                    },
                    "lblWarning": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.noteTheFollowingPoints\")"
                    },
                    "lblWarningSecond": {
                        "bottom": "viz.val_cleared",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.payoffInquiry\")",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "listbxFromDetails": {
                        "width": "92.53%"
                    },
                    "tbxLoanPayOffAmountValue": {
                        "width": "45.34%"
                    },
                    "tbxPayoffPenalityValue": {
                        "width": "45.34%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLoanPayOff.add(lblHeading1, btnByPass2, LoanPayOff);
            var flxActions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "65.30%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "70dp",
                "width": "28.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var flxSecondaryActions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "60dp",
                "id": "flxSecondaryActions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryActions.setDefaultUnit(kony.flex.DP);
            var btnPayDueAccount = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "60dp",
                "id": "btnPayDueAccount",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.payDueAmount\")",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSecondaryActions.add(btnPayDueAccount);
            var flxPrimaryActions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "60dp",
                "id": "flxPrimaryActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryActions.setDefaultUnit(kony.flex.DP);
            var flxSeparatorPrimaryActions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorPrimaryActions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorPrimaryActions.setDefaultUnit(kony.flex.DP);
            flxSeparatorPrimaryActions.add();
            var btnViewAccountDetail = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "60dp",
                "id": "btnViewAccountDetail",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ViewAccountDetails\")",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnViewStatement = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "60dp",
                "id": "btnViewStatement",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknBtnSSP3343a815pxhover",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ViewStatements.STATEMENTS\")",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View Statements"
            });
            flxPrimaryActions.add(flxSeparatorPrimaryActions, btnViewAccountDetail, btnViewStatement);
            flxActions.add(flxSecondaryActions, flxPrimaryActions);
            var flxConfirmation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmation",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmation.setDefaultUnit(kony.flex.DP);
            var lblConfirmationTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblConfirmationTitle",
                "isVisible": true,
                "left": "6.08%",
                "skin": "sknlblUserName",
                "text": "Due Payment- Confirmation",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMainConfirmation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainConfirmation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "55dp",
                "width": "87.77%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainConfirmation.setDefaultUnit(kony.flex.DP);
            var confirmation = new com.InfinityOLB.BillPay.PayDueAmount.confirmation({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "confirmation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA",
                "overrides": {
                    "btnTermsAndConditions": {
                        "top": "26dp"
                    },
                    "confirmHeaders.lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.YourTransactionDetails\")"
                    },
                    "confirmation": {
                        "minHeight": "viz.val_cleared"
                    },
                    "flxActualEndDateDetails": {
                        "left": "20dp",
                        "top": "20dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxActualEndDateKey": {
                        "left": "0dp"
                    },
                    "flxActualEndDateValue": {
                        "left": "35%",
                        "top": "0dp",
                        "width": "250dp"
                    },
                    "flxCenterDetails": {
                        "centerX": "viz.val_cleared",
                        "height": "296dp",
                        "isVisible": true,
                        "left": "49.91%",
                        "width": "1dp"
                    },
                    "flxCheckbox": {
                        "left": "2.50%",
                        "top": "20dp",
                        "width": "20dp"
                    },
                    "flxContainerPartialDate": {
                        "isVisible": true
                    },
                    "flxCurrentBalanceDetails": {
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "top": "20dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxCurrentBalanceKey": {
                        "left": "0dp"
                    },
                    "flxCurrentBalanceValue": {
                        "left": "35%",
                        "top": "0dp",
                        "width": "250dp"
                    },
                    "flxError": {
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxFromDetails": {
                        "left": "20dp",
                        "top": "20dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxFromKey": {
                        "left": "0dp"
                    },
                    "flxFromValue": {
                        "left": "25%",
                        "top": "0dp",
                        "width": "400dp"
                    },
                    "flxIAgree": {
                        "isVisible": true,
                        "top": "250dp"
                    },
                    "flxLateFeeValue": {
                        "left": "16%",
                        "top": "0dp",
                        "width": "30%"
                    },
                    "flxLatePaymentChargeDetails": {
                        "bottom": "viz.val_cleared",
                        "isVisible": false,
                        "minHeight": "viz.val_cleared",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxLeftDetails": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "2.20%",
                        "minHeight": "viz.val_cleared",
                        "width": "47%"
                    },
                    "flxMainWrapper": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxPartialPayment": {
                        "isVisible": false
                    },
                    "flxPartialPaymentdetails": {
                        "isVisible": true
                    },
                    "flxPayOffAmountDetails": {
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "top": "20dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxPayOffAmountKey": {
                        "left": "0dp"
                    },
                    "flxPayOffAmountValue": {
                        "left": "25%",
                        "top": "0dp",
                        "width": "30%"
                    },
                    "flxPayOffDateDetails": {
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxPayOffDateKey": {
                        "left": "0dp"
                    },
                    "flxPayOffDateValue": {
                        "left": "35%",
                        "top": "0dp",
                        "width": "250dp"
                    },
                    "flxPayOffPenalityDetails": {
                        "bottom": "viz.val_cleared",
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "top": "20dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxPayOffPenalityKey": {
                        "left": "0dp"
                    },
                    "flxPayOffPenalityValue": {
                        "left": "25%",
                        "top": "0dp",
                        "width": "30%"
                    },
                    "flxRateDetails": {
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxRateKey": {
                        "left": "0dp"
                    },
                    "flxRateValue": {
                        "left": "35%",
                        "top": "0dp",
                        "width": "250dp"
                    },
                    "flxRightDetails": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "51%",
                        "maxWidth": "viz.val_cleared",
                        "width": "47%"
                    },
                    "flxSeperatorLine": {
                        "isVisible": true
                    },
                    "flxToDetails": {
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "top": "20dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxToKey": {
                        "left": "0dp"
                    },
                    "flxToValue": {
                        "left": "25%",
                        "top": "0dp",
                        "width": "30%"
                    },
                    "flxTotalInterestDetails": {
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxTotalInterestKey": {
                        "left": "0dp"
                    },
                    "flxTotalInterestValue": {
                        "left": "35%",
                        "top": "0dp",
                        "width": "250dp"
                    },
                    "flxTotalPrincipalDetails": {
                        "left": "20dp",
                        "minHeight": "viz.val_cleared",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxTotalPrincipalKey": {
                        "left": "0dp"
                    },
                    "flxTotalPrincipalValue": {
                        "left": "35%",
                        "top": "0dp",
                        "width": "250dp"
                    },
                    "flxWrapper": {
                        "isVisible": true
                    },
                    "imgError": {
                        "src": "error_yellow.png",
                        "width": "8.54%"
                    },
                    "lblActualEndDateValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblAgree": {
                        "top": 21
                    },
                    "lblCurrentBalanceValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblError": {
                        "left": "14.95%",
                        "width": "54.91%"
                    },
                    "lblFavoriteEmailCheckBoxMain": {
                        "width": "20dp"
                    },
                    "lblFromValue": {
                        "left": "0dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                        "left": "0",
                        "right": "viz.val_cleared"
                    },
                    "lblKeyAmount": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.Amount($)\")"
                    },
                    "lblKeyBalanceAmount": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.BalanceAmount\")"
                    },
                    "lblKeyDAte": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Date:\")"
                    },
                    "lblKeyDescription": {
                        "text": "Notes:"
                    },
                    "lblKeyPartialDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblDate\")"
                    },
                    "lblKeyPaymentDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.paymentDateWithColon\")"
                    },
                    "lblKeyPenaltyAmount": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.confirmPenaltyAmount\")"
                    },
                    "lblKeyTo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.To\")"
                    },
                    "lblKeyYouArePaying": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.YouarePaying\")"
                    },
                    "lblKeyYourBill": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.YourBillAmount\")"
                    },
                    "lblLateFeeKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18npayments.lastPaymentsCharges\")"
                    },
                    "lblPayOffAmountValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblPayOffDateValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblPayOffPenalityValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblRateValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblToValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblTotalInterestValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblTotalPrincipalValue": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainConfirmation.add(confirmation);
            flxConfirmation.add(lblConfirmationTitle, flxMainConfirmation);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgement",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var lblAcknowledgementTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblAcknowledgementTitle",
                "isVisible": true,
                "left": "6.07%",
                "skin": "sknlbl42424217px",
                "text": "Loan Due Payment-Acknowledgment",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMainAcknowledgment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainAcknowledgment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainAcknowledgment.setDefaultUnit(kony.flex.DP);
            var acknowledgment = new com.InfinityOLB.BillPay.PayDueAmount.acknowledgment({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "acknowledgment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.07%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "43.26%",
                "appName": "BillPayMA",
                "overrides": {
                    "ImgAcknowledged": {
                        "height": "72dp",
                        "src": "success_green.png",
                        "top": "220dp"
                    },
                    "acknowledgment": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "6.07%",
                        "minHeight": "400px",
                        "minWidth": "viz.val_cleared",
                        "top": "0dp",
                        "width": "43.26%"
                    },
                    "flxBalance": {
                        "isVisible": true
                    },
                    "flxSeparator": {
                        "isVisible": true
                    },
                    "flxWrapper": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared"
                    },
                    "lblAccType": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.MySavingsAccount\")"
                    },
                    "lblAvailableBalance": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.NowyouravailableBalancein\")"
                    },
                    "lblTransactionMessage": {
                        "text": "Label",
                        "top": "78px",
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var confirmDialog = new com.InfinityOLB.BillPay.PayDueAmount.confirmDialog({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "confirmDialog",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50.58%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "43.26%",
                "appName": "BillPayMA",
                "overrides": {
                    "confirmDialog": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "50.58%",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "width": "43.26%"
                    },
                    "flxKeyBalanceAmount": {
                        "width": "27%"
                    },
                    "flxKeyPayDate": {
                        "width": "20%"
                    },
                    "flxKeyPayoffCharges": {
                        "top": "0dp",
                        "width": "18%"
                    },
                    "flxKeyPayoffamount": {
                        "top": "0dp",
                        "width": "18%"
                    },
                    "flxMain": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared",
                        "clipBounds": false
                    },
                    "flxPartial": {
                        "height": "215dp"
                    },
                    "flxValue": {
                        "width": "62%"
                    },
                    "flxValueAmount": {
                        "width": "62%"
                    },
                    "flxValueDescription": {
                        "width": "62%"
                    },
                    "flxValueLoanEndDate": {
                        "width": "62%"
                    },
                    "flxValueTo": {
                        "width": "62%"
                    },
                    "lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.from\")"
                    },
                    "lblKeyBalanceAmount": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.BalanceAmount\")",
                        "width": "100%"
                    },
                    "lblKeyBillAmount": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.YourBillAmount\")"
                    },
                    "lblKeyDescription": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.Description\")"
                    },
                    "lblKeyLoanEndDate": {
                        "text": "Actual Loan End Date:",
                        "width": "100%"
                    },
                    "lblKeyPaying": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.YouarePaying\")"
                    },
                    "lblKeyPayoffCharges": {
                        "width": "95%"
                    },
                    "lblKeyTo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.to\")"
                    },
                    "lblKeypayoffamount": {
                        "width": "95%"
                    },
                    "lblValue": {
                        "width": "100%"
                    },
                    "lblValueDescription": {
                        "text": "Car Loan EMI for July ",
                        "width": "100%"
                    },
                    "lblValueTo": {
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainAcknowledgment.add(acknowledgment, confirmDialog);
            var flxButton = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxButton",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "reverseLayoutDirection": false,
                "left": "-6%",
                "isModalContainer": false,
                "right": "10dp",
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButton.setDefaultUnit(kony.flex.DP);
            var btnBackToAccountDeatil = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnBackToAccountDeatil",
                "isVisible": true,
                "left": "20dp",
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ViewStatements.BackToAccountDetails\")",
                "top": "0dp",
                "width": "20.86%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnBackToAccountSummary = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Go to Account Summary"
                },
                "bottom": "20px",
                "height": "40dp",
                "id": "btnBackToAccountSummary",
                "isVisible": true,
                "left": "-10dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ViewStatements.GoToAccountSummary\")",
                "top": "0dp",
                "width": "20.86%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxButton.add(btnBackToAccountDeatil, btnBackToAccountSummary);
            flxAcknowledgement.add(lblAcknowledgementTitle, flxMainAcknowledgment, flxButton);
            flxMainContainer.add(flxMyPaymentAccounts, flxPayDueAmount, flxLoanPayOff, flxActions, flxConfirmation, flxAcknowledgement);
            var flxBottom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "128dp",
                "id": "flxBottom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var flxTermsConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "79dp",
                "id": "flxTermsConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsConditions.setDefaultUnit(kony.flex.DP);
            var lblTermsConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblTermsConditions",
                "isVisible": true,
                "left": "2%",
                "skin": "ICSknLbl949494SSPR15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.TermsAndConditions\")",
                "width": "96%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTermsConditions.add(lblTermsConditions);
            flxBottom.add(flxTermsConditions);
            flxContainer.add(flxDownTimeWarning, flxMainContainer, flxBottom);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxscrollassist, flxContainer, flxFooter);
            var flxQuitPaymentParent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxQuitPaymentParent",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1100,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuitPaymentParent.setDefaultUnit(kony.flex.DP);
            var flxQuitPayment = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxQuitPayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1100
            }, {
                "paddingInPixel": false
            }, {});
            flxQuitPayment.setDefaultUnit(kony.flex.DP);
            var CustomPopup1 = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.QUITPAYMENT\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxQuitPayment.add(CustomPopup1);
            flxQuitPaymentParent.add(flxQuitPayment);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1100,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsPopUp = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxTermsAndConditionsPopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1501
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsPopUp.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "600dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "120dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "close terms and conditions popup"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Close"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "richtext",
                        "tabindex": -1
                    }
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxTcArabic = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "richtext",
                        "tabindex": -1
                    }
                },
                "bottom": "10dp",
                "id": "rtxTcArabic",
                "isVisible": false,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nبالموافقة على أنك قد قرأت هذه الشروط والأحكام واستمرار التسجيل في البيانات الإلكترونية / الإشعارات الإلكترونية ، فإنك تشير إلى موافقتك على جميع الشروط والأحكام والإشعارات الواردة أو المشار إليها في هذا المستند وتقبل المسؤولية عن استخدامك للخدمة. إذا اخترت عدم الموافقة على قراءتك لهذه الشروط والأحكام ، فلن يتم تسجيلك في الخدمة ولن تتحمل أي مسؤولية أخرى تجاه البنك. يخضع الوصول إلى الخدمة واستخدام الخدمة لجميع الدول الفيدرالية المعمول بها. والقوانين واللوائح المحلية. يُحظر تمامًا الاستخدام غير المصرح به للخدمة أو المعلومات التي يتم الوصول إليها عبر الخدمة.\nبالموافقة على أنك قد قرأت هذه الشروط والأحكام واستمرار التسجيل في البيانات الإلكترونية / الإشعارات الإلكترونية ، فإنك تشير إلى موافقتك على جميع الشروط والأحكام والإشعارات الواردة أو المشار إليها في هذا المستند وتقبل المسؤولية عن استخدامك للخدمة. إذا اخترت عدم الموافقة على قراءتك لهذه الشروط والأحكام ، فلن يتم تسجيلك في الخدمة ولن تتحمل أي مسؤولية أخرى تجاه البنك. يخضع الوصول إلى الخدمة واستخدام الخدمة لجميع الدول الفيدرالية المعمول بها. والقوانين واللوائح المحلية. يُحظر تمامًا الاستخدام غير المصرح به للخدمة أو المعلومات التي يتم الوصول إليها عبر الخدمة.\n<br/>\n<b> وصف الكشوف الإلكترونية </ b>\n<br/>\nيتم تقديم البيانات الإلكترونية لحسابات الإيداع المؤهلة ، مما يسمح لك باستبدال كشف الحساب المرسل (الورقي) بالبريد بإصدار إلكتروني (PDF) يمكنك عرضه أو حفظه على جهاز الكمبيوتر الخاص بك أو طباعته على راحتك. سيتم تسليم أي إشعارات قانونية عادة ما تصاحب البيان المرسل إليك إلكترونيًا. فيما يلي وصف موجز لمختلف ميزات الخدمة ومتطلبات استخدام الخدمة. من وقت لآخر ، يجوز لنا إضافة أو تعديل أو حذف أي ميزة في الخدمة وفقًا لتقديرنا الخاص. يرجى ملاحظة أنه بالتسجيل في كشوفات الحساب الإلكترونية ، لن تتلقى بعد ذلك كشف حساب ورقي بالبريد. ومع ذلك ، سيتاح لك كشف حساب ورقي شهري عند الطلب عن طريق الاتصال بالبنك.\n<br/>\n<b> التسجيل في كشوف الحسابات الإلكترونية </ b>\n<br/>\nيجب عليك التسجيل أولاً وتصبح عميلاً للخدمات المصرفية عبر الإنترنت لاستخدام الخدمة. يجب عليك قبول هذه الشروط والأحكام لتصبح مستخدمًا مسجلاً في الخدمة. سيتم توفير كشوفاتك الإلكترونية لك عند تسجيل الدخول إلى الخدمة المصرفية عبر الإنترنت الخاصة بالبنك. عند التسجيل للحصول على كشوفات الحساب الإلكترونية:\n<br/>\nأنت توافق على استلام كشف حسابك المصرفي بصيغة إلكترونية وتفوضنا بتسليم كشف حسابك إلكترونيًا في دورة كشف حساب شهرية. قد لا تتوفر كشوف حسابات العملاء المجمعة.\nسيتم تقديم البيان الخاص بك بتنسيق يمكن قراءته وطباعته وتنزيله. سيكون كشف حسابك الإلكتروني متاحًا للعرض لمدة تصل إلى 12 شهرًا بدءًا من شهر التسجيل. أنت توافق أيضًا على التنازل عن إرسال بيان ورقي بالبريد اعتبارًا من هذا الوقت فصاعدًا. ومع ذلك ، يمكنك رفض الخدمة في أي وقت وتلقي كشوف ورقية بالبريد عن طريق الاتصال بنا لإبلاغنا بطلب الإنهاء الخاص بك. في جميع الأوقات ، سيتاح لك كشف حساب شهري في البنك عند الطلب.\n<br/>\n<b> الحسابات المؤهلة للحصول على كشوف الحسابات الإلكترونية </ b>\n<br/>\nتشمل الحسابات المؤهلة أنواع الحسابات الشخصية أو غير الشخصية التالية: الحسابات الجارية والادخار وحسابات سوق المال التي تحتوي على كشوف حسابات دورية متكررة. سيتم تسجيل جميع الحسابات الجارية وحسابات سوق المال وحسابات التوفير المرتبطة برقم الضمان الاجتماعي أو رقم التعريف الضريبي لصاحب الحساب الأساسي أو الثانوي تلقائيًا في الكشوف الإلكترونية. ستتلقى كشوفات حساب إلكترونية للحسابات التي تختارها عند التسجيل. إذا لم تختر حسابًا ، فستستمر في تلقي كشوف ورقية لهذا الحساب.\n<br/>\nنحتفظ بموجب هذا بالحق وفقًا لتقديرنا المطلق في تقييد الموافقة على الخدمات المنصوص عليها في هذه الاتفاقية أو توفرها والوصول إليها على أي حساب موضوع يتم تقديمه بموجب هذه الاتفاقية إلى الفرد المدرج في سجلات البنك باعتباره الحساب الأساسي فقط. صاحب مثل هذه الحسابات.\nإذا كان أي حساب قمت بتقديم طلب للحصول عليه ووافق عليه البنك لتلقي كشوف الحسابات الإلكترونية هو حساب مشترك ، فيرجى العلم بأن المالك الأساسي أو صاحب الحساب الثانوي فقط كما هو موضح في مستند كشف الحساب هو الذي سيتلقى ويكون قادرًا على الوصول إليه. البيان الإلكتروني لهذا الحساب.\n<br/>\n<b> التسجيل لتسليم كشوف الحسابات الإلكترونية </ b>\n<br/>\nللوصول إلى الخدمة ، يجب عليك تسجيل الدخول إلى خدمتنا المصرفية عبر الإنترنت واختيار ملف التعريف ، ثم ESTATEMENT-EDIT. اتبع التعليمات التي تظهر على الشاشة للتسجيل في كشوف الحسابات الإلكترونية. بالنسبة للحسابات ذات المالكين المتعددين ، يحتاج مالك حساب واحد فقط إلى تسجيل الحساب في الخدمة. قد لا يكون كشف الشهر الحالي متاحًا حتى تاريخ الدورة التالية.\n<br/>\n<b> تغيير في البنود والشروط </ b>\n<br/>\nيحتفظ البنك بالحق في تعديل هذه الاتفاقية في أي وقت. يجب أن تكون أي تعديلات فعالة عندما يتم نشرها على الخدمة. سيتم إخطارك في أقرب وقت ممكن عند إجراء أي تغييرات تؤثر بشكل جوهري على حقوقك ، مثل التغييرات المتعلقة بكيفية الحفاظ على معلوماتك أو استخدامها. تقع على عاتقك مسؤولية مراجعة هذه الاتفاقية بما في ذلك سياسة الخصوصية الخاصة بالبنك لتكون على دراية بأي من هذه التغييرات.\n<br/>\n<b> الإنهاء </ b>\n<br/>\nستكون هذه الاتفاقية سارية المفعول من تاريخ تقديم التسجيل الخاص بك وقبوله من قبل البنك وفي جميع الأوقات أثناء استخدامك للخدمة. يجوز لك أو للبنك إنهاء هذه الاتفاقية واستخدامك للخدمة في أي وقت. بصفتك أحد عملاء البنك ، يحق لك إرسال كشف حساب ورقي إليك عبر البريد بدلاً من كشف الحساب الإلكتروني (eStatement). لإلغاء الاشتراك في خدمة كشف الحساب الإلكتروني للبنك والبدء في استلام كشف حسابك الورقي مرة أخرى ، سوف تتصل بنا على الرقم (605) 698-7621.\n<br/>\n<br/>\n<b> متنوعة </ b>\n<br/>\nإذا تم اعتبار أي بند من أحكام هذه الاتفاقية غير صالح أو غير قابل للتنفيذ بأي شكل من الأشكال ، تظل بقية الأحكام سارية المفعول والتأثير الكامل ولن يتم إبطالها أو تأثرها بأي حال من الأحوال. العناوين هي للإشارة فقط ولا تحدد بأي حال من الأحوال أو تحدد أو تفسر أو تصف نطاق أو مدى هذا القسم. إن فشلنا في التصرف فيما يتعلق بخرق من قبلك أو من قبل الآخرين لا يتنازل عن حقنا في التصرف فيما يتعلق بالانتهاكات اللاحقة أو المماثلة. تمثل هذه الاتفاقية الاتفاقية الوحيدة والحصرية بينك وبين البنك فيما يتعلق بالخدمة وتدمج وتحل محل جميع الاتفاقيات والتفاهمات السابقة والمعاصرة المكتوبة أو الشفهية فيما يتعلق بموضوع هذه الاتفاقية. يجوز للبنك التنازل عن الخدمة ، بما في ذلك هذه الاتفاقية كليًا أو جزئيًا ؛ ومع ذلك ، لا يجوز لك التنازل عن هذه الاتفاقية أو نقلها. في حالة وجود تعارض بين أي بند أو شرط بين هذه الاتفاقية وأي مستند مدرج هنا بالإشارة إلى هذه الاتفاقية ، يجب أن تكون الاتفاقية هي الحاكمة.\nإذا كانت لديك أي أسئلة بخصوص هذه الاتفاقية أو الخدمة ، فيرجى الاتصال بمصرفنا.\nتخضع هذه الخدمة لجميع الشروط والأحكام المنصوص عليها في شروط وأحكام الخدمات المصرفية عبر الإنترنت التي تم توفيرها لك مسبقًا.\n<br/>\n. </style> </p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC, rtxTcArabic);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var CopyflxDummy0a7b5b9eb258749 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "CopyflxDummy0a7b5b9eb258749",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDummy0a7b5b9eb258749.setDefaultUnit(kony.flex.DP);
            CopyflxDummy0a7b5b9eb258749.add();
            var flxBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "657dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxBody.add(brwBodyTnC);
            var flxSpacing = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(CopyflxDummy0a7b5b9eb258749, flxBody, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxScrollDetails);
            flxTermsAndConditionsPopUp.add(flxTC);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1100
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxTermsAndConditionsPopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmPayDueAmount": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDownTimeWarning": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "1001px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMyPaymentAccounts": {
                        "isVisible": false,
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPayDueAmount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "17.50%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.CalendarSendDate": {
                        "segmentProps": []
                    },
                    "PayDueAmount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "PayDueAmount"
                    },
                    "PayDueAmount.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.btnPayAmount": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxAmountOther": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxCalender": {
                        "height": {
                            "type": "string",
                            "value": "46dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxDueAmount": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxInfoDueAmount": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxInfoDueDate": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioButtons": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxtxtbox": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblDueAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblDueDate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblDueDate1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblDueDate2": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblError": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblInfoAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "ethrthrhrthdr",
                        "segmentProps": []
                    },
                    "PayDueAmount.lblNote": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblPayDueAmount": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblSend": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.tbxAmount": {
                        "segmentProps": []
                    },
                    "PayDueAmount.tbxOptional": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanPayOff": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblHeading1": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LoanPayOff.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "top": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.AllForms.RichTextInfo": {
                        "left": {
                            "type": "string",
                            "value": "7.80%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.CalenderPayOffDate": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "LoanPayOff"
                    },
                    "LoanPayOff.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "640px"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.btnCancelDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "700px"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.btnContinueDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxBottomDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minHeight": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "LoanPayOff.flxCalendar": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "343dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxCalender": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxCheckbox": {
                        "height": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "562dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxContent": {
                        "height": {
                            "type": "string",
                            "value": "760dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxDetails": {
                        "segmentProps": []
                    },
                    "LoanPayOff.flxError": {
                        "segmentProps": []
                    },
                    "LoanPayOff.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LoanPayOff.flxImageInfo": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxPayOffPenality": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "399dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxSeparator2": {
                        "top": {
                            "type": "string",
                            "value": "599dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxTopDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minHeight": {
                            "type": "string",
                            "value": "178dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.imgCheckbox": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblActualLoanEndDate": {
                        "left": {
                            "type": "string",
                            "value": "9px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblActualLoanEndDateValue": {
                        "left": {
                            "type": "string",
                            "value": "9px"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblAgree": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "562dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentBalanceLabel": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentBalanceValue": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentDueLabel": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentDueValue": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblFrom": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblLoanEndDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "239dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblLoanPayOffAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "158dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOffPenality": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "318dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "79dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblToLabel": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblToValue": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblToValueDetails": {
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestLabel": {
                        "left": {
                            "type": "string",
                            "value": "9px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestValue": {
                        "left": {
                            "type": "string",
                            "value": "9px"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalLabel": {
                        "left": {
                            "type": "string",
                            "value": "9px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalValue": {
                        "left": {
                            "type": "string",
                            "value": "9px"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblWarningSecond": {
                        "height": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.listbxFrom": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.listbxFromDetails": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.listbxTo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "102dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxActualLoanEndDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "262dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxLoanPayOffAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "183dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxLoanPayOffAmountValue": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxOptional": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "503dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxPayoffPenality": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "424dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxPayoffPenalityValue": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSecondaryActions": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxConfirmation": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "981px"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblConfirmationTitle": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainConfirmation": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.btnTermsAndConditions": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation": {
                        "minHeight": {
                            "type": "string",
                            "value": "881px"
                        },
                        "segmentProps": [],
                        "instanceId": "confirmation"
                    },
                    "confirmation.flxActualEndDateDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxActualEndDateKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxActualEndDateValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCenterDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "4.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerBalanceAmount": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerDescription": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerPartialDate": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerYouArePaying": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerYourBill": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCurrentBalanceDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCurrentBalanceKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCurrentBalanceValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxError": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxFromDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxFromKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxFromValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxIAgree": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKey": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyAmount": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyBalanceAmount": {
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyDate": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyDescription": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyPartialDate": {
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyPaymentDate": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyPenaltyAmount": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyTo": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyYouArePaying": {
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyYourBill": {
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "confirmation.flxLateFeeValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxLatePaymentChargeDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxLeft": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxLeftDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxMainWrapper": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "confirmation.flxPartialPayment": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPartialPaymentdetails": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffAmountDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffAmountKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffDateDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffDateKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffDateValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffPenalityDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffPenalityKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffPenalityValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxRateDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxRateKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxRateValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxRightDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxSeparator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxSeperatorLine": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmation.flxToDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxToKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxToValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalInterestDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalInterestKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalInterestValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalPrincipalDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalPrincipalKey": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalPrincipalValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValue": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValue0Description": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueAmount": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueBalanceAmount": {
                        "left": {
                            "type": "string",
                            "value": "36.11%"
                        },
                        "width": {
                            "type": "string",
                            "value": "63%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueDate": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValuePartialDate": {
                        "left": {
                            "type": "string",
                            "value": "36.11%"
                        },
                        "width": {
                            "type": "string",
                            "value": "63%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValuePaymentDate": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValuePenaltyAmount": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueTo": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueYouArePaying": {
                        "left": {
                            "type": "string",
                            "value": "36.11%"
                        },
                        "width": {
                            "type": "string",
                            "value": "63%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueYourBill": {
                        "left": {
                            "type": "string",
                            "value": "36.11%"
                        },
                        "width": {
                            "type": "string",
                            "value": "63%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxWrapper": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "confirmation.lblAgree": {
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblError": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKey": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyBalanceAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyDAte": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyDescription": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyPartialDate": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyPaymentDate": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyPenaltyAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyTo": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyYouArePaying": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblKeyYourBill": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementTitle": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "s52290e2ece44ae9b235133cae7e448b",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainAcknowledgment": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.ImgAcknowledged": {
                        "segmentProps": []
                    },
                    "acknowledgment": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "acknowledgment"
                    },
                    "acknowledgment.flxBalance": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.flxSeparator": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.flxWrapper": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblRefrenceNumber": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblRefrenceNumberValue": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblTransactionMessage": {
                        "segmentProps": []
                    },
                    "confirmDialog": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "confirmDialog"
                    },
                    "confirmDialog.flxContainerBalanceAmount": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxContainerPayDate": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxContainerPaying": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKey": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyAmount": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyBalanceAmount": {
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyBillAmount": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyDescription": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyLoanEndDate": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyPartial": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyPayDate": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyPaying": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyPayoffCharges": {
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyPayoffamount": {
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyPenalityAmount": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxKeyTo": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxPartial": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "confirmDialog.lblKey": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyBillAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyDescription": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyLoanEndDate": {
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyPartial": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyPayDate": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyPaying": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyPenalityAmount": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.lblKeyTo": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxButton": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToAccountDeatil": {
                        "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnBackToAccountSummary": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblTermsConditions": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxQuitPayment": {
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "height": {
                            "type": "string",
                            "value": "160%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "height": {
                            "type": "string",
                            "value": "540px"
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownTimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.50%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMyPaymentAccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPayDueAmount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "45.08%"
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.AllForms.flxInformationText": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "PayDueAmount"
                    },
                    "PayDueAmount.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.btnPayAmount": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxAmountDue": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxAmountOther": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxInfoDueAmount": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "48%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxInfoDueDate": {
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioPayDueAmount": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblInfoAmount": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "PayDueAmount.lblPayDueAmount": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.tbxOptional": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanPayOff": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblHeading1": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LoanPayOff.AllForms": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "top": {
                            "type": "string",
                            "value": "452dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "instanceId": "LoanPayOff"
                    },
                    "LoanPayOff.btnCancel": {
                        "segmentProps": []
                    },
                    "LoanPayOff.btnCancelDetails": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.btnConfirm": {
                        "segmentProps": []
                    },
                    "LoanPayOff.btnContinueDetails": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxCalendar": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LoanPayOff.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblAgree": {
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentBalanceLabel": {
                        "left": {
                            "type": "string",
                            "value": "74.66%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentBalanceValue": {
                        "left": {
                            "type": "string",
                            "value": "74.66%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentDueLabel": {
                        "left": {
                            "type": "string",
                            "value": "44.88%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentDueValue": {
                        "left": {
                            "type": "string",
                            "value": "44.88%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblFrom": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblLoanEndDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblLoanPayOffAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOffPenality": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblToValue": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestLabel": {
                        "left": {
                            "type": "string",
                            "value": "74.66%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestValue": {
                        "left": {
                            "type": "string",
                            "value": "74.66%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalLabel": {
                        "left": {
                            "type": "string",
                            "value": "44.88%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalValue": {
                        "left": {
                            "type": "string",
                            "value": "44.88%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblWarningSecond": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.listbxFrom": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxActualLoanEndDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxLoanPayOffAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxOptional": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.tbxPayoffPenality": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSecondaryActions": {
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxConfirmation": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblConfirmationTitle": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxMainConfirmation": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "49%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "26%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmHeaders.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxActualEndDateValue": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerBalanceAmount": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerPartialDate": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerYouArePaying": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxContainerYourBill": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCurrentBalanceValue": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxError": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxFromValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyAmount": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyDate": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxKeyPaymentDate": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxLeft": {
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxMainWrapper": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmation.flxPartialPayment": {
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPartialPaymentdetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffDateValue": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxPayOffPenalityValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxRateValue": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxSeparator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxToValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalInterestValue": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxTotalPrincipalValue": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValue": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueAmount": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueDate": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValuePaymentDate": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxValueTo": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxWrapper": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "confirmation.imgError": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblActualEndDateValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblCurrentBalanceValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblError": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblFromValue": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblPayOffAmountValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblPayOffDateValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblPayOffPenalityValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblRateValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblToValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblTotalInterestValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblTotalPrincipalValue": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementTitle": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainAcknowledgment": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "instanceId": "acknowledgment"
                    },
                    "acknowledgment.flxSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.flxWrapper": {
                        "segmentProps": []
                    },
                    "confirmDialog": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "instanceId": "confirmDialog"
                    },
                    "confirmDialog.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxHorizontalLine": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxPartial": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "confirmDialog.flxSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "flxButton": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "reverseLayoutDirection": true,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToAccountDeatil": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                        "segmentProps": []
                    },
                    "btnBackToAccountSummary": {
                        "bottom": {
                            "type": "string",
                            "value": "20px"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxQuitPayment": {
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "height": {
                            "type": "string",
                            "value": "540px"
                        },
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxDownTimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMyPaymentAccounts": {
                        "height": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.50%"
                        },
                        "segmentProps": []
                    },
                    "flxPayDueAmount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount": {
                        "segmentProps": [],
                        "instanceId": "PayDueAmount"
                    },
                    "PayDueAmount.btnPayAmount": {
                        "segmentProps": []
                    },
                    "PayDueAmount.flxAmountDue": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxAmountOther": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioPayDueAmount": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblInfoAmount": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "48%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanPayOff": {
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeading1": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "LoanPayOff"
                    },
                    "LoanPayOff.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LoanPayOff.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentBalanceLabel": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentBalanceValue": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentDueLabel": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblCurrentDueValue": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblLoanEndDate": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblNote": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOffPenality": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOn": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblToValue": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestLabel": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestValue": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalLabel": {
                        "left": {
                            "type": "string",
                            "value": "47.87%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalValue": {
                        "left": {
                            "type": "string",
                            "value": "47.87%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblWarningSecond": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSecondaryActions": {
                        "segmentProps": []
                    },
                    "btnPayDueAccount": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSeparatorPrimaryActions": {
                        "segmentProps": []
                    },
                    "btnViewAccountDetail": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "btnViewStatement": {
                        "isVisible": false,
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "flxConfirmation": {
                        "segmentProps": []
                    },
                    "lblConfirmationTitle": {
                        "segmentProps": []
                    },
                    "flxMainConfirmation": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCheckbox": {
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxHorizontalLine": {
                        "segmentProps": []
                    },
                    "confirmation.flxLeft": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxToValue": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblFavoriteEmailCheckBoxMain": {
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementTitle": {
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainAcknowledgment": {
                        "segmentProps": []
                    },
                    "acknowledgment": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "acknowledgment"
                    },
                    "acknowledgment.confirmHeaders": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "confirmDialog": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "confirmDialog"
                    },
                    "flxButton": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "reverseLayoutDirection": true,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToAccountDeatil": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "skin": "sknBtnSSPBg0273e3Border0273e3",
                        "segmentProps": []
                    },
                    "btnBackToAccountSummary": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnSSPBg0273e3Border0273e3",
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.90%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "height": {
                            "type": "string",
                            "value": "540px"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "540dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxDownTimeWarning": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "flxMyPaymentAccounts": {
                        "height": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxPayDueAmount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "PayDueAmount"
                    },
                    "PayDueAmount.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "205dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.btnPayAmount": {
                        "right": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxAmountDue": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxAmountOther": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxContent": {
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxInfoDueAmount": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxInfoDueDate": {
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioPayDueAmount": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxRadioPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": "49%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.lblPayDueAmount": {
                        "segmentProps": []
                    },
                    "PayDueAmount.lblPayOtherAmount": {
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "PayDueAmount.tbxOptional": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanPayOff": {
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeading1": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "17.61%"
                        },
                        "top": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "instanceId": "LoanPayOff"
                    },
                    "LoanPayOff.btnContinueDetails": {
                        "segmentProps": []
                    },
                    "LoanPayOff.flxContent": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.flxError": {
                        "segmentProps": []
                    },
                    "LoanPayOff.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "LoanPayOff.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblLoanEndDate": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblNote": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOffPenality": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblPayOn": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblToValue": {
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestLabel": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalInterestValue": {
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalLabel": {
                        "left": {
                            "type": "string",
                            "value": "47.87%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblTotalPrincipalValue": {
                        "left": {
                            "type": "string",
                            "value": "47.87%"
                        },
                        "segmentProps": []
                    },
                    "LoanPayOff.lblWarningSecond": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSecondaryActions": {
                        "segmentProps": []
                    },
                    "btnPayDueAccount": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "flxPrimaryActions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "btnViewAccountDetail": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "btnViewStatement": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "flxConfirmation": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmationTitle": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainConfirmation": {
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.77%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxCheckbox": {
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxHorizontalLine": {
                        "segmentProps": []
                    },
                    "confirmation.flxLeft": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.flxToValue": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "confirmation.lblFavoriteEmailCheckBoxMain": {
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblAcknowledgementTitle": {
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainAcknowledgment": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "acknowledgment"
                    },
                    "acknowledgment.flxBalance": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmDialog": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "confirmDialog"
                    },
                    "flxButton": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "reverseLayoutDirection": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "btnBackToAccountDeatil": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "83px"
                        },
                        "skin": "sknBtnSSPBg0273e3Border0273e3",
                        "segmentProps": []
                    },
                    "btnBackToAccountSummary": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "skin": "sknBtnSSPBg0273e3Border0273e3",
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "segmentProps": []
                    },
                    "flxTermsConditions": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxQuitPayment": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTC": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "height": {
                            "type": "string",
                            "value": "540px"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "mypaymentAccounts.lblHeading": {
                    "left": "30px"
                },
                "mypaymentAccounts.segMypaymentAccounts": {
                    "data": [{
                        "lblAccountName": "Personal Chekcing....1234",
                        "lblAvailableBalance": "Available Balance",
                        "lblBalance": "$6453.90",
                        "lblLeft": " "
                    }, {
                        "lblAccountName": "Personal Chekcing....1234",
                        "lblAvailableBalance": "Available Balance",
                        "lblBalance": "$6453.90",
                        "lblLeft": " "
                    }, {
                        "lblAccountName": "Personal Chekcing....1234",
                        "lblAvailableBalance": "Available Balance",
                        "lblBalance": "$6453.90",
                        "lblLeft": " "
                    }, {
                        "lblAccountName": "Personal Chekcing....1234",
                        "lblAvailableBalance": "Available Balance",
                        "lblBalance": "$6453.90",
                        "lblLeft": " "
                    }]
                },
                "PayDueAmount.AllForms": {
                    "left": "39.08%",
                    "top": "240dp"
                },
                "PayDueAmount.AllForms.RichTextInfo": {
                    "text": "You cannot pay more than the due amount.</br></br>You cannot make  an ad-hoc payment more than 'X' number of times in an year etc.</br></br>You cannot Pay-Off loan for a particular arrangement depending on the rules. E.g. if the account was opened in less than 6 months."
                },
                "PayDueAmount.AllForms.RichTextInfoArabic": {
                    "text": " لا يمكنك دفع أكثر من المبلغ المستحق. </br> </br> لا يمكنك إجراء دفعة مخصصة أكثر من \"X\" عدد المرات في السنة وما إلى ذلك. </br> </br> لا يمكنك الدفع- قرض خارج الترتيب لترتيب معين حسب القواعد. على سبيل المثال إذا تم فتح الحساب في أقل من 6 أشهر."
                },
                "PayDueAmount.AllForms.flxInformationText": {
                    "top": "-2dp"
                },
                "PayDueAmount.AllForms.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "PayDueAmount.AllForms.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "PayDueAmount.CalendarSendDate": {
                    "width": "100%"
                },
                "PayDueAmount": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "45dp",
                    "width": "100%"
                },
                "PayDueAmount.btnCancel": {
                    "bottom": "20dp"
                },
                "PayDueAmount.btnPayAmount": {
                    "bottom": "20dp",
                    "top": "0dp"
                },
                "PayDueAmount.flxAmountDue": {
                    "left": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FREE_FORM
                },
                "PayDueAmount.flxAmountOther": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FREE_FORM
                },
                "PayDueAmount.flxButtons": {
                    "top": "30dp"
                },
                "PayDueAmount.flxCalender": {
                    "height": "40dp"
                },
                "PayDueAmount.flxContent": {
                    "zIndex": 1
                },
                "PayDueAmount.flxDueAmount": {
                    "top": "11dp"
                },
                "PayDueAmount.flxImgInfoIcon": {
                    "left": "44%"
                },
                "PayDueAmount.flxInfoDueDate": {
                    "right": ""
                },
                "PayDueAmount.flxRadioButtons": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "PayDueAmount.flxRadioPayDueAmount": {
                    "left": "2.50%"
                },
                "PayDueAmount.flxRadioPayOtherAmount": {
                    "left": "24%"
                },
                "PayDueAmount.flxSeparator2": {
                    "left": "",
                    "top": "30dp",
                    "width": "95%"
                },
                "PayDueAmount.flxtxtbox": {
                    "width": "46.60%"
                },
                "PayDueAmount.imgError": {
                    "src": "error_yellow.png"
                },
                "PayDueAmount.imgInfoIcon": {
                    "src": "info_grey.png"
                },
                "PayDueAmount.imgRadioPayDueAmount": {
                    "src": "radio_butn_active.png"
                },
                "PayDueAmount.imgRadioPayOtherAmount": {
                    "src": "icon_radiobtn.png"
                },
                "PayDueAmount.lblDueAmount": {
                    "right": ""
                },
                "PayDueAmount.lblDueDate": {
                    "right": ""
                },
                "PayDueAmount.lblDueDate1": {
                    "left": "0%",
                    "right": ""
                },
                "PayDueAmount.lblDueDate2": {
                    "left": "0%",
                    "right": ""
                },
                "PayDueAmount.lblError": {
                    "left": "70dp",
                    "width": "85%"
                },
                "PayDueAmount.lblInfoAmount": {
                    "left": "0%",
                    "right": "",
                    "text": "et",
                    "width": "100%"
                },
                "PayDueAmount.lblNote": {
                    "top": "20dp",
                    "zIndex": 1
                },
                "PayDueAmount.lblPayDueAmount": {
                    "left": "6.50%"
                },
                "PayDueAmount.lblPayOtherAmount": {
                    "left": "28%"
                },
                "PayDueAmount.lblSend": {
                    "top": "20dp"
                },
                "PayDueAmount.lblTo": {
                    "top": "20dp"
                },
                "PayDueAmount.listbxFrom": {
                    "top": "10dp"
                },
                "PayDueAmount.listbxTo": {
                    "top": "10dp"
                },
                "PayDueAmount.tbxAmount": {
                    "left": "0%",
                    "width": "100%"
                },
                "PayDueAmount.tbxOptional": {
                    "top": "10dp",
                    "width": "95.50%"
                },
                "LoanPayOff.AllForms": {
                    "left": "3.78%",
                    "top": "530dp"
                },
                "LoanPayOff.AllForms.RichTextInfo": {
                    "left": "7.80%",
                    "top": "0dp"
                },
                "LoanPayOff.AllForms.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "LoanPayOff.AllForms.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "LoanPayOff.CalenderPayOffDate": {
                    "width": "100%"
                },
                "LoanPayOff.btnCancel": {
                    "height": "40dp",
                    "top": "672px"
                },
                "LoanPayOff.btnCancelDetails": {
                    "bottom": "20dp",
                    "centerX": "",
                    "height": "40dp",
                    "left": "",
                    "right": "205dp",
                    "top": "0dp",
                    "width": "150dp"
                },
                "LoanPayOff.btnConfirm": {
                    "height": "40dp",
                    "top": "672px"
                },
                "LoanPayOff.btnContinueDetails": {
                    "bottom": "20dp",
                    "centerX": "",
                    "height": "40dp",
                    "left": "",
                    "right": "35dp",
                    "top": "0dp",
                    "width": "150dp"
                },
                "LoanPayOff.flxBottomDetails": {
                    "minHeight": "",
                    "top": "0dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "LoanPayOff.flxButtons": {
                    "centerX": "",
                    "centerY": "",
                    "height": "60dp",
                    "left": "0dp",
                    "top": "30dp",
                    "width": "100%",
                    "zIndex": 2,
                    "layoutType": kony.flex.FREE_FORM
                },
                "LoanPayOff.flxCalender": {
                    "width": "45.34%"
                },
                "LoanPayOff.flxContentDuplicate": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "LoanPayOff.flxDetails": {
                    "left": "3.70%",
                    "minHeight": "",
                    "top": "20dp"
                },
                "LoanPayOff.flxError": {
                    "height": "62dp",
                    "left": "0.00%",
                    "top": "0dp",
                    "width": "100.00%"
                },
                "LoanPayOff.flxTopDetails": {
                    "bottom": "20dp",
                    "centerX": "50%",
                    "minHeight": "",
                    "top": "0dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "LoanPayOff.flxWarningMessage": {
                    "height": "50dp"
                },
                "LoanPayOff.imgCheckbox": {
                    "src": "unchecked_box.png"
                },
                "LoanPayOff.imgError": {
                    "src": "error_yellow.png"
                },
                "LoanPayOff.imgInfo": {
                    "src": "info_large.png"
                },
                "LoanPayOff.imgInfoIcon": {
                    "src": "info_grey.png"
                },
                "LoanPayOff.imgInfoIcon1": {
                    "src": "info_grey.png"
                },
                "LoanPayOff.imgInfoflx": {
                    "src": "info_large.png"
                },
                "LoanPayOff.imgLoadingIndicatorTo": {
                    "src": "rb_4_0_ad_loading_indicator.gif"
                },
                "LoanPayOff.imgWarning": {
                    "src": "bluealert_2.png"
                },
                "LoanPayOff.lblActualLoanEndDate": {
                    "left": 30,
                    "top": "10dp"
                },
                "LoanPayOff.lblActualLoanEndDateValue": {
                    "bottom": "",
                    "left": 30,
                    "top": "30dp"
                },
                "LoanPayOff.lblCurrentBalanceLabel": {
                    "left": "78.65%",
                    "top": "20dp"
                },
                "LoanPayOff.lblCurrentBalanceValue": {
                    "left": "78.65%",
                    "top": "40dp"
                },
                "LoanPayOff.lblCurrentDueLabel": {
                    "centerX": "",
                    "left": "47.87%",
                    "top": "20dp"
                },
                "LoanPayOff.lblCurrentDueValue": {
                    "centerX": "",
                    "left": "47.87%",
                    "top": "40dp"
                },
                "LoanPayOff.lblError": {
                    "left": "20dp"
                },
                "LoanPayOff.lblHeader": {
                    "centerY": "50%",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "top": ""
                },
                "LoanPayOff.lblToLabel": {
                    "left": "30dp",
                    "top": "20dp"
                },
                "LoanPayOff.lblToValue": {
                    "left": 30,
                    "top": "35dp"
                },
                "LoanPayOff.lblToValueDetails": {
                    "left": 30,
                    "top": "60dp"
                },
                "LoanPayOff.lblTotalInterestLabel": {
                    "left": "78.65%",
                    "top": "10dp"
                },
                "LoanPayOff.lblTotalInterestValue": {
                    "bottom": "",
                    "left": "78.65%",
                    "top": "30dp"
                },
                "LoanPayOff.lblTotalPrincipalLabel": {
                    "left": 350,
                    "top": "10dp"
                },
                "LoanPayOff.lblTotalPrincipalValue": {
                    "bottom": "",
                    "left": 350,
                    "top": "30dp"
                },
                "LoanPayOff.lblWarningSecond": {
                    "bottom": "",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "LoanPayOff.listbxFromDetails": {
                    "width": "92.53%"
                },
                "LoanPayOff.tbxLoanPayOffAmountValue": {
                    "width": "45.34%"
                },
                "LoanPayOff.tbxPayoffPenalityValue": {
                    "width": "45.34%"
                },
                "confirmation.btnTermsAndConditions": {
                    "top": "26dp"
                },
                "confirmation": {
                    "minHeight": ""
                },
                "confirmation.flxActualEndDateDetails": {
                    "left": "20dp",
                    "top": "20dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxActualEndDateKey": {
                    "left": "0dp"
                },
                "confirmation.flxActualEndDateValue": {
                    "left": "35%",
                    "top": "0dp",
                    "width": "250dp"
                },
                "confirmation.flxCenterDetails": {
                    "centerX": "",
                    "height": "296dp",
                    "left": "49.91%",
                    "width": "1dp"
                },
                "confirmation.flxCheckbox": {
                    "left": "2.50%",
                    "top": "20dp",
                    "width": "20dp"
                },
                "confirmation.flxCurrentBalanceDetails": {
                    "left": "20dp",
                    "minHeight": "",
                    "top": "20dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxCurrentBalanceKey": {
                    "left": "0dp"
                },
                "confirmation.flxCurrentBalanceValue": {
                    "left": "35%",
                    "top": "0dp",
                    "width": "250dp"
                },
                "confirmation.flxError": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxFromDetails": {
                    "left": "20dp",
                    "top": "20dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxFromKey": {
                    "left": "0dp"
                },
                "confirmation.flxFromValue": {
                    "left": "25%",
                    "top": "0dp",
                    "width": "400dp"
                },
                "confirmation.flxIAgree": {
                    "top": "250dp"
                },
                "confirmation.flxLateFeeValue": {
                    "left": "16%",
                    "top": "0dp",
                    "width": "30%"
                },
                "confirmation.flxLatePaymentChargeDetails": {
                    "bottom": "",
                    "minHeight": "",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxLeftDetails": {
                    "left": "2.20%",
                    "minHeight": "",
                    "width": "47%"
                },
                "confirmation.flxMainWrapper": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxPayOffAmountDetails": {
                    "left": "20dp",
                    "minHeight": "",
                    "top": "20dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxPayOffAmountKey": {
                    "left": "0dp"
                },
                "confirmation.flxPayOffAmountValue": {
                    "left": "25%",
                    "top": "0dp",
                    "width": "30%"
                },
                "confirmation.flxPayOffDateDetails": {
                    "left": "20dp",
                    "minHeight": "",
                    "minWidth": "",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxPayOffDateKey": {
                    "left": "0dp"
                },
                "confirmation.flxPayOffDateValue": {
                    "left": "35%",
                    "top": "0dp",
                    "width": "250dp"
                },
                "confirmation.flxPayOffPenalityDetails": {
                    "bottom": "",
                    "left": "20dp",
                    "minHeight": "",
                    "top": "20dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxPayOffPenalityKey": {
                    "left": "0dp"
                },
                "confirmation.flxPayOffPenalityValue": {
                    "left": "25%",
                    "top": "0dp",
                    "width": "30%"
                },
                "confirmation.flxRateDetails": {
                    "left": "20dp",
                    "minHeight": "",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxRateKey": {
                    "left": "0dp"
                },
                "confirmation.flxRateValue": {
                    "left": "35%",
                    "top": "0dp",
                    "width": "250dp"
                },
                "confirmation.flxRightDetails": {
                    "left": "51%",
                    "maxWidth": "",
                    "width": "47%"
                },
                "confirmation.flxToDetails": {
                    "left": "20dp",
                    "minHeight": "",
                    "top": "20dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxToKey": {
                    "left": "0dp"
                },
                "confirmation.flxToValue": {
                    "left": "25%",
                    "top": "0dp",
                    "width": "30%"
                },
                "confirmation.flxTotalInterestDetails": {
                    "left": "20dp",
                    "minHeight": "",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxTotalInterestKey": {
                    "left": "0dp"
                },
                "confirmation.flxTotalInterestValue": {
                    "left": "35%",
                    "top": "0dp",
                    "width": "250dp"
                },
                "confirmation.flxTotalPrincipalDetails": {
                    "left": "20dp",
                    "minHeight": "",
                    "layoutType": kony.flex.FREE_FORM
                },
                "confirmation.flxTotalPrincipalKey": {
                    "left": "0dp"
                },
                "confirmation.flxTotalPrincipalValue": {
                    "left": "35%",
                    "top": "0dp",
                    "width": "250dp"
                },
                "confirmation.imgError": {
                    "src": "error_yellow.png",
                    "width": "8.54%"
                },
                "confirmation.lblActualEndDateValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblAgree": {
                    "top": 21
                },
                "confirmation.lblCurrentBalanceValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblError": {
                    "left": "14.95%",
                    "width": "54.91%"
                },
                "confirmation.lblFavoriteEmailCheckBoxMain": {
                    "width": "20dp"
                },
                "confirmation.lblFromValue": {
                    "left": "0dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblKey": {
                    "left": "0",
                    "right": ""
                },
                "confirmation.lblKeyDescription": {
                    "text": "Notes:"
                },
                "confirmation.lblPayOffAmountValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblPayOffDateValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblPayOffPenalityValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblRateValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblToValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblTotalInterestValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "confirmation.lblTotalPrincipalValue": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "acknowledgment.ImgAcknowledged": {
                    "height": "72dp",
                    "src": "success_green.png",
                    "top": "220dp"
                },
                "acknowledgment": {
                    "left": "6.07%",
                    "minHeight": "400px",
                    "minWidth": "",
                    "top": "0dp",
                    "width": "43.26%"
                },
                "acknowledgment.flxWrapper": {
                    "bottom": ""
                },
                "acknowledgment.lblTransactionMessage": {
                    "text": "Label",
                    "top": "78px",
                    "width": "90%"
                },
                "confirmDialog": {
                    "left": "50.58%",
                    "minHeight": "",
                    "minWidth": "",
                    "width": "43.26%"
                },
                "confirmDialog.flxKeyBalanceAmount": {
                    "width": "27%"
                },
                "confirmDialog.flxKeyPayDate": {
                    "width": "20%"
                },
                "confirmDialog.flxKeyPayoffCharges": {
                    "top": "0dp",
                    "width": "18%"
                },
                "confirmDialog.flxKeyPayoffamount": {
                    "top": "0dp",
                    "width": "18%"
                },
                "confirmDialog.flxMain": {
                    "bottom": ""
                },
                "confirmDialog.flxPartial": {
                    "height": "215dp"
                },
                "confirmDialog.flxValue": {
                    "width": "62%"
                },
                "confirmDialog.flxValueAmount": {
                    "width": "62%"
                },
                "confirmDialog.flxValueDescription": {
                    "width": "62%"
                },
                "confirmDialog.flxValueLoanEndDate": {
                    "width": "62%"
                },
                "confirmDialog.flxValueTo": {
                    "width": "62%"
                },
                "confirmDialog.lblKeyBalanceAmount": {
                    "width": "100%"
                },
                "confirmDialog.lblKeyLoanEndDate": {
                    "text": "Actual Loan End Date:",
                    "width": "100%"
                },
                "confirmDialog.lblKeyPayoffCharges": {
                    "width": "95%"
                },
                "confirmDialog.lblKeypayoffamount": {
                    "width": "95%"
                },
                "confirmDialog.lblValue": {
                    "width": "100%"
                },
                "confirmDialog.lblValueDescription": {
                    "text": "Car Loan EMI for July ",
                    "width": "100%"
                },
                "confirmDialog.lblValueTo": {
                    "width": "100%"
                }
            }
            this.add(flxHeader, flxFormContent, flxQuitPaymentParent, flxLoading, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmPayDueAmount,
            "enabledForIdleTimeout": true,
            "id": "frmPayDueAmount",
            "init": controller.AS_Form_hb17e01c2e4a4390b09bb171c9e05d12,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});