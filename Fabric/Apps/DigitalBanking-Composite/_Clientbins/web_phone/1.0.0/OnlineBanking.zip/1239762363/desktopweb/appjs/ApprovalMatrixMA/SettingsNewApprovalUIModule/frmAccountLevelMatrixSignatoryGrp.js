define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmAccountLevelMatrixSignatoryGrp", function() {
    return function(controller) {
        function addWidgetsfrmAccountLevelMatrixSignatoryGrp() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var lblAccountLevelHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Add Recipient - Acknowledgement"
                },
                "height": "25px",
                "id": "lblAccountLevelHeading",
                "isVisible": true,
                "left": "91px",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.accountLevelHeader\")",
                "top": "26px",
                "width": "88%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var FlexWrapper = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "800dp",
                "id": "FlexWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90px",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "22px",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexWrapper.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "700dp",
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var lblViewApprovalMatrix = new kony.ui.Label({
                "height": "20dp",
                "id": "lblViewApprovalMatrix",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalmatrix.editAccountLevelHeader\")",
                "top": "16dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "21dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "14dp",
                "width": "1155px",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var Search = new com.InfinityOLB.ApprovalMatrixMA.BillPay.Search({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "70dp",
                "id": "Search",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA",
                "overrides": {
                    "Search": {
                        "height": "70dp",
                        "left": "0px",
                        "top": "20dp",
                        "width": "100%"
                    },
                    "btnConfirm": {
                        "width": "40dp"
                    },
                    "flxClearBtn": {
                        "isVisible": false
                    },
                    "flxtxtSearchandClearbtn": {
                        "height": "40dp",
                        "left": "21dp",
                        "width": "96%"
                    },
                    "imgCross": {
                        "src": "icon_close_grey_2.png"
                    },
                    "lblSearch": {
                        "text": "e",
                        "top": "viz.val_cleared",
                        "width": "20dp"
                    },
                    "txtSearch": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvalsAccountLevel.searchaccountname\")",
                        "placeholder": "Search by account name,  number and type"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSearchSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSearchSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "5dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchSeparator.setDefaultUnit(kony.flex.DP);
            flxSearchSeparator.add();
            var TabBodyNew = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabBodyNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "top": "0dp",
                        "width": "100%"
                    },
                    "segTemplates": {
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxNoRecords",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoRecords.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "height": "50dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "4%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "32dp",
                "width": "6.30%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxNoRecordsMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "No transactions found."
                },
                "id": "rtxNoRecordsMessage",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.NotificationsAndMessages.noRecords\")",
                "top": "41dp",
                "width": "87.94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblScheduleAPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")"
                },
                "id": "lblScheduleAPayment",
                "isVisible": false,
                "left": "12.60%",
                "skin": "sknSSP3343ABpx24",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")",
                "top": "107dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "MAKE TRANSFER"
            });
            flxNoRecords.add(imgInfo, rtxNoRecordsMessage, lblScheduleAPayment);
            flxMainWrapper.add(lblViewApprovalMatrix, flxSeparator, Search, flxSearchSeparator, TabBodyNew, flxNoRecords);
            var flxBackContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainer.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50.00%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainer.add(lblBottomSeparator, btnBack);
            FlexWrapper.add(flxMainWrapper, flxBackContainer);
            flxMainContent.add(lblAccountLevelHeading, flxDowntimeWarning, FlexWrapper);
            flxMain.add(flxMainContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1000dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "103%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternewAM": {
                        "centerX": "viz.val_cleared",
                        "left": "6dp",
                        "width": "103%"
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblAccountLevelHeading": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "Search.btnConfirm": {
                        "segmentProps": []
                    },
                    "Search.btnConfirm1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Search.flxClearBtn": {
                        "right": {
                            "type": "string",
                            "value": "3.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "Search.flxtxtSearchandClearbtn": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "Search.txtSearch": {
                        "width": {
                            "type": "string",
                            "value": "86%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "Transfer",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMainContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountLevelHeading": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "FlexWrapper": {
                        "height": {
                            "type": "string",
                            "value": "1140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.06%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "Search.flxtxtSearchandClearbtn": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "Search.lblSearch": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "Search.txtSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "rtxNoRecordsMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "i18n_text": "i18n.NotificationsAndMessages.noRecords",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblBottomSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "115%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblAccountLevelHeading": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxNoRecords": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "-37dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "104%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "Search": {
                    "height": "70dp",
                    "left": "0px",
                    "top": "20dp",
                    "width": "100%"
                },
                "Search.btnConfirm": {
                    "width": "40dp"
                },
                "Search.flxtxtSearchandClearbtn": {
                    "height": "40dp",
                    "left": "21dp",
                    "width": "96%"
                },
                "Search.imgCross": {
                    "src": "icon_close_grey_2.png"
                },
                "Search.lblSearch": {
                    "text": "e",
                    "top": "",
                    "width": "20dp"
                },
                "Search.txtSearch": {
                    "height": "40dp"
                },
                "TabBodyNew": {
                    "top": "0dp",
                    "width": "100%"
                },
                "TabBodyNew.segTemplates": {
                    "width": "100%"
                },
                "customfooternew": {
                    "centerX": "",
                    "left": "6dp",
                    "width": "103%"
                },
                "customfooternew.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                }
            }
            this.add(flxHeader, flxFormContent);
        };
        return [{
            "addWidgets": addWidgetsfrmAccountLevelMatrixSignatoryGrp,
            "enabledForIdleTimeout": true,
            "id": "frmAccountLevelMatrixSignatoryGrp",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_hca9410b922e43a9a5fefec3186383d3,
            "preShow": function(eventobject) {
                controller.AS_Form_a96816e5c2b148fcb537df6aed3256b7(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_f768b26bdc23445f913cd678b31b0b84,
            "retainScrollPosition": false
        }]
    }
});