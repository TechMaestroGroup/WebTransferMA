define("ArrangementsMA/MortgageServicesUIModule/frmConfirmRepaymentAccount", function() {
    return function(controller) {
        function addWidgetsfrmConfirmRepaymentAccount() {
            this.setDefaultUnit(kony.flex.DP);
            var formConfirmRepaymentAccount = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formConfirmRepaymentAccount",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formConfirmRepaymentAccount",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formConfirmRepaymentAccount_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmConfirmRepaymentAccount"] && appConfig.componentMetadata["ResourcesMA"]["frmConfirmRepaymentAccount"]["formConfirmRepaymentAccount"]) || {};
            formConfirmRepaymentAccount.serviceParameters = formConfirmRepaymentAccount_data.serviceParameters || {};
            formConfirmRepaymentAccount.customPopupData = formConfirmRepaymentAccount_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formConfirmRepaymentAccount.dataFormatting = formConfirmRepaymentAccount_data.dataFormatting || {};
            formConfirmRepaymentAccount.dataMapping = formConfirmRepaymentAccount_data.dataMapping || {};
            formConfirmRepaymentAccount.conditionalMappingKey = formConfirmRepaymentAccount_data.conditionalMappingKey || "";
            formConfirmRepaymentAccount.conditionalMapping = formConfirmRepaymentAccount_data.conditionalMapping || {};
            formConfirmRepaymentAccount.pageTitle = formConfirmRepaymentAccount_data.pageTitle || "Confirm Repayment Account";
            formConfirmRepaymentAccount.pageTitlei18n = formConfirmRepaymentAccount_data.pageTitlei18n || "";
            formConfirmRepaymentAccount.primaryLinks = formConfirmRepaymentAccount_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formConfirmRepaymentAccount.flxMainWrapperzIndex = formConfirmRepaymentAccount_data.flxMainWrapperzIndex || 2;
            formConfirmRepaymentAccount.secondaryLinks = formConfirmRepaymentAccount_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formConfirmRepaymentAccount.supplementaryLinks = formConfirmRepaymentAccount_data.supplementaryLinks || [];
            formConfirmRepaymentAccount.pageTitleVisibility = formConfirmRepaymentAccount_data.pageTitleVisibility || true;
            formConfirmRepaymentAccount.logoConfig = formConfirmRepaymentAccount_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formConfirmRepaymentAccount.accountText = formConfirmRepaymentAccount_data.accountText || "";
            formConfirmRepaymentAccount.logoutConfig = formConfirmRepaymentAccount_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formConfirmRepaymentAccount.profileConfig = formConfirmRepaymentAccount_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formConfirmRepaymentAccount.activeMenuID = formConfirmRepaymentAccount_data.activeMenuID || "";
            formConfirmRepaymentAccount.activeSubMenuID = formConfirmRepaymentAccount_data.activeSubMenuID || "";
            formConfirmRepaymentAccount.backFlag = formConfirmRepaymentAccount_data.backFlag || false;
            formConfirmRepaymentAccount.hamburgerConfig = formConfirmRepaymentAccount_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formConfirmRepaymentAccount.backProperties = formConfirmRepaymentAccount_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formConfirmRepaymentAccount.breadCrumbProperties = formConfirmRepaymentAccount_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formConfirmRepaymentAccount.genricMessage = formConfirmRepaymentAccount_data.genricMessage || {};
            formConfirmRepaymentAccount.sessionTimeOutData = formConfirmRepaymentAccount_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formConfirmRepaymentAccount.footerProperties = formConfirmRepaymentAccount_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formConfirmRepaymentAccount.copyRight = formConfirmRepaymentAccount_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirm.setDefaultUnit(kony.flex.DP);
            var flxAccDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAccDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccDetails.setDefaultUnit(kony.flex.DP);
            var lblAccountDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblAccountDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "lblSeparator",
                "isVisible": true,
                "left": "30dp",
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "49dp",
                "width": "94%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccDetails.add(lblAccountDetails, lblSeparator);
            var flxAccountDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountDetails.setDefaultUnit(kony.flex.DP);
            var flxAccDetHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "div"
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAccDetHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccDetHeader.setDefaultUnit(kony.flex.DP);
            var lblCurAccDet = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "tagName": "h3"
                },
                "id": "lblCurAccDet",
                "isVisible": true,
                "left": "310dp",
                "skin": "ICSknlbl424242SSP13pxSemibold",
                "text": "Current Account Detail",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAccDet = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "lblNewAccDet",
                "isVisible": true,
                "left": "677dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.NewAccountDetail\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccDetHeader.add(lblCurAccDet, lblNewAccDet);
            var lbSepMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lbSepMobile",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccHold = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAccHold",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccHold.setDefaultUnit(kony.flex.DP);
            var lblAccHoldName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblAccHoldName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountHolderNameWithColon\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal1",
                "isVisible": true,
                "left": "310dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal2",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Daisy Davis",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccHold.add(lblAccHoldName, lblVal1, lblVal2);
            var flxAccNo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAccNo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccNo.setDefaultUnit(kony.flex.DP);
            var lblAccNo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblAccNo",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountNumberWithColon\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal3",
                "isVisible": true,
                "left": "310dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal4",
                "isVisible": true,
                "left": "677dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "9281 8900 8192 1211",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccNo.add(lblAccNo, lblVal3, lblVal4);
            var flxBICSwift = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxBICSwift",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBICSwift.setDefaultUnit(kony.flex.DP);
            var lblBICSWIFT = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblBICSWIFT",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.bicSwift\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal5",
                "isVisible": true,
                "left": "310dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "LB29NWBK60161331926819",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal6",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "MCRBRUMM000",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBICSwift.add(lblBICSWIFT, lblVal5, lblVal6);
            var flxBankName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxBankName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankName.setDefaultUnit(kony.flex.DP);
            var lblBankName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblBankName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payee.bankname\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal7 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal7",
                "isVisible": true,
                "left": "310dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Lloyds Banking Group",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVal8 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblVal8",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Bank of Moscow",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankName.add(lblBankName, lblVal7, lblVal8);
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountDetails.add(flxAccDetHeader, lbSepMobile, flxAccHold, flxAccNo, flxBICSwift, flxBankName, lblSeparator1);
            var flxNewAccDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNewAccDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewAccDetails.setDefaultUnit(kony.flex.DP);
            var flxNewAccDetHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxNewAccDetHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewAccDetHeader.setDefaultUnit(kony.flex.DP);
            var CopylblCurAccDet0e87a4f18c7a440 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "CopylblCurAccDet0e87a4f18c7a440",
                "isVisible": true,
                "left": "305dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.CurrentAccountDetail\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAccDet2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "id": "lblNewAccDet2",
                "isVisible": true,
                "left": "677dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.NewAccountDetail\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewAccDetHeader.add(CopylblCurAccDet0e87a4f18c7a440, lblNewAccDet2);
            var lblSep1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSep1",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNewAccHold = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxNewAccHold",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewAccHold.setDefaultUnit(kony.flex.DP);
            var lblNewAccHoldName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewAccHoldName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountHolderNameWithColon\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblVal0a1f565882f534f = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "CopylblVal0a1f565882f534f",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewVal2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewVal2",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Daisy Davis",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewAccHold.add(lblNewAccHoldName, CopylblVal0a1f565882f534f, lblNewVal2);
            var flxNewAccNo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxNewAccNo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewAccNo.setDefaultUnit(kony.flex.DP);
            var lblNewAccNo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewAccNo",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountNumberWithColon\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblVal0e1b0e90f7e864e = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "CopylblVal0e1b0e90f7e864e",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewVal4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewVal4",
                "isVisible": true,
                "left": "677dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "9281 8900 8192 1211",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewAccNo.add(lblNewAccNo, CopylblVal0e1b0e90f7e864e, lblNewVal4);
            var flxNewBICSwift = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxNewBICSwift",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewBICSwift.setDefaultUnit(kony.flex.DP);
            var lblNewBICSWIFT = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewBICSWIFT",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.bicSwift\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblVal0h8f4f8ee4afc41 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "CopylblVal0h8f4f8ee4afc41",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "LB29NWBK60161331926819",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewVal6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewVal6",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "MCRBRUMM000",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewBICSwift.add(lblNewBICSWIFT, CopylblVal0h8f4f8ee4afc41, lblNewVal6);
            var flxNewBankName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxNewBankName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewBankName.setDefaultUnit(kony.flex.DP);
            var lblNewBankName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewBankName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSkn727272SSPRegular13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payee.bankname\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblVal0db02025f943142 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "CopylblVal0db02025f943142",
                "isVisible": true,
                "left": "305dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Lloyds Banking Group",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewVal8 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNewVal8",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Bank of Moscow",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewBankName.add(lblNewBankName, CopylblVal0db02025f943142, lblNewVal8);
            var lblSep2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSep2",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewAccDetails.add(flxNewAccDetHeader, lblSep1, flxNewAccHold, flxNewAccNo, flxNewBICSwift, flxNewBankName, lblSep2);
            var flxSupportingDocsMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocsMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocsMain.setDefaultUnit(kony.flex.DP);
            var flxSuppDoc = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSuppDoc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDoc.setDefaultUnit(kony.flex.DP);
            var lblSuppDoc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSuppDoc",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unified.supportingDocuments\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "lblSeparator2",
                "isVisible": true,
                "left": "30dp",
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "35dp",
                "width": "94%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuppDoc.add(lblSuppDoc, lblSeparator2);
            var flxSupportingDocs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.setDefaultUnit(kony.flex.DP);
            var segSupportingDocs = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDoc": "",
                    "lblDocName": ""
                }],
                "groupCells": false,
                "id": "segSupportingDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSupportingDocs"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContentDocs": "flxContentDocs",
                    "flxGap": "flxGap",
                    "flxImgDoc": "flxImgDoc",
                    "flxSupportingDocs": "flxSupportingDocs",
                    "imgDoc": "imgDoc",
                    "lblDocName": "lblDocName"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.add(segSupportingDocs);
            var flxCheckBoxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCheckBoxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBoxMain.setDefaultUnit(kony.flex.DP);
            var flxCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-checked": false,
                        "aria-labelledby": "lblCheckMsg",
                        "role": "checkbox",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "21dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBox.setDefaultUnit(kony.flex.DP);
            var lblCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "lblCheckBox",
                "isVisible": true,
                "left": "0",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "D",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox.add(lblCheckBox);
            var lblCheckMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCheckMsg",
                "isVisible": true,
                "left": "56dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.AwareMessage\")",
                "top": "4dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "30dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            flxCheckBoxMain.add(flxCheckBox, lblCheckMsg, flxSeparator3);
            var flxConfirmAndModify = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "101dp",
                "id": "flxConfirmAndModify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmAndModify.setDefaultUnit(kony.flex.DP);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20dp",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnSubmit = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Confirm repayment account details"
                },
                "bottom": "20dp",
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnSubmit",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnSSPffffff15px0273e3bg",
                "text": "Confirm",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            var btnModify = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Modify repayment account details"
                },
                "centerY": "50.00%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "40dp",
                "id": "btnModify",
                "isVisible": true,
                "right": "200dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.modifiy\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel change repayment account process"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "380dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxButtons.add(btnSubmit, btnModify, btnCancel);
            flxConfirmAndModify.add(flxButtons);
            flxSupportingDocsMain.add(flxSuppDoc, flxSupportingDocs, flxCheckBoxMain, flxConfirmAndModify);
            flxConfirm.add(flxAccDetails, flxAccountDetails, flxNewAccDetails, flxSupportingDocsMain);
            formConfirmRepaymentAccount.flxContentTCCenter.add(flxConfirm);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formConfirmRepaymentAccount": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "skin": "ICSknFlxF7F8F7Border",
                        "segmentProps": []
                    },
                    "flxConfirm": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter"]
                    },
                    "flxAccDetails": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "lblAccountDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "text": "Repayment Account Details",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccDetails"]
                    },
                    "flxAccountDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "flxAccDetHeader": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "bbsknf8f7f8WithoutBorder",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblCurAccDet": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "tagName": "h3"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "Current Repayment Account ",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccDetHeader"]
                    },
                    "lblNewAccDet": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccDetHeader"]
                    },
                    "lbSepMobile": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "flxAccHold": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblAccHoldName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccHold"]
                    },
                    "lblVal1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccHold"]
                    },
                    "lblVal2": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccHold"]
                    },
                    "flxAccNo": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblAccNo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccNo"]
                    },
                    "lblVal3": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccNo"]
                    },
                    "lblVal4": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccNo"]
                    },
                    "flxBICSwift": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBICSwift"]
                    },
                    "lblVal5": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBICSwift"]
                    },
                    "lblVal6": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBICSwift"]
                    },
                    "flxBankName": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblBankName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBankName"]
                    },
                    "lblVal7": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBankName"]
                    },
                    "lblVal8": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBankName"]
                    },
                    "lblSeparator1": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "flxNewAccDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "flxNewAccDetHeader": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "bbsknf8f7f8WithoutBorder",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "CopylblCurAccDet0e87a4f18c7a440": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccDetHeader"]
                    },
                    "lblNewAccDet2": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "New Repayment Account",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccDetHeader"]
                    },
                    "lblSep1": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "flxNewAccHold": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblNewAccHoldName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccHold"]
                    },
                    "CopylblVal0a1f565882f534f": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccHold"]
                    },
                    "lblNewVal2": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccHold"]
                    },
                    "flxNewAccNo": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblNewAccNo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccNo"]
                    },
                    "CopylblVal0e1b0e90f7e864e": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccNo"]
                    },
                    "lblNewVal4": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccNo"]
                    },
                    "flxNewBICSwift": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblNewBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBICSwift"]
                    },
                    "CopylblVal0h8f4f8ee4afc41": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBICSwift"]
                    },
                    "lblNewVal6": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBICSwift"]
                    },
                    "flxNewBankName": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblNewBankName": {
                        "i18n_text": "i18n.payee.bankname",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBankName"]
                    },
                    "CopylblVal0db02025f943142": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBankName"]
                    },
                    "lblNewVal8": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBankName"]
                    },
                    "lblSep2": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "flxSupportingDocsMain": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "lblSuppDoc": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP13pxSemibold",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxSuppDoc"]
                    },
                    "lblSeparator2": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxSuppDoc"]
                    },
                    "flxCheckBoxMain": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "flxCheckBox": {
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxCheckBoxMain"]
                    },
                    "lblCheckMsg": {
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "I confirm that my co-borrower is aware of the change. ",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxCheckBoxMain"]
                    },
                    "flxSeparator3": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxCheckBoxMain"]
                    },
                    "flxConfirmAndModify": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify"]
                    },
                    "btnSubmit": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    }
                },
                "1024": {
                    "formConfirmRepaymentAccount": {
                        "skin": "ICSknFlxF7F8F7Border",
                        "segmentProps": []
                    },
                    "lblAccountDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.transfers.accountDetails",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "Account Details",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccDetails"]
                    },
                    "flxAccountDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "lblCurAccDet": {
                        "i18n_text": "i18n.accounts.CurrentAccountDetail",
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "text": "Current Account Detail",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccDetHeader"]
                    },
                    "lblNewAccDet": {
                        "i18n_text": "i18n.accounts.NewAccountDetail",
                        "left": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "text": "New Account Detail",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccDetHeader"]
                    },
                    "lbSepMobile": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblAccHoldName": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentAccountHolderNameWithColon",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Repayment Account Holder Name:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccHold"]
                    },
                    "lblVal1": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccHold"]
                    },
                    "lblVal2": {
                        "left": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccHold"]
                    },
                    "lblAccNo": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentAccountNumberWithColon",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Repayment Account Number:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccNo"]
                    },
                    "lblVal3": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccNo"]
                    },
                    "lblVal4": {
                        "left": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccNo"]
                    },
                    "lblBICSWIFT": {
                        "i18n_text": "kony.i18n.verifyDetails.bicSwift",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "BIC/SWIFT :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBICSwift"]
                    },
                    "lblVal5": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBICSwift"]
                    },
                    "lblVal6": {
                        "left": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBICSwift"]
                    },
                    "lblBankName": {
                        "i18n_text": "i18n.payee.bankname",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBankName"]
                    },
                    "lblVal7": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBankName"]
                    },
                    "lblVal8": {
                        "left": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxBankName"]
                    },
                    "lblSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "flxNewAccDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "CopylblCurAccDet0e87a4f18c7a440": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccDetHeader"]
                    },
                    "lblNewAccDet2": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccDetHeader"]
                    },
                    "lblSep1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblNewAccHoldName": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentAccountHolderNameWithColon",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Repayment Account Holder Name:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccHold"]
                    },
                    "CopylblVal0a1f565882f534f": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccHold"]
                    },
                    "lblNewVal2": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccHold"]
                    },
                    "lblNewAccNo": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentAccountNumberWithColon",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Repayment Account Number:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccNo"]
                    },
                    "CopylblVal0e1b0e90f7e864e": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccNo"]
                    },
                    "lblNewVal4": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccNo"]
                    },
                    "lblNewBICSWIFT": {
                        "i18n_text": "i18n.payments.bicSlashSwiftWithColon",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "BIC/SWIFT :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBICSwift"]
                    },
                    "CopylblVal0h8f4f8ee4afc41": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBICSwift"]
                    },
                    "lblNewVal6": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBICSwift"]
                    },
                    "lblNewBankName": {
                        "i18n_text": "i18n.transfers.bankName",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBankName"]
                    },
                    "CopylblVal0db02025f943142": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBankName"]
                    },
                    "lblNewVal8": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewBankName"]
                    },
                    "lblSep2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "flxSupportingDocsMain": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "flxSuppDoc": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "lblSuppDoc": {
                        "i18n_text": "i18n.unified.supportingDocuments",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Supporting Documents",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxSuppDoc"]
                    },
                    "lblSeparator2": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxSuppDoc"]
                    },
                    "flxSupportingDocs": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxSupportingDocs"]
                    },
                    "flxCheckBoxMain": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "lblCheckMsg": {
                        "i18n_text": "i18n.mortgageAccount.AwareMessage",
                        "text": "I confirm that my co-borrower is aware of the change. ",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxCheckBoxMain"]
                    },
                    "flxSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxCheckBoxMain"]
                    },
                    "flxConfirmAndModify": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "btnSubmit": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "i18n_text": "kony.mb.common.submit",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnModify": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "i18n_text": "i18n.common.modifiy",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "181dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "i18n_text": "i18n.konybb.common.cancel",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "342dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    }
                },
                "1366": {
                    "formConfirmRepaymentAccount": {
                        "backProperties": "{}",
                        "skin": "ICSknFlxF7F8F7Border",
                        "segmentProps": []
                    },
                    "flxConfirm": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter"]
                    },
                    "lblAccountDetails": {
                        "text": "Repayment Account Details",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccDetails"]
                    },
                    "lbSepMobile": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblAccHoldName": {
                        "text": "Repayment Account Holder Name:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccHold"]
                    },
                    "lblAccNo": {
                        "text": "Repayment Account Number:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails", "flxAccNo"]
                    },
                    "lblSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblSep1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblNewAccHoldName": {
                        "text": "Repayment Account Holder Name:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccHold"]
                    },
                    "lblNewAccNo": {
                        "text": "Repayment Account Number:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails", "flxNewAccNo"]
                    },
                    "lblSep2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "flxSupportingDocsMain": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm"]
                    },
                    "flxSuppDoc": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "lblSeparator2": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxSuppDoc"]
                    },
                    "flxSupportingDocs": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "number",
                            "value": "20"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "flxCheckBoxMain": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "lblCheckBox": {
                        "skin": "sknFontIconCheckBoxSelected",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxCheckBoxMain", "flxCheckBox"]
                    },
                    "flxSeparator3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxCheckBoxMain"]
                    },
                    "flxConfirmAndModify": {
                        "height": {
                            "type": "string",
                            "value": "91dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "flxButtons": {
                        "right": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify"]
                    },
                    "btnSubmit": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnModify": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    }
                },
                "1380": {
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccDetails"]
                    },
                    "lbSepMobile": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxAccountDetails"]
                    },
                    "lblSep1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblSep2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxNewAccDetails"]
                    },
                    "lblSeparator2": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxSuppDoc"]
                    },
                    "flxSupportingDocs": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "flxCheckBoxMain": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain"]
                    },
                    "btnSubmit": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnModify": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    },
                    "btnCancel": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formConfirmRepaymentAccount", "flxContentTCCenter", "flxConfirm", "flxSupportingDocsMain", "flxConfirmAndModify", "flxButtons"]
                    }
                }
            }
            this.compInstData = {
                "formConfirmRepaymentAccount": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formConfirmRepaymentAccount);
        };
        return [{
            "addWidgets": addWidgetsfrmConfirmRepaymentAccount,
            "enabledForIdleTimeout": true,
            "id": "frmConfirmRepaymentAccount",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_fee3dd8d2cfa4851899fac6dbe782cc1(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});