define("OpenBankingMA/OpenBankingUIModule/userfrmConsentVerifyDetailsController", ['CommonUtilities', 'OLBConstants', 'FormControllerUtility', 'ViewConstants', 'CampaignUtility'], function(CommonUtilities, OLBConstants, FormControllerUtility, ViewConstants, CampaignUtility) {
    return {
        frmConsentVerifyDetailsInit: function() {
            this.view.preShow = this.preShow;
            this.view.postShow = this.postShow;
        },
        onNavigate: function(context) {
            if (!kony.sdk.isNullOrUndefined(context)) {
                this.context = context;
            }
        },
        loadOBModule: function() {
            return kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("OpenBankingUIModule");
        },
        preShow: function() {
            try {
                kony.print("Entered onpreShow");
                this.setPreShowData();
                this.setFlowActions();
            } catch (e) {
                kony.print("Exception in onpreShow" + e);
            }
        },
        postShow: function() {
            let navManager = applicationManager.getNavigationManager();
            let dataList = navManager.getCustomInfo("frmPaymentConsent");
            let data = dataList[0];
            if (data.isScheduled === "true") {
                this.view.lblFutureDate.text = kony.i18n.getLocalizedString("i18n.tppConsent.paymentMadeOn") + " " + data.transactionDate;
            }
        },
        setFlowActions: function() {
            let self = this;
            this.view.btnApprove.onClick = this.onApprove;
            this.view.btnReject.onClick = () => this.toggleRejectPopup(true);
            this.view.btnNo.onClick = () => this.toggleRejectPopup(false);
            this.view.btnYes.onClick = this.onReject;
            this.view.btnClose.onClick = () => this.toggleRejectPopup(false);
        },
        /**
         * Toggles the Reject popup.
         * @param {boolean} visibility - Specfies whether to show/hide Reject popup.
         * @returns {void} - Returns nothing if visibility is false.
         */
        toggleRejectPopup: function(visibility) {
            this.view.flxRejectPopup.setVisibility(visibility);
        },
        setPreShowData: function() {
            var psdMode = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "OpenBankingUIModule",
                "appName": "OpenBankingMA"
            });
            let navManager = applicationManager.getNavigationManager();
            var forUtility = applicationManager.getFormatUtilManager();
            let dataList = navManager.getCustomInfo("frmPaymentConsent");
            let data = dataList[0];
            let warnings = dataList[0].messageDetails;
            this.view.flxErrorSingle.isVisible = false;
            this.view.flxErrorMultiple.isVisible = false;
            if (!kony.sdk.isNullOrUndefined(warnings)) {
                var str = warnings;
                dataObj = JSON.parse(str);
                if (dataObj.length === 1) {
                    this.view.flxErrorSingle.isVisible = true;
                    this.view.lblError.text = dataObj[0].message
                } else {
                    this.view.flxErrorMultiple.isVisible = true;
                    let segData = [];
                    segData = dataObj.map(data => {
                        return {
                            "lblErrorText": {
                                "text": data.message
                            },
                            "lblDot": {
                                "text": "Label"
                            }
                        };
                    });
                    let widgetDataMap = {
                        "flexWarningMessages": "flexWarningMessages",
                        "lblErrorText": "lblErrorText",
                        "lblDot": "lblDot"
                    };
                    this.view.SegError.widgetDataMap = widgetDataMap;
                    this.view.SegError.setData(segData);
                }
            }
            if (data) {
                if (data.isScheduled === "true") {
                    this.view.flxFutureDate.setVisibility(true);
                    this.view.flxMainContainer.top = "12dp";
                    this.view.lblFuturePaymentDate.text = kony.i18n.getLocalizedString("i18n.tppConsent.futureDatedPayment") + ":";
                    this.view.lblFutureDate.text = kony.i18n.getLocalizedString("i18n.tppConsent.paymentMadeOn") + " " + data.transactionDate;
                } else {
                    this.view.flxMainContainer.top = "24dp";
                    this.view.flxFutureDate.setVisibility(false);
                }
                let thirdPartyWebsiteName = applicationManager.deeplinkAppName;
                this.view.rtxAuthInformation.text = " <b> " + thirdPartyWebsiteName + "</b> "
                this.view.lblEnteredAmt.text = data.amount ? forUtility.formatAmountandAppendCurrencySymbol(data.amount, data.transactionCurrency) : "";
                this.view.lblTotalDebitValue.text = data.totalDebit ? forUtility.formatAmountandAppendCurrencySymbol(data.totalDebit, data.transactionCurrency) : "";
                this.view.lblAmtValue.text = data.amount ? forUtility.formatAmountandAppendCurrencySymbol(data.amount, data.transactionCurrency) : "";
                if (kony.sdk.isNullOrUndefined(data.transactionFee) || data.transactionFee === "") {
                    this.view.flx3.setVisibility(false);
                } else {
                    this.view.flx3.setVisibility(true);
                    this.view.lblTransFeeValue.text = data.transactionFee ? forUtility.formatAmountandAppendCurrencySymbol(data.transactionFee, data.transactionCurrency) : "";
                }
                if (kony.sdk.isNullOrUndefined(data.serviceFee) || data.serviceFee === "") {
                    this.view.flx4.setVisibility(false);
                } else {
                    this.view.flx4.setVisibility(true);
                    this.view.lblServiceFeeValue.text = data.serviceFee ? forUtility.formatAmountandAppendCurrencySymbol(data.serviceFee, data.transactionCurrency) : "";
                }
                if ((kony.sdk.isNullOrUndefined(data.transactionFee) || data.transactionFee === "") && (kony.sdk.isNullOrUndefined(data.serviceFee) || data.serviceFee === "")) {
                    this.view.flxFeesAndCharges.setVisibility(false);
                    this.view.flxFeeAndChargesSep.setVisibility(false);
                } else {
                    this.view.flxFeesAndCharges.setVisibility(true);
                    this.view.flxFeeAndChargesSep.setVisibility(true);
                }
                this.view.lblPayeeAccValue.text = data.creditAccountNumber;
                this.view.lblPaymentRefValue.text = data.paymentId;
                this.view.flx10.setVisibility(false);
                if (!kony.sdk.isNullOrUndefined(data.Accounts[0])) {
                    this.view.lblCustomerName.text = data.Accounts[0].accountName;
                    this.view.lblCustomerId.text = data.Accounts[0].IBAN;
                    this.view.lblAccType.text = data.Accounts[0].accountType;
                    this.view.lblAmount.text = data.Accounts[0].availableBalance ? forUtility.formatAmountandAppendCurrencySymbol(data.Accounts[0].availableBalance, data.Accounts[0].currencyCode) : "";
                    if (!kony.sdk.isNullOrUndefined(data.exchangeRate) && (!CommonUtilities.isEmptyString(data.exchangeRate))) {
                        let exchangeRate = forUtility.formatAmountandAppendCurrencySymbol(data.exchangeRate, data.Accounts[0].currencyCode);
                        this.view.lblExchangeRateValue.text = exchangeRate;
                        this.view.flx10.setVisibility(true);
                    }
                }
                if (!kony.sdk.isNullOrUndefined(data.frequency) && (!CommonUtilities.isEmptyString(data.frequency) || data.frequency !== psdMode.presentationController.tppConstants.ONCE)) {
                    this.view.flxFutureDate.setVisibility(false);
                    this.view.lblSinglePaymentInfo.setVisibility(false);
                    this.view.lblRecurringPaymentMsg1.setVisibility(true);
                    this.view.lblRecurringPaymentMsg2.setVisibility(true);
                    this.view.lblEveryMonth.setVisibility(true);
                    var frequency = !kony.sdk.isNullOrUndefined(data.frequency) ? data.frequency.toLowerCase() : "";
                    this.view.lblEveryMonth.text = kony.i18n.getLocalizedString("i18n.tppConsent.willbemade") + " " + frequency;
                    this.view.flx5.setVisibility(true);
                    this.view.lblFrequencyValue.text = data.frequency;
                    this.view.lblPaymentDate.text = kony.i18n.getLocalizedString("kony.i18n.verifyDetails.startDate");
                    this.view.lblPaymentDateValue.text = data.startDate;
                    this.view.lblCreditDate.text = kony.i18n.getLocalizedString("i18n.accountsweeps.endDateWithColon");
                    this.view.lblCreditDateValue.text = data.endDate;
                } else {
                    this.view.lblSinglePaymentInfo.setVisibility(true);
                    this.view.lblRecurringPaymentMsg1.setVisibility(false);
                    this.view.lblRecurringPaymentMsg2.setVisibility(false);
                    this.view.lblEveryMonth.setVisibility(false);
                    this.view.flx5.setVisibility(false);
                    this.view.lblPaymentDate.text = kony.i18n.getLocalizedString("i18n.payments.paymentDateWithColon");
                    this.view.lblPaymentDateValue.text = data.transactionDate;
                    this.view.lblCreditDate.text = kony.i18n.getLocalizedString("i18n.payments.creditValueDateWithColon");
                    this.view.lblCreditDateValue.text = data.creditValueDate;
                }
            }
        },
        onApprove: function() {
            var accountMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "OpenBankingUIModule",
                "appName": "OpenBankingMA"
            });
            accountMod.presentationController.approvePaymentConsent();
        },
        onReject: function() {
            this.toggleRejectPopup(false);
            var openBankingMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "OpenBankingUIModule",
                "appName": "OpenBankingMA"
            });
            openBankingMod.presentationController.denyPaymentConsent();
        },
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmConsentVerifyDetailsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmConsentVerifyDetails **/
    AS_Form_fc4c49027a9e4c35a46e8e34fb7a5891: function AS_Form_fc4c49027a9e4c35a46e8e34fb7a5891(eventobject) {
        var self = this;
        this.frmConsentVerifyDetailsInit();
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmConsentVerifyDetailsController", ["OpenBankingMA/OpenBankingUIModule/userfrmConsentVerifyDetailsController", "OpenBankingMA/OpenBankingUIModule/frmConsentVerifyDetailsControllerActions"], function() {
    var controller = require("OpenBankingMA/OpenBankingUIModule/userfrmConsentVerifyDetailsController");
    var controllerActions = ["OpenBankingMA/OpenBankingUIModule/frmConsentVerifyDetailsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
