define("AccountSweepsMA/AccountSweepsUIModule/frmAccountSweepAcknowledgement", function() {
    return function(controller) {
        function addWidgetsfrmAccountSweepAcknowledgement() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate66 = new com.InfinityOLB.Resources.formTemplate66({
                "height": "100%",
                "id": "formTemplate66",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate66",
                "overrides": {
                    "formTemplate66": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate66_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmAccountSweepAcknowledgement"] && appConfig.componentMetadata["ResourcesMA"]["frmAccountSweepAcknowledgement"]["formTemplate66"]) || {};
            formTemplate66.serviceParameters = formTemplate66_data.serviceParameters || {};
            formTemplate66.customPopupData = formTemplate66_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate66.backFlag = formTemplate66_data.backFlag || false;
            formTemplate66.genricMessage = formTemplate66_data.genricMessage || {};
            formTemplate66.primaryLinks = formTemplate66_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate66.dataFormatting = formTemplate66_data.dataFormatting || {};
            formTemplate66.backProperties = formTemplate66_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate66.secondaryLinks = formTemplate66_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate66.dataMapping = formTemplate66_data.dataMapping || {};
            formTemplate66.breadCrumbProperties = formTemplate66_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate66.supplementaryLinks = formTemplate66_data.supplementaryLinks || {};
            formTemplate66.conditionalMappingKey = formTemplate66_data.conditionalMappingKey || "";
            formTemplate66.logoConfig = formTemplate66_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate66.conditionalMapping = formTemplate66_data.conditionalMapping || {};
            formTemplate66.hamburgerConfig = formTemplate66_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate66.logoutConfig = formTemplate66_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate66.pageTitle = formTemplate66_data.pageTitle || "Create Sweep - Acknowledgement ";
            formTemplate66.profileConfig = formTemplate66_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate66.pageTitlei18n = formTemplate66_data.pageTitlei18n || "";
            formTemplate66.activeMenuID = formTemplate66_data.activeMenuID || "";
            formTemplate66.flxMainWrapperzIndex = formTemplate66_data.flxMainWrapperzIndex || 2;
            formTemplate66.activeSubMenuID = formTemplate66_data.activeSubMenuID || "";
            formTemplate66.pageTitleVisibility = formTemplate66_data.pageTitleVisibility || true;
            formTemplate66.accountText = formTemplate66_data.accountText || "";
            formTemplate66.sessionTimeOutData = formTemplate66_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate66.footerProperties = formTemplate66_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate66.copyRight = formTemplate66_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxLeftContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainer.setDefaultUnit(kony.flex.DP);
            var flxLeftHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLeftHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftHeader.setDefaultUnit(kony.flex.DP);
            var lblSectionHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblSectionHeader",
                "isVisible": true,
                "left": "2.20%",
                "skin": "ICSknLabelSSPBold42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Acknowledgement\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftHeader.add(lblSectionHeader);
            var flxLeftSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLeftSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftSeparator.setDefaultUnit(kony.flex.DP);
            flxLeftSeparator.add();
            var flxAckDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAckDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckDetails.setDefaultUnit(kony.flex.DP);
            var lblStatus = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblStatus",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular42424224px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.acknowledgementMsg\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSuccess = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "69dp",
                "id": "imgSuccess",
                "isVisible": true,
                "skin": "slImage",
                "src": "success_green.png",
                "top": "38px",
                "width": "69dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxReferenceNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxReferenceNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "21dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReferenceNumber.setDefaultUnit(kony.flex.DP);
            var lblReferenceNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl727272SSPRegular20px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.ReferenceNumber\")",
                "top": "0dp",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblReferenceNumberValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknsknSSPLight42424228px",
                "top": "0",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxReferenceNumber.add(lblReferenceNumber, lblReferenceNumberValue);
            flxAckDetails.add(lblStatus, imgSuccess, flxReferenceNumber);
            flxLeftContainer.add(flxLeftHeader, flxLeftSeparator, flxAckDetails);
            formTemplate66.flxContentTCLeft.add(flxLeftContainer);
            var flxRightContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblHeader",
                "isVisible": true,
                "left": "2%",
                "skin": "ICSknLabelSSPBold42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountSweeps.accountSweepDetails\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(lblHeader);
            var flxHeaderSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlxSeparator",
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeparator.add();
            var flxMainContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxConfirmDetail1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail1.setDefaultUnit(kony.flex.DP);
            var flxKey1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey1.setDefaultUnit(kony.flex.DP);
            var lblKey1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblKey1",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.primaryAccountWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey1.add(lblKey1);
            var flxValue1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue1.setDefaultUnit(kony.flex.DP);
            var lblValue1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValue1",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue1.add(lblValue1);
            flxConfirmDetail1.add(flxKey1, flxValue1);
            var flxConfirmDetail2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail2.setDefaultUnit(kony.flex.DP);
            var flxKey2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey2.setDefaultUnit(kony.flex.DP);
            var lblKey2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblKey2",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.secondaryAccountWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey2.add(lblKey2);
            var flxValue2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue2.setDefaultUnit(kony.flex.DP);
            var lblValue2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValue2",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue2.add(lblValue2);
            flxConfirmDetail2.add(flxKey2, flxValue2);
            var flxConfirmDetail3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail3.setDefaultUnit(kony.flex.DP);
            var flxKey3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey3.setDefaultUnit(kony.flex.DP);
            var lblKey3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblKey3",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.sweepConditionWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey3.add(lblKey3);
            var flxValue3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "32.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "60%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue3.setDefaultUnit(kony.flex.DP);
            var lblValue3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValue3",
                "isVisible": true,
                "left": "0",
                "skin": "bblblskn424242Bold",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxCondition = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxCondition",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "10dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBoth = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBoth",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoth.setDefaultUnit(kony.flex.DP);
            var flxConditionBelow = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionBelow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionBelow.setDefaultUnit(kony.flex.DP);
            var flxPoint = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8dp",
                "id": "flxPoint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxRoundedCorner727272Radius8px",
                "top": "7dp",
                "width": "8dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPoint.setDefaultUnit(kony.flex.DP);
            flxPoint.add();
            var rtxSweepCond = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxSweepCond",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "0dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionBelow.add(flxPoint, rtxSweepCond);
            var flxConditionAbove = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionAbove",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionAbove.setDefaultUnit(kony.flex.DP);
            var flxPointAbove = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8dp",
                "id": "flxPointAbove",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxRoundedCorner727272Radius8px",
                "top": "7dp",
                "width": "8dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPointAbove.setDefaultUnit(kony.flex.DP);
            flxPointAbove.add();
            var rtxSweepCondAbove = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxSweepCondAbove",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "0dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionAbove.add(flxPointAbove, rtxSweepCondAbove);
            flxBoth.add(flxConditionBelow, flxConditionAbove);
            flxValue3.add(lblValue3, rtxCondition, flxBoth);
            flxConfirmDetail3.add(flxKey3, flxValue3);
            var flxConfirmDetail4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail4.setDefaultUnit(kony.flex.DP);
            var flxKey4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey4.setDefaultUnit(kony.flex.DP);
            var lblKey4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblKey4",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.frequency\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey4.add(lblKey4);
            var flxValue4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue4.setDefaultUnit(kony.flex.DP);
            var lblValue4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValue4",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue4.add(lblValue4);
            flxConfirmDetail4.add(flxKey4, flxValue4);
            var flxConfirmDetail5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail5.setDefaultUnit(kony.flex.DP);
            var flxKey5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey5.setDefaultUnit(kony.flex.DP);
            var lblKey5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblKey5",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.startingFromWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey5.add(lblKey5);
            var flxValue5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue5.setDefaultUnit(kony.flex.DP);
            var lblValue5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValue5",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue5.add(lblValue5);
            flxConfirmDetail5.add(flxKey5, flxValue5);
            var flxConfirmDetail6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail6.setDefaultUnit(kony.flex.DP);
            var flxKey6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey6.setDefaultUnit(kony.flex.DP);
            var lblKey6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblKey6",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.endDateWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey6.add(lblKey6);
            var flxValue6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue6.setDefaultUnit(kony.flex.DP);
            var lblValue6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValue6",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue6.add(lblValue6);
            flxConfirmDetail6.add(flxKey6, flxValue6);
            var flxGap = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxGap",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGap.setDefaultUnit(kony.flex.DP);
            flxGap.add();
            flxMainContent.add(flxConfirmDetail1, flxConfirmDetail2, flxConfirmDetail3, flxConfirmDetail4, flxConfirmDetail5, flxConfirmDetail6, flxGap);
            flxMainContainer.add(flxHeader, flxHeaderSeparator, flxMainContent);
            flxRightContainer.add(flxMainContainer);
            var flxAcKButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcKButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcKButtons.setDefaultUnit(kony.flex.DP);
            var btnCreateRule = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "40dp",
                "id": "btnCreateRule",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.createAnotherRule\")",
                "top": "0",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFF4vs"
            });
            var btnViewRules = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnffffffBorder0273e31pxRadius2px",
                "height": "40dp",
                "id": "btnViewRules",
                "isVisible": true,
                "left": "0dp",
                "right": "20dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.viewExistingRules\")",
                "top": "0",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder0273e31pxRadius2px"
            });
            flxAcKButtons.add(btnCreateRule, btnViewRules);
            formTemplate66.flxContentTCRight.add(flxRightContainer, flxAcKButtons);
            var btnDownload = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Download account sweep details"
                },
                "focusSkin": "sknBtnFontType15px",
                "id": "btnDownload",
                "isVisible": true,
                "right": "31dp",
                "skin": "sknBtnFontType15px",
                "text": "D",
                "top": "-21dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnFontType15px"
            });
            var btnPrint = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Print account sweep details"
                },
                "focusSkin": "sknBtnFontType15px",
                "id": "btnPrint",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnFontType15px",
                "text": "p",
                "top": "-21dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnFontType15px"
            });
            formTemplate66.flxTCButtons.add(btnDownload, btnPrint);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate66": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft"]
                    },
                    "flxAckDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer"]
                    },
                    "lblStatus": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "flxReferenceNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "lblReferenceNumber": {
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "lblReferenceNumberValue": {
                        "skin": "sknlblUserName",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "flxConfirmDetail1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "flxConfirmDetail2": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey2": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxConfirmDetail3": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey3": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "rtxCondition": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxConfirmDetail4": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxConfirmDetail5": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey5": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxConfirmDetail6": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey6": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxAcKButtons": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight"]
                    },
                    "btnCreateRule": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxAcKButtons"]
                    },
                    "btnViewRules": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxAcKButtons"]
                    },
                    "btnDownload": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    },
                    "btnPrint": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    }
                },
                "1024": {
                    "flxLeftContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft"]
                    },
                    "flxAckDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer"]
                    },
                    "lblStatus": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknlblUserName",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "flxReferenceNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "lblReferenceNumber": {
                        "skin": "ICSknLbl727272SSPRegular20px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "lblReferenceNumberValue": {
                        "skin": "ICSknlbl424242SSP24px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "flxKey1": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxKey1"]
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "flxKey2": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2", "flxKey2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxKey3": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "lblKey3": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxKey3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "72%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "rtxCondition": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxKey4": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "lblKey4": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4", "flxKey4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxKey5": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "lblKey5": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5", "flxKey5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxKey6": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6", "flxKey6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxAcKButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight"]
                    },
                    "btnCreateRule": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxAcKButtons"]
                    },
                    "btnViewRules": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxAcKButtons"]
                    },
                    "btnDownload": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    },
                    "btnPrint": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    }
                },
                "1366": {
                    "formTemplate66": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft"]
                    },
                    "lblStatus": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "flxReferenceNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "lblReferenceNumber": {
                        "skin": "ICSknLbl727272SSPRegular20px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "lblReferenceNumberValue": {
                        "skin": "ICSknlbl424242SSP24px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxHeader"]
                    },
                    "flxKey1": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxKey1"]
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "flxKey2": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2", "flxKey2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "flxKey3": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "lblKey3": {
                        "padding": [0, 0, 2, 0],
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxKey3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "rtxCondition": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxKey4": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "lblKey4": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4", "flxKey4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "flxKey5": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "lblKey5": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5", "flxKey5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "flxKey6": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6", "flxKey6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "flxAcKButtons": {
                        "reverseLayoutDirection": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight"]
                    },
                    "btnDownload": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    },
                    "btnPrint": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    }
                },
                "1380": {
                    "formTemplate66": {
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft"]
                    },
                    "flxLeftHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer"]
                    },
                    "lblSectionHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxLeftHeader"]
                    },
                    "flxLeftSeparator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer"]
                    },
                    "flxAckDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer"]
                    },
                    "lblStatus": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "imgSuccess": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "flxReferenceNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails"]
                    },
                    "lblReferenceNumber": {
                        "skin": "ICSknLbl727272SSPRegular20px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "lblReferenceNumberValue": {
                        "skin": "ICSknlbl424242SSP24px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCLeft", "flxLeftContainer", "flxAckDetails", "flxReferenceNumber"]
                    },
                    "flxRightContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight"]
                    },
                    "flxMainContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer"]
                    },
                    "flxHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer"]
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxHeader"]
                    },
                    "flxHeaderSeparator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer"]
                    },
                    "flxMainContent": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer"]
                    },
                    "flxConfirmDetail1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey1": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "lblKey1": {
                        "i18n_text": "i18n.accountsweeps.primaryAccountWithColon",
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxKey1"]
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1"]
                    },
                    "lblValue1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail1", "flxValue1"]
                    },
                    "flxConfirmDetail2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey2": {
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "lblKey2": {
                        "i18n_text": "i18n.accountsweeps.secondaryAccountWithColon",
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2", "flxKey2"]
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2"]
                    },
                    "lblValue2": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail2", "flxValue2"]
                    },
                    "flxConfirmDetail3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey3": {
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "lblKey3": {
                        "i18n_text": "i18n.accountsweeps.sweepConditionWithColon",
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxKey3"]
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3"]
                    },
                    "lblValue3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "rtxCondition": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "flxBoth": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3"]
                    },
                    "flxConditionBelow": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth"]
                    },
                    "flxPoint": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "rtxSweepCond": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionBelow"]
                    },
                    "flxConditionAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth"]
                    },
                    "flxPointAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail3", "flxValue3", "flxBoth", "flxConditionAbove"]
                    },
                    "flxConfirmDetail4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey4": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "lblKey4": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4", "flxKey4"]
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4"]
                    },
                    "lblValue4": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail4", "flxValue4"]
                    },
                    "flxConfirmDetail5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey5": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "lblKey5": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5", "flxKey5"]
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5"]
                    },
                    "lblValue5": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail5", "flxValue5"]
                    },
                    "flxConfirmDetail6": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxKey6": {
                        "left": {
                            "type": "string",
                            "value": "3.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6", "flxKey6"]
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "34.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6"]
                    },
                    "lblValue6": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent", "flxConfirmDetail6", "flxValue6"]
                    },
                    "flxGap": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxRightContainer", "flxMainContainer", "flxMainContent"]
                    },
                    "flxAcKButtons": {
                        "reverseLayoutDirection": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight"]
                    },
                    "btnCreateRule": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxAcKButtons"]
                    },
                    "btnViewRules": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxContentTCRight", "flxAcKButtons"]
                    },
                    "btnDownload": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    },
                    "btnPrint": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate66", "flxTCButtons"]
                    }
                }
            }
            this.compInstData = {
                "formTemplate66": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate66);
        };
        return [{
            "addWidgets": addWidgetsfrmAccountSweepAcknowledgement,
            "enabledForIdleTimeout": true,
            "id": "frmAccountSweepAcknowledgement",
            "init": controller.AS_Form_abb679f2fee9455c8d9b16e6ee75c86e,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AccountSweepsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});