define("ArrangementsMA/ServiceRequestsUIModule/userfrmServiceRequestsController", ['FormControllerUtility', 'CommonUtilities'], function(FormControllerUtility, CommonUtilities) {
    var responsiveUtils = new ResponsiveUtils();
    return {
        init: function() {
            this.view.preShow = this.preShow;
            this.view.postShow = this.postShow;
            this.view.onBreakpointChange = this.onBreakpointChange;
            var data = {};
            this.view.viewRequests.setContext();
        },
        //Type your controller code here 
        preShow: function() {
            this.view.customheadernew.activateMenu("ACCOUNTS", "Service Requests");
            this.view.flxDowntimeWarning.setVisibility(false);
            // this.view.viewRequests.onError = this.onError();
            //  this.view.viewRequests.showErrorMessage = this.showErrorMessage();
            var scope = this;
            this.view.customheadernew.btnSkipNav.onClick = function() {
                scope.view.lblServiceHead.setActive(true);
            }
            this.view.CustomPopup.doLayout = CommonUtilities.centerPopupFlex;
            this.view.onKeyPress = this.onKeyPressCallBack;
            this.view.CustomPopup.onKeyPress = this.onKeyPressCallBack;
        },
        onKeyPressCallBack: function(eventObject, eventPayload) {
            if (eventPayload.keyCode === 27) {
                if (this.view.flxDialogs.isVisible) {
                    this.view.flxDialogs.isVisible = false;
                }
                this.view.customheadernew.onKeyPressCallBack(eventObject, eventPayload);
            }
        },
        postShow: function() {
            this.flxMainCalculateHeight();
            if (kony.i18n.getCurrentLocale() === "ar_AE") {
                if (kony.application.getCurrentBreakpoint() <= 640) {
                    this.view.viewRequests.setLayoutForMobileRTL();
                } else if (kony.application.getCurrentBreakpoint() <= 1024) {
                    this.view.viewRequests.setLayoutForTabletRTL();
                } else {
                    this.view.viewRequests.setLayoutForDesktopRTL();
                }
            }
            this.view.forceLayout();
        },
        onRequestSelection: function(account) {
            var navMan = applicationManager.getNavigationManager();
            navMan.setCustomInfo("frmRepaymentDayRequest", account);
            navMan.navigateTo({
                "appName": "ArrangementsMA",
                "friendlyName": "ServiceRequestsUIModule/frmRepaymentDayRequest"
            });
        },
        flxMainCalculateHeight: function() {
            let headerHeight = this.view.flxHeader.height;
            let footerHeight = this.view.flxFooter.height;
            this.view.flxMain.minHeight = kony.os.deviceInfo().screenHeight - headerHeight.substring(0, headerHeight.length - 2) - footerHeight.substring(0, footerHeight.length - 2) + "dp";
            applicationManager.getNavigationManager().applyUpdates(this);
        },
        updateFormUI: function(viewModel) {},
        onBreakpointChange: function(form, width) {
            responsiveUtils.onOrientationChange(this.onBreakpointChange);
            this.view.customheadernew.onBreakpointChangeComponent(width);
            this.view.customfooternew.onBreakpointChangeComponent(width);
            this.flxMainCalculateHeight();
        },
    };
});
define("ArrangementsMA/ServiceRequestsUIModule/frmServiceRequestsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmServiceRequests **/
    AS_Form_ec831d0047024b6891b28ea0e4830b85: function AS_Form_ec831d0047024b6891b28ea0e4830b85(eventobject) {
        var self = this;
        return self.init.call(this);
    },
    /** onTouchEnd defined for frmServiceRequests **/
    AS_Form_ecdb436b4aaf481f9fab7ba4ee759deb: function AS_Form_ecdb436b4aaf481f9fab7ba4ee759deb(eventobject, x, y) {
        var self = this;
        hidePopups();
    },
    /** postShow defined for frmServiceRequests **/
    AS_Form_i27852a29b2d4f97babce056eb1ef7a6: function AS_Form_i27852a29b2d4f97babce056eb1ef7a6(eventobject) {
        var self = this;
        return self.postShow.call(this);
    },
    /** preShow defined for frmServiceRequests **/
    AS_Form_jd7f539d12ad459fbc5f3e46d38c6959: function AS_Form_jd7f539d12ad459fbc5f3e46d38c6959(eventobject) {
        var self = this;
        return self.preShow.call(this);
    },
    /** showErrorMessage defined for viewRequests **/
    AS_UWI_b4d27738c04140cea11ae11ecf7e2d92: function AS_UWI_b4d27738c04140cea11ae11ecf7e2d92(error) {
        var self = this;
        this.view.flxDowntimeWarning.setVisibility(true);
        this.view.rtxDowntimeWarning.text = error;
        this.view.forceLayout();
    },
    /** onError defined for viewRequests **/
    AS_UWI_be3271a8fc56401c9440a74f6971022e: function AS_UWI_be3271a8fc56401c9440a74f6971022e(error) {
        var self = this;
        // add error
    }
});
define("ArrangementsMA/ServiceRequestsUIModule/frmServiceRequestsController", ["ArrangementsMA/ServiceRequestsUIModule/userfrmServiceRequestsController", "ArrangementsMA/ServiceRequestsUIModule/frmServiceRequestsControllerActions"], function() {
    var controller = require("ArrangementsMA/ServiceRequestsUIModule/userfrmServiceRequestsController");
    var controllerActions = ["ArrangementsMA/ServiceRequestsUIModule/frmServiceRequestsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
