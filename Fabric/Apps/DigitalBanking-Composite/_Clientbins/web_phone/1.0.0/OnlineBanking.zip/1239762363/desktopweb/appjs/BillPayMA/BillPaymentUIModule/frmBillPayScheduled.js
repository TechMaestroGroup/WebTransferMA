define("BillPayMA/BillPaymentUIModule/frmBillPayScheduled", function() {
    return function(controller) {
        function addWidgetsfrmBillPayScheduled() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblHeaderMobile": {
                        "text": "T"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPLightRich42424217Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.ThereisomeerrorintheserverWecouldnotcompleteyourrequestofaddingtheaccount\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContentHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblTransactions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblTransactions",
                "isVisible": true,
                "left": "6.07%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPay\")",
                "top": "25dp",
                "width": "88%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBypass = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": "3dp",
                "height": "30dp",
                "id": "btnBypass",
                "isVisible": true,
                "left": "300dp",
                "skin": "btnSkipNavigation",
                "text": "Skip to payment options",
                "width": "220dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgSearch",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "search_blue.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Search"
            });
            flxSearch.add(imgSearch);
            flxContentHeader.add(lblTransactions, btnBypass, flxSearch);
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxTabsChecking = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "tablist",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "50dp",
                "horizontalScrollIndicator": true,
                "id": "flxTabsChecking",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_HORIZONTAL,
                "skin": "slFbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 5
            }, {
                "paddingInPixel": false
            }, {});
            flxTabsChecking.setDefaultUnit(kony.flex.DP);
            var btnAllPayees = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": "false",
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnAllPayees",
                "isVisible": true,
                "left": "3.7%",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AllPayees\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnPayementDue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": "false",
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnPayementDue",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnScheduled = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": "true",
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnScheduled",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummarySelected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.scheduled\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummarySelectedHover"
            });
            var btnHistory = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": "false",
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnHistory",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.History\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnManagePayee = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": "false",
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "80%",
                "id": "btnManagePayee",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ManagePayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            flxTabsChecking.add(btnAllPayees, btnPayementDue, btnScheduled, btnHistory, btnManagePayee);
            var flxScheduledSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100dp",
                "id": "flxScheduledSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScheduledSearch.setDefaultUnit(kony.flex.DP);
            var flxtxtSearchandClearbtn = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtSearchandClearbtn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.70%",
                "isModalContainer": false,
                "right": "30.50%",
                "skin": "sknFlxffffffBorder3px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtSearchandClearbtn.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Search Text"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "btnConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "4%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            btnConfirm.setDefaultUnit(kony.flex.DP);
            var lblSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSearch",
                "isVisible": true,
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            btnConfirm.add(lblSearch);
            var txtSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "40dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billPay.SearchMessage\")",
                "secureTextEntry": false,
                "skin": "Copyskntxt0b2e1fe36dece41",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearBtn = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Clear text"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxClearBtn",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "width": "5%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClearBtn.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgCross",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon_1.png",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearBtn.add(imgCross);
            flxtxtSearchandClearbtn.add(btnConfirm, txtSearch, flxClearBtn);
            var flxFiltersList = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50%",
                "id": "flxFiltersList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "72%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "27%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersList.setDefaultUnit(kony.flex.DP);
            var flxFiltersWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFiltersWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder3px",
                "top": "0",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersWrapper.setDefaultUnit(kony.flex.DP);
            var flxtxtFilters = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtFilters.setDefaultUnit(kony.flex.DP);
            var txtFilters = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtFilters",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "secureTextEntry": false,
                "skin": "bbSknTbx455574SSP15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lbltxtFilters = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lbltxtFilters",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtxtFilters.add(txtFilters, lbltxtFilters);
            var flxLblType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLblType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblType.setDefaultUnit(kony.flex.DP);
            var lblType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "40dp",
                "id": "lblType",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "All Payees",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblType.add(lblType);
            var flxDropdownSchedule = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDropdownSchedule",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gbb52155891440a4971350aca54624c4,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdownSchedule.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "16dp",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "O",
                "top": "0",
                "width": "16dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdownSchedule.add(lblDropdown);
            flxFiltersWrapper.add(flxtxtFilters, flxLblType, flxDropdownSchedule);
            var lstBoxFilters = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "id": "lstBoxFilters",
                "isVisible": false,
                "left": "0",
                "masterData": [
                    ["lb1", "All Payees"],
                    ["lb2", "Business Payees"],
                    ["lb3", "Personal Payees"]
                ],
                "skin": "sknlbxaltoffffffB1R2",
                "top": "0",
                "width": "100%",
                "blur": {
                    "enabled": true,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var accountTypesBillPaySchedule = new com.InfinityOLB.BillPay.account.accountTypes({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "height": "170dp",
                "id": "accountTypesBillPaySchedule",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "BillPayMA",
                "overrides": {
                    "accountTypes": {
                        "height": "170dp",
                        "isVisible": false,
                        "zIndex": 100
                    },
                    "flxAccountTypesSegment": {
                        "zIndex": 100
                    },
                    "imgToolTip": {
                        "isVisible": true,
                        "src": "tool_tip.png"
                    },
                    "segAccountTypes": {
                        "zIndex": 5
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFiltersList.add(flxFiltersWrapper, lstBoxFilters, accountTypesBillPaySchedule);
            flxScheduledSearch.add(flxtxtSearchandClearbtn, flxFiltersList);
            var flxPayFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxPayFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayFrom.setDefaultUnit(kony.flex.DP);
            var lblPayFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblPayFrom",
                "isVisible": true,
                "left": "42dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Pay From: ",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lstbxPayFrom = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lstbxPayFrom",
                "isVisible": true,
                "left": "150dp",
                "masterData": [
                    ["lb1", "Personal Checking...1234"],
                    ["lb2", "Listbox Two"],
                    ["lb3", "Listbox Three"]
                ],
                "skin": "sknLbxSSP42424215PxBorder727272",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyflxHorizontalLine0d0817beac4d543 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "CopyflxHorizontalLine0d0817beac4d543",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxHorizontalLine0d0817beac4d543.setDefaultUnit(kony.flex.DP);
            CopyflxHorizontalLine0d0817beac4d543.add();
            flxPayFrom.add(lblPayFrom, lstbxPayFrom, CopyflxHorizontalLine0d0817beac4d543);
            var flxHorizontalLine = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine.add();
            var flxBillPayScheduled = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxBillPayScheduled",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayScheduled.setDefaultUnit(kony.flex.DP);
            var flxBillPayScheduledHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBillPayScheduledHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayScheduledHeader.setDefaultUnit(kony.flex.DP);
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "8%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var CopyimgDropdown0i3be8fc01a9f4b = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "7dp",
                "id": "CopyimgDropdown0i3be8fc01a9f4b",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "5dp",
                "skin": "slImage",
                "src": "arrow_down.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdown.add(CopyimgDropdown0i3be8fc01a9f4b);
            var flxWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWrapper.setDefaultUnit(kony.flex.DP);
            var flxScheduledDateWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxScheduledDateWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScheduledDateWrapper.setDefaultUnit(kony.flex.DP);
            var lblScheduledDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Scheduled Date"
                },
                "centerY": "50%",
                "id": "lblScheduledDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billpay.scheduledDate\")",
                "top": "5dp",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortDate = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortDate",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "7dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxScheduledDateWrapper.add(lblScheduledDate, imgSortDate);
            var flxScheduledPayeeWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxScheduledPayeeWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20%",
                "isModalContainer": false,
                "right": "385dp",
                "skin": "slFbox",
                "top": "0dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScheduledPayeeWrapper.setDefaultUnit(kony.flex.DP);
            var lblPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Payee"
                },
                "centerY": "50%",
                "id": "lblPayee",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Payee\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPayeeSort = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgPayeeSort",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "7dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxScheduledPayeeWrapper.add(lblPayee, imgPayeeSort);
            var flxBillAmountWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBillAmountWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "40%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "130dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillAmountWrapper.setDefaultUnit(kony.flex.DP);
            var lblBillAMount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Bill Amount"
                },
                "centerY": "50%",
                "id": "lblBillAMount",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billpay.lblbill\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgBillPaySort = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgBillPaySort",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "7dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBillAmountWrapper.add(lblBillAMount, imgBillPaySort);
            var flxScheduledAmountWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxScheduledAmountWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "100dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "155dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScheduledAmountWrapper.setDefaultUnit(kony.flex.DP);
            var lblScheduledAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Scheduled Amount"
                },
                "centerY": "50%",
                "id": "lblScheduledAmount",
                "isVisible": true,
                "left": "-1dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.scheduledAmount\")",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSchedledAmountSort = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSchedledAmountSort",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxScheduledAmountWrapper.add(lblScheduledAmount, imgSchedledAmountSort);
            var flxAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "92dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Actions"
                },
                "centerY": "50%",
                "id": "lblAmount",
                "isVisible": true,
                "left": "2dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmount.add(lblAmount);
            flxWrapper.add(flxScheduledDateWrapper, flxScheduledPayeeWrapper, flxBillAmountWrapper, flxScheduledAmountWrapper, flxAmount);
            flxBillPayScheduledHeader.add(flxDropdown, flxWrapper);
            flxBillPayScheduled.add(flxBillPayScheduledHeader);
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            var flxSegmentContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.setDefaultUnit(kony.flex.DP);
            var segmentBillpay = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "table"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotes": "",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumber": "",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }, {
                    "btnCancel": "CANCEL",
                    "btnCancelSeries": "Cancel Series",
                    "btnEbill": "VIEW E-BILL",
                    "btnEdit": "EDIT",
                    "lblBillDueAmount": "$900.00",
                    "lblBillDueAmountA": "",
                    "lblDate": "05/30/2017",
                    "lblDateA": "05/30/2017",
                    "lblDropdown": "O",
                    "lblFrequencyTitle": "",
                    "lblFrequencyValue": "2nd (of total 10)",
                    "lblFromIcon": "s",
                    "lblIcon": "r",
                    "lblIdentifier": "Last payment: $66.51 on 01/12/2017",
                    "lblNotesValue": "Lorem Ipsum Lorem Ipsum.Lorem Ipsum Lorem Ipsum",
                    "lblPaidAmount": "$900.00",
                    "lblPaidAmountA": "",
                    "lblPayeeName": "",
                    "lblPayeeNameA": "",
                    "lblRecurrenceNo": "",
                    "lblRecurrenceNoValue": "2nd (of total 10)",
                    "lblRefrenceNumberValue": "5534628647738",
                    "lblSentFrom": "",
                    "lblSentFromValue": "Checking Account...1233",
                    "lblSeparator": "",
                    "lblSeperatorone": ""
                }],
                "groupCells": false,
                "id": "segmentBillpay",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegfffff",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxBillPaymentScheduledSelected"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnCancel": "btnCancel",
                    "btnCancelSeries": "btnCancelSeries",
                    "btnEbill": "btnEbill",
                    "btnEdit": "btnEdit",
                    "flxAction": "flxAction",
                    "flxBillDueAmount": "flxBillDueAmount",
                    "flxBillPaymentScheduledSelected": "flxBillPaymentScheduledSelected",
                    "flxBottom": "flxBottom",
                    "flxCancelSeries": "flxCancelSeries",
                    "flxDate": "flxDate",
                    "flxDropdown": "flxDropdown",
                    "flxEdit": "flxEdit",
                    "flxFrequency": "flxFrequency",
                    "flxFromDetails": "flxFromDetails",
                    "flxFromIcon": "flxFromIcon",
                    "flxGroupParent1": "flxGroupParent1",
                    "flxGroupParent2": "flxGroupParent2",
                    "flxIdentifier": "flxIdentifier",
                    "flxMain": "flxMain",
                    "flxNotes": "flxNotes",
                    "flxPaidAmount": "flxPaidAmount",
                    "flxPayeeIcon": "flxPayeeIcon",
                    "flxPayeeName": "flxPayeeName",
                    "flxRecurrenceNumber": "flxRecurrenceNumber",
                    "flxRefrenceNumber": "flxRefrenceNumber",
                    "flxRow2": "flxRow2",
                    "flxSentFrom": "flxSentFrom",
                    "flxWrapper": "flxWrapper",
                    "flxleftBottom": "flxleftBottom",
                    "lblBillDueAmount": "lblBillDueAmount",
                    "lblBillDueAmountA": "lblBillDueAmountA",
                    "lblDate": "lblDate",
                    "lblDateA": "lblDateA",
                    "lblDropdown": "lblDropdown",
                    "lblFrequencyTitle": "lblFrequencyTitle",
                    "lblFrequencyValue": "lblFrequencyValue",
                    "lblFromIcon": "lblFromIcon",
                    "lblIcon": "lblIcon",
                    "lblIdentifier": "lblIdentifier",
                    "lblNotes": "lblNotes",
                    "lblNotesValue": "lblNotesValue",
                    "lblPaidAmount": "lblPaidAmount",
                    "lblPaidAmountA": "lblPaidAmountA",
                    "lblPayeeName": "lblPayeeName",
                    "lblPayeeNameA": "lblPayeeNameA",
                    "lblRecurrenceNo": "lblRecurrenceNo",
                    "lblRecurrenceNoValue": "lblRecurrenceNoValue",
                    "lblRefrenceNumber": "lblRefrenceNumber",
                    "lblRefrenceNumberValue": "lblRefrenceNumberValue",
                    "lblSentFrom": "lblSentFrom",
                    "lblSentFromValue": "lblSentFromValue",
                    "lblSeparator": "lblSeparator",
                    "lblSeperatorone": "lblSeperatorone"
                },
                "widgetSkin": "sknsegWatchlist",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.add(segmentBillpay);
            var flxNoPayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxNoPayment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPayment.setDefaultUnit(kony.flex.DP);
            var rtxNoPaymentMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxNoPaymentMessage",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.noPaymentScheduleMessage\")",
                "top": "41dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSchedulePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSchedulePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "12.70%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSchedulePayment.setDefaultUnit(kony.flex.DP);
            var lblScheduleAPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblScheduleAPayment",
                "isVisible": true,
                "skin": "sknSSP3343ABpx24",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ScheduleAPayment\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Schedule a Payment"
            });
            flxSchedulePayment.add(lblScheduleAPayment);
            var flxImginfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxImginfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImginfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Info"
            });
            flxImginfo.add(imgInfo);
            flxNoPayment.add(rtxNoPaymentMessage, flxSchedulePayment, flxImginfo);
            flxLeft.add(flxTabsChecking, flxScheduledSearch, flxPayFrom, flxHorizontalLine, flxBillPayScheduled, flxHorizontalLine2, flxSegmentContainer, flxNoPayment);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "6.04%",
                "skin": "slFbox",
                "top": "0px",
                "width": "28.40%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxTotalEbillAmountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxTotalEbillAmountDue",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalEbillAmountDue.setDefaultUnit(kony.flex.DP);
            var flxEbillAMountDueHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDueHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEbillAMountDueHeader.setDefaultUnit(kony.flex.DP);
            var lblTotalEbillAmountDue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblTotalEbillAmountDue",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknlLblSSPMedium42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalEbillAmountDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            flxEbillAMountDueHeader.add(lblTotalEbillAmountDue, flxSeperator);
            var flxEbillAMountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxEbillAMountDue.setDefaultUnit(kony.flex.DP);
            var lblBills = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblBills",
                "isVisible": true,
                "left": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.6ebills\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEbillAmountDueValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblEbillAmountDueValue",
                "isVisible": true,
                "right": "7.69%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "$443.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEbillAMountDue.add(lblBills, lblEbillAmountDueValue);
            flxTotalEbillAmountDue.add(flxEbillAMountDueHeader, flxEbillAMountDue);
            var flxAddPayeeMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddPayeeMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayeeMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var flxAddPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddPayee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayee.setDefaultUnit(kony.flex.DP);
            var lblAddPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAddPayee",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.addPayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            flxAddPayee.add(lblAddPayee, flxSeperator1);
            var flxMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var lblMakeOneTimePayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblMakeOneTimePayment",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.MAKEONETIMEPAYMENT\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMakeOneTimePayment.add(lblMakeOneTimePayment);
            flxAddPayeeMakeOneTimePayment.add(flxAddPayee, flxMakeOneTimePayment);
            flxRight.add(flxTotalEbillAmountDue, flxAddPayeeMakeOneTimePayment);
            flxMainContainer.add(flxLeft, flxRight);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "5px",
                "centerX": "50%",
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlbla0a0a013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.TermsAndConditions\")",
                "top": "5px",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.add(lblTermsAndConditions);
            flxContent.add(flxMainContainer, flxTermsAndConditions);
            flxMain.add(flxDowntimeWarning, flxContentHeader, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            var flxCancelPopup = new kony.ui.FlexScrollContainer({
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.AreyousuredoyouwanttocancelTransaction?\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(CustomPopupCancel);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": true,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxViewEbillPopup = new kony.ui.FlexScrollContainer({
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "id": "flxViewEbillPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbillPopup.setDefaultUnit(kony.flex.DP);
            var flxViewEbillContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxViewEbillContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "100dp",
                "width": "73%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTransactions1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTransactions1",
                "isVisible": true,
                "left": "3%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.EBill\")",
                "top": "19px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "54dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxImgCancel = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this pop-up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20px",
                "id": "flxImgCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "flxHoverSkinPointer",
                "top": "19dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgCancel.setDefaultUnit(kony.flex.DP);
            var imgCancel = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50.00%",
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancel",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "bbcloseicon_1.png",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxImgCancel.add(imgCancel);
            flxTitle.add(lblTransactions1, flxSeparator3, flxImgCancel);
            var flxBillDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDetails.setDefaultUnit(kony.flex.DP);
            var flxBillDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDate.setDefaultUnit(kony.flex.DP);
            var lblBillDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblBillDate",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillDate\")",
                "top": "5px",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon1",
                "isVisible": true,
                "left": "0px",
                "right": "20px",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPostDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPostDateValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "01/02/2107",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillDate.add(lblBillDate, lblColon1, lblPostDateValue);
            var flxBillAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBillAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillAmount.setDefaultUnit(kony.flex.DP);
            var lblAmountKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Bill Amount"
                },
                "id": "lblAmountKey",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillAmount\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcolon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblcolon2",
                "isVisible": true,
                "left": "2px",
                "skin": "ICSknsknSSPRegular727272op10015px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountValue",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "$20.00",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillAmount.add(lblAmountKey, lblcolon2, lblAmountValue);
            var flxMemo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMemo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMemo.setDefaultUnit(kony.flex.DP);
            var lblMemo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMemo",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelMemo\")",
                "top": "5dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblColon3",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMemoValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMemoValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "Max. 100 charcacters allowed",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxMemo.add(lblMemo, lblColon3, lblMemoValue);
            flxBillDetails.add(flxBillDate, flxBillAmount, flxMemo);
            var flxSeparator4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            var flxImg = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            var flxImageContainer1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "470dp",
                "id": "flxImageContainer1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "217dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer1.setDefaultUnit(kony.flex.DP);
            var imgEBill = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "391dp",
                "id": "imgEBill",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "billpay_ebill.png",
                "top": "25dp",
                "width": "398dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImageHolder = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": true,
                "id": "flxImageHolder",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "108dp",
                "width": "66dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageHolder.setDefaultUnit(kony.flex.DP);
            var flxZoom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Click to zoom"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxZoom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxZoom.setDefaultUnit(kony.flex.DP);
            var imgZoom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "60dp",
                "id": "imgZoom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "icon_zoom_frame.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Zoom"
            });
            flxZoom.add(imgZoom);
            var flxFlip = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "click to flip"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFlip",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFlip.setDefaultUnit(kony.flex.DP);
            var imgFlip = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "60dp",
                "id": "imgFlip",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "iconflip.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Flip"
            });
            flxFlip.add(imgFlip);
            var flxDownload = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Download details of this e-bill"
                },
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3dp",
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "50dp",
                "id": "imgDownload",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "download_blue.png",
                "top": "1dp",
                "width": "50dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Download"
            });
            var lblDownload = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblDownload",
                "isVisible": true,
                "left": "3%",
                "skin": "sknOlbFonts0273e335px",
                "text": "D",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 5, 5],
                "paddingInPixel": false
            }, {});
            flxDownload.add(imgDownload, lblDownload);
            flxImageHolder.add(flxZoom, flxFlip, flxDownload);
            flxImageContainer1.add(imgEBill, flxImageHolder);
            flxImg.add(flxImageContainer1);
            var flxSeparator5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "687dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator5.setDefaultUnit(kony.flex.DP);
            flxSeparator5.add();
            var lblEbillDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEbillDetails",
                "isVisible": true,
                "left": "3%",
                "skin": "sknSSPregular42424213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Ebills.Terms&Conditions\")",
                "top": "10dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 5, 5],
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.add(flxTitle, flxBillDetails, flxSeparator4, flxImg, flxSeparator5, lblEbillDetails);
            flxViewEbillPopup.add(flxViewEbillContainer);
            flxDialogs.add(flxLogout, flxCancelPopup, flxLoading, flxViewEbillPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1388,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "kony.mb.BillPay.BillPay",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTabsChecking": {
                        "skin": "sknscrollFlxffffffShadowdddcdcnoradius2vs",
                        "segmentProps": []
                    },
                    "btnAllPayees": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxScheduledSearch": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxHorizontalLine": {
                        "segmentProps": []
                    },
                    "flxBillPayScheduled": {
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "segmentProps": []
                    },
                    "flxSegmentContainer": {
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "segmentBillpay": {
                        "segmentProps": []
                    },
                    "flxNoPayment": {
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "rtxNoPaymentMessage": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel.lblPopupMessage": {
                        "segmentProps": []
                    },
                    "flxViewEbillPopup": {
                        "left": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "49.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "flxBillDate": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBillDate": {
                        "width": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "lblPostDateValue": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblAmountKey": {
                        "segmentProps": []
                    },
                    "lblAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblMemo": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblTransactions": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnBypass": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxScheduledSearch": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPaySchedule.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxViewEbillPopup": {
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "btnAllPayees": {
                        "segmentProps": []
                    },
                    "btnPayementDue": {
                        "segmentProps": []
                    },
                    "btnScheduled": {
                        "segmentProps": []
                    },
                    "btnHistory": {
                        "segmentProps": []
                    },
                    "btnManagePayee": {
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxScheduledSearch": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPaySchedule": {
                        "segmentProps": [],
                        "instanceId": "accountTypesBillPaySchedule"
                    },
                    "accountTypesBillPaySchedule.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxHorizontalLine": {
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxScheduledDateWrapper": {
                        "segmentProps": []
                    },
                    "flxBillAmountWrapper": {
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxViewEbillPopup": {
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgCancel": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxBillDetails": {
                        "segmentProps": []
                    },
                    "lblcolon2": {
                        "left": {
                            "type": "string",
                            "value": "5px"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "segmentProps": []
                    },
                    "lblDownload": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEbillDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "1388": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxScheduledSearch": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPaySchedule.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxViewEbillPopup": {
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.lblHeaderMobile": {
                    "text": "T"
                },
                "accountTypesBillPaySchedule": {
                    "height": "170dp",
                    "zIndex": 100
                },
                "accountTypesBillPaySchedule.flxAccountTypesSegment": {
                    "zIndex": 100
                },
                "accountTypesBillPaySchedule.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "accountTypesBillPaySchedule.segAccountTypes": {
                    "zIndex": 5
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmBillPayScheduled,
            "enabledForIdleTimeout": true,
            "id": "frmBillPayScheduled",
            "init": controller.AS_Form_gec72a3a939e468f85d4f97004d6de3f,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "My Bills",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1388],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});