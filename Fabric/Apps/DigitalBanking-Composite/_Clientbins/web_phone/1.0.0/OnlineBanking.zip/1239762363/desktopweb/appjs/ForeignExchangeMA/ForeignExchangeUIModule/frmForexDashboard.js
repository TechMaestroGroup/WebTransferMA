define("ForeignExchangeMA/ForeignExchangeUIModule/frmForexDashboard", function() {
    return function(controller) {
        function addWidgetsfrmForexDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSeperatorheader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorheader",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorheader.setDefaultUnit(kony.flex.DP);
            flxSeperatorheader.add();
            flxHeader.add(customheadernew, flxSeperatorheader);
            var flxFormContent = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100%",
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "120dp",
                "width": "100%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "83dp",
                "maxWidth": "1200dp",
                "isModalContainer": false,
                "right": "83dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxForexHeader = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxForexHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "83%",
                "zIndex": 1,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxForexHeader.setDefaultUnit(kony.flex.DP);
            var lblForexHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ForeignExchange.ExchangeRate\")"
                },
                "centerY": "50%",
                "id": "lblForexHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLabel42424224pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ForeignExchange.ExchangeRate\")",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxForexHeader.add(lblForexHeader);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "90%",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "83%",
                "zIndex": 1,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var foreignExchange = new com.InfinityOLB.ForeignExchangeMA.foreignExchange({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "foreignExchange",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ForeignExchangeMA",
                "viewType": "foreignExchange",
                "overrides": {
                    "foreignExchange": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var foreignExchange_data = (appConfig.componentMetadata && appConfig.componentMetadata["ForeignExchangeMA"] && appConfig.componentMetadata["ForeignExchangeMA"]["frmForexDashboard"] && appConfig.componentMetadata["ForeignExchangeMA"]["frmForexDashboard"]["foreignExchange"]) || {};
            var flxRatesContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "89%",
                "id": "flxRatesContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "90%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRatesContainer.setDefaultUnit(kony.flex.DP);
            var flxratesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80px",
                "id": "flxratesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknf8f8f8Radius14px",
                "top": "0dp",
                "width": "100%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxratesHeader.setDefaultUnit(kony.flex.DP);
            var flxLeftSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeftSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0",
                "width": "50%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftSection.setDefaultUnit(kony.flex.DP);
            var flxLeftHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30%",
                "id": "flxLeftHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "70%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftHeader.setDefaultUnit(kony.flex.DP);
            var lblleftHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblleftHeader",
                "isVisible": true,
                "left": "7%",
                "skin": "sknLabel42424224pxSemiBold",
                "text": "Currency",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftHeader.add(lblleftHeader);
            flxLeftSection.add(flxLeftHeader);
            var flxRightSection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRightSection",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0",
                "width": "50%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightSection.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "90%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var flxBuyHead = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30%",
                "id": "flxBuyHead",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBuyHead.setDefaultUnit(kony.flex.DP);
            var lblBuyHead = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblBuyHead",
                "isVisible": true,
                "left": "7%",
                "skin": "sknLabel42424224pxSemiBold",
                "text": "Buying",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBuyHead.add(lblBuyHead);
            var flxSellHead = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30%",
                "id": "flxSellHead",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSellHead.setDefaultUnit(kony.flex.DP);
            var lblSellHead = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSellHead",
                "isVisible": true,
                "skin": "sknLabel42424224pxSemiBold",
                "text": "Selling",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSellHead.add(lblSellHead);
            flxHeaderContainer.add(flxBuyHead, flxSellHead);
            flxRightSection.add(flxHeaderContainer);
            flxratesHeader.add(flxLeftSection, flxRightSection);
            var segRatesDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }, {
                    "imgCurrency": "imagedrag.png",
                    "lblBuyHead": "Buying",
                    "lblBuyRate": "Buying",
                    "lblCurrCode": "Selling",
                    "lblSellHead": "Selling",
                    "lblSellRate": "Selling",
                    "lblleftHeader": "Currency"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segRatesDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ForeignExchangeMA",
                    "friendlyName": "flxMainContainer"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "f1ab1500",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxBuyRate": "flxBuyRate",
                    "flxCurrCodeGroup": "flxCurrCodeGroup",
                    "flxImgContainer": "flxImgContainer",
                    "flxImgGroupContainer": "flxImgGroupContainer",
                    "flxLeftSection": "flxLeftSection",
                    "flxMain": "flxMain",
                    "flxMainContainer": "flxMainContainer",
                    "flxRightRowContainer": "flxRightRowContainer",
                    "flxRightSection": "flxRightSection",
                    "flxRowContainer": "flxRowContainer",
                    "flxSellRate": "flxSellRate",
                    "imgCurrency": "imgCurrency",
                    "lblBuyRate": "lblBuyRate",
                    "lblCurrCode": "lblCurrCode",
                    "lblSellRate": "lblSellRate"
                },
                "width": "100%",
                "appName": "ForeignExchangeMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRatesContainer.add(flxratesHeader, segRatesDetails);
            flxMainContainer.add(foreignExchange, flxRatesContainer);
            flxContent.add(flxDowntimeWarning, flxForexHeader, flxMainContainer);
            flxMain.add(flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45px",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-5%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ForeignExchangeMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.LogoutMsg\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxSeperatorheader": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxForexHeader": {
                        "segmentProps": []
                    },
                    "lblForexHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "foreignExchange": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxContent": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxForexHeader": {
                        "segmentProps": []
                    },
                    "lblForexHeader": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "foreignExchange": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxForexHeader": {
                        "segmentProps": []
                    },
                    "lblForexHeader": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "foreignExchange": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxForexHeader": {
                        "segmentProps": []
                    },
                    "lblForexHeader": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "foreignExchange": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "foreignExchange": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmForexDashboard,
            "enabledForIdleTimeout": true,
            "id": "frmForexDashboard",
            "init": controller.AS_Form_a09971ae49914bceb7ad9545cec39442,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_a6abd548364e49a19ba1cfaf299b7f60,
            "preShow": function(eventobject) {
                controller.AS_Form_da81c7208cbb471bbd8f7eefe0a1d2df(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.kony.exchangeRates.ExchangeRatesHeader\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ForeignExchangeMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});