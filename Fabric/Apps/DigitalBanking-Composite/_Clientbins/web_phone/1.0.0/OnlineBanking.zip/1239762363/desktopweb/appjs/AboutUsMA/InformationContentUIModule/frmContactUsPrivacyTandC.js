define("AboutUsMA/InformationContentUIModule/frmContactUsPrivacyTandC", function() {
    return function(controller) {
        function addWidgetsfrmContactUsPrivacyTandC() {
            this.setDefaultUnit(kony.flex.PERCENTAGE);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnSkip": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxLoginMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLoginMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "556dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-52dp",
                "width": "10%",
                "zIndex": 2000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginMobile.setDefaultUnit(kony.flex.DP);
            var lblLoginMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerY": "50%",
                "id": "lblLoginMobile",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblffffff15pxSSP",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                "width": "65%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoginMobile.add(lblLoginMobile);
            flxHeader.add(customheader, flxLoginMobile);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "CopysknBorderE0g0878f2d2c094a",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknRtx424242SSP17Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContentHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "67dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1220dp",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "bottom": "15dp",
                "height": "25dp",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContentHeader.add(lblContentHeader);
            var flxContactUs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30px",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContactUs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxTransparent",
                "top": "7dp",
                "width": "1220px",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContactUs.setDefaultUnit(kony.flex.DP);
            var contactUs = new com.InfinityOLB.AboutUs.contactUs({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "contactUs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "contactUs": {
                        "width": "100%"
                    },
                    "flxContactCustomerService": {
                        "left": "0dp"
                    },
                    "flxContactDetails": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "30px",
                        "top": "12dp"
                    },
                    "flxContactSeperator": {
                        "right": "45px"
                    },
                    "flxSeperator": {
                        "isVisible": false
                    },
                    "flxSeperatorWrapper": {
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "imgBank": {
                        "src": "corporate_office_img.png"
                    },
                    "lblContactCustomerService": {
                        "text": "Customer Service"
                    },
                    "lblCorporateOffice": {
                        "width": "100%"
                    },
                    "lblCustomerSupport": {
                        "text": "Customer Support",
                        "width": "100%"
                    },
                    "lblEmail": {
                        "centerX": "viz.val_cleared",
                        "top": "10dp",
                        "width": "100%"
                    },
                    "lblTollFree": {
                        "width": "100%"
                    },
                    "rtxContactCustomerServiceMsg": {
                        "text": "Our customer service is available to address your account and servicing needs for various products.",
                        "width": "100%"
                    },
                    "rtxCorporateOfficeAddress": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bankaddress\")"
                    },
                    "rtxCustomerSupportNumbers": {
                        "text": "1877-777-7684"
                    },
                    "rtxEmailId": {
                        "top": "0dp"
                    },
                    "segCustomerService": {
                        "data": [{
                            "Label0f353b0b69e104e": "||",
                            "Label0je457b0d8de34f": "Label",
                            "imgDot": "pageoffdot.png",
                            "lblEmailId": "Email:",
                            "lblHeading": "Credit Cards",
                            "rtxEmailId": "konybank.creditcards@kony.com",
                            "rtxPhoneNumber": "Phone: 0000-0021-0022"
                        }, {
                            "Label0f353b0b69e104e": "||",
                            "Label0je457b0d8de34f": "Label",
                            "imgDot": "pageoffdot.png",
                            "lblEmailId": "Email:",
                            "lblHeading": "Credit Cards",
                            "rtxEmailId": "konybank.creditcards@kony.com",
                            "rtxPhoneNumber": "Phone: 0000-0021-0022"
                        }, {
                            "Label0f353b0b69e104e": "||",
                            "Label0je457b0d8de34f": "Label",
                            "imgDot": "pageoffdot.png",
                            "lblEmailId": "Email:",
                            "lblHeading": "Credit Cards",
                            "rtxEmailId": "konybank.creditcards@kony.com",
                            "rtxPhoneNumber": "Phone: 0000-0021-0022"
                        }]
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxseparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "600px",
                "id": "flxseparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "58px",
                "width": "2px",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxseparator.setDefaultUnit(kony.flex.DP);
            flxseparator.add();
            var Copyflxseparator0b3e76cc35fb84d = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "2px",
                "id": "Copyflxseparator0b3e76cc35fb84d",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "656px",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            Copyflxseparator0b3e76cc35fb84d.setDefaultUnit(kony.flex.DP);
            Copyflxseparator0b3e76cc35fb84d.add();
            flxContactUs.add(contactUs, flxseparator, Copyflxseparator0b3e76cc35fb84d);
            var flxPrivacyPolicy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "52%",
                "clipBounds": false,
                "id": "flxPrivacyPolicy",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "1200px",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrivacyPolicy.setDefaultUnit(kony.flex.DP);
            var privacyPolicy = new com.InfinityOLB.AboutUs.privacyAndTAndC({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "privacyPolicy",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "flxBody": {
                        "left": "0%"
                    },
                    "flxHeader": {
                        "left": "0%"
                    },
                    "flxScrollDetails": {
                        "left": "0%"
                    },
                    "flxSpacing": {
                        "left": "0%"
                    },
                    "privacyAndTAndC": {
                        "isVisible": false,
                        "left": "0%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxContentPP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentPP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentPP.setDefaultUnit(kony.flex.DP);
            var flxHeaderPP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": 60,
                "id": "flxHeaderPP",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderPP.setDefaultUnit(kony.flex.DP);
            var lblHeadingPP = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": 1,
                "id": "lblHeadingPP",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblSSP42424215px",
                "text": "TERMS & CONDITIONS",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperatorPP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "1px",
                "clipBounds": true,
                "height": 1,
                "id": "flxSeperatorPP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorPP.setDefaultUnit(kony.flex.DP);
            flxSeperatorPP.add();
            flxHeaderPP.add(lblHeadingPP, flxSeperatorPP);
            var flxScrollDetailsPP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetailsPP",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetailsPP.setDefaultUnit(kony.flex.DP);
            var flxBodyPP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBodyPP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyPP.setDefaultUnit(kony.flex.DP);
            var brwBodyPC = new kony.ui.Browser({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "brwBodyPC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "657dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxBodyPP.add(brwBodyPC);
            var flxSpacingPP = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacingPP",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacingPP.setDefaultUnit(kony.flex.DP);
            flxSpacingPP.add();
            flxScrollDetailsPP.add(flxBodyPP, flxSpacingPP);
            flxContentPP.add(flxHeaderPP, flxScrollDetailsPP);
            flxPrivacyPolicy.add(privacyPolicy, flxContentPP);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30px",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "minHeight": "500dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0px",
                "width": "1200px",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var termsAndConditions = new com.InfinityOLB.AboutUs.privacyAndTAndC({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "termsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "flxBody": {
                        "left": "0%"
                    },
                    "flxHeader": {
                        "left": "0%"
                    },
                    "flxScrollDetails": {
                        "left": "0%"
                    },
                    "flxSpacing": {
                        "left": "0%"
                    },
                    "privacyAndTAndC": {
                        "isVisible": false,
                        "left": "0%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0px",
                "width": "100%",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxHeader2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60px",
                "id": "flxHeader2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader2.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblHeading",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblSSP42424215px",
                "text": "TERMS & CONDITIONS",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            flxHeader2.add(lblHeading, flxSeperator);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var flxBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "657dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxBody.add(brwBodyTnC);
            var flxSpacing = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(flxBody, flxSpacing);
            flxContent.add(flxHeader2, flxScrollDetails);
            flxTermsAndConditions.add(termsAndConditions, flxContent);
            flxMainContainer.add(flxDowntimeWarning, flxContentHeader, flxContactUs, flxPrivacyPolicy, flxTermsAndConditions);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.AboutUs.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "AboutUsMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE,
                        "zIndex": 1
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(CustomFooterMain);
            flxFormContent.add(flxMainContainer, flxFooter);
            var flxPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1200
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.3%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%"
                    },
                    "btnNo": {
                        "right": "41%"
                    },
                    "btnYes": {
                        "right": "5%"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfer.QuitTransfer\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"I18n.billPay.QuitTransactionMsg\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "width": "44.30%",
                        "zIndex": 1100
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmContactUsPrivacyTandC": {
                        "skin": "Copysknflxe0d22ee7ea723944",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.btnSkip": {
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblLoginMobile": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "tagName": "span"
                        },
                        "text": "Sign In",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "rtxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContactUs": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxContactCustomerService": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxContactDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "86%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "contactUs.flxImage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "contactUs.flxSeperatorWrapper": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "contactUs.lblHeading": {
                        "segmentProps": []
                    },
                    "contactUs.rtxContactCustomerServiceMsg": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.segCustomerService": {
                        "data": [{
                            "Label0f353b0b69e104e": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "Label0je457b0d8de34f": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "imgDot": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": ""
                            },
                            "lblEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "rtxEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "rtxPhoneNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            }
                        }],
                        "segmentProps": ["data"]
                    },
                    "flxPrivacyPolicy": {
                        "bottom": {
                            "type": "string",
                            "value": "30px"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentPP": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "skin": "sknFlxTransparent",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopupLogout"
                    }
                },
                "1024": {
                    "flxHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblLoginMobile": {
                        "accessibilityConfig": {},
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxContactCustomerService": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxContactDetails": {
                        "height": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxCustomerServiceSegment": {
                        "top": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxImage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "contactUs.lblContactCustomerService": {
                        "text": "Conact Customer Service",
                        "segmentProps": []
                    },
                    "contactUs.lblEmail": {
                        "segmentProps": []
                    },
                    "contactUs.rtxContactCustomerServiceMsg": {
                        "text": "Customer service is available to address your account and servicing needs for various products.",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.rtxCustomerSupportNumbers": {
                        "text": "1877-777-7684",
                        "segmentProps": []
                    },
                    "contactUs.segCustomerService": {
                        "data": [{
                            "Label0f353b0b69e104e": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "Label0je457b0d8de34f": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "imgDot": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": ""
                            },
                            "lblEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "rtxEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "rtxPhoneNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            }
                        }],
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": ["data"]
                    },
                    "flxPrivacyPolicy": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "679dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentPP": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "minHeight": {
                            "type": "string",
                            "value": "679dp"
                        },
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopupLogout"
                    }
                },
                "1366": {
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "88.48%"
                        },
                        "segmentProps": []
                    },
                    "contactUs": {
                        "segmentProps": [],
                        "instanceId": "contactUs"
                    },
                    "contactUs.flxContactDetails": {
                        "height": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxContactSeperator": {
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxSeperatorWrapper": {
                        "width": {
                            "type": "string",
                            "value": "53%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.lblContactCustomerService": {
                        "text": "Contact Customer Service",
                        "segmentProps": []
                    },
                    "contactUs.lblEmail": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "contactUs.lblHeading": {
                        "segmentProps": []
                    },
                    "contactUs.rtxContactCustomerServiceMsg": {
                        "text": "Customer service is available to address your account and servicing needs for various products.",
                        "segmentProps": []
                    },
                    "contactUs.rtxCustomerSupportNumbers": {
                        "text": "1877-777-7684",
                        "segmentProps": []
                    },
                    "contactUs.rtxEmailId": {
                        "segmentProps": []
                    },
                    "contactUs.segCustomerService": {
                        "data": [{
                            "Label0f353b0b69e104e": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "||"
                            },
                            "Label0je457b0d8de34f": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "imgDot": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pageoffdot.png"
                            },
                            "lblEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Email:"
                            },
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credit Cards"
                            },
                            "rtxEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "konybank.creditcards@kony.com"
                            },
                            "rtxPhoneNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Phone: 0000-0021-0022"
                            }
                        }, {
                            "Label0f353b0b69e104e": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "||"
                            },
                            "Label0je457b0d8de34f": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "imgDot": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pageoffdot.png"
                            },
                            "lblEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Email:"
                            },
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credit Cards"
                            },
                            "rtxEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "konybank.creditcards@kony.com"
                            },
                            "rtxPhoneNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Phone: 0000-0021-0022"
                            }
                        }, {
                            "Label0f353b0b69e104e": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "||"
                            },
                            "Label0je457b0d8de34f": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "imgDot": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pageoffdot.png"
                            },
                            "lblEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Email:"
                            },
                            "lblHeading": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Credit Cards"
                            },
                            "rtxEmailId": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "konybank.creditcards@kony.com"
                            },
                            "rtxPhoneNumber": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Phone: 0000-0021-0022"
                            }
                        }],
                        "segmentProps": ["data"]
                    },
                    "flxPrivacyPolicy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "591dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88.48%"
                        },
                        "segmentProps": []
                    },
                    "flxContentPP": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "591dp"
                        },
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "width": {
                            "type": "string",
                            "value": "88.40%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "centerY": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmContactUsPrivacyTandC": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.TnC",
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "text": "Terms & Conditions",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxTransparent",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "contactUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "contactUs"
                    },
                    "contactUs.flxContactCustomerService": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxContactDetails": {
                        "height": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxContactSeperator": {
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "contactUs.flxScrollDetails": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.flxSeperatorWrapper": {
                        "width": {
                            "type": "string",
                            "value": "53%"
                        },
                        "segmentProps": []
                    },
                    "contactUs.lblContactCustomerService": {
                        "text": "Contact Customer Service",
                        "segmentProps": []
                    },
                    "contactUs.lblEmail": {
                        "segmentProps": []
                    },
                    "contactUs.lblHeading": {
                        "text": "Contact Us",
                        "segmentProps": []
                    },
                    "contactUs.rtxContactCustomerServiceMsg": {
                        "text": "Customer service is available to address your account and servicing needs for various products.",
                        "segmentProps": []
                    },
                    "contactUs.rtxCustomerSupportNumbers": {
                        "text": "1877-777-7684",
                        "segmentProps": []
                    },
                    "contactUs.segCustomerService": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrivacyPolicy": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "591dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "privacyPolicy": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "privacyPolicy"
                    },
                    "flxContentPP": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": []
                    },
                    "flxSeperatorPP": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "870dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "591dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "skin": "sknFlxffffffShadowdddcdc3pxradius",
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "minHeight": {
                            "type": "string",
                            "value": "850dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "contactUs": {
                    "width": "100%"
                },
                "contactUs.flxContactCustomerService": {
                    "left": "0dp"
                },
                "contactUs.flxContactDetails": {
                    "bottom": "30px",
                    "top": "12dp"
                },
                "contactUs.flxContactSeperator": {
                    "right": "45px"
                },
                "contactUs.flxSeperatorWrapper": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "contactUs.imgBank": {
                    "src": "corporate_office_img.png"
                },
                "contactUs.lblContactCustomerService": {
                    "text": "Customer Service"
                },
                "contactUs.lblCorporateOffice": {
                    "width": "100%"
                },
                "contactUs.lblCustomerSupport": {
                    "text": "Customer Support",
                    "width": "100%"
                },
                "contactUs.lblEmail": {
                    "centerX": "",
                    "top": "10dp",
                    "width": "100%"
                },
                "contactUs.lblTollFree": {
                    "width": "100%"
                },
                "contactUs.rtxContactCustomerServiceMsg": {
                    "text": "Our customer service is available to address your account and servicing needs for various products.",
                    "width": "100%"
                },
                "contactUs.rtxCustomerSupportNumbers": {
                    "text": "1877-777-7684"
                },
                "contactUs.rtxEmailId": {
                    "top": "0dp"
                },
                "contactUs.segCustomerService": {
                    "data": [{
                        "Label0f353b0b69e104e": "||",
                        "Label0je457b0d8de34f": "Label",
                        "imgDot": "pageoffdot.png",
                        "lblEmailId": "Email:",
                        "lblHeading": "Credit Cards",
                        "rtxEmailId": "konybank.creditcards@kony.com",
                        "rtxPhoneNumber": "Phone: 0000-0021-0022"
                    }, {
                        "Label0f353b0b69e104e": "||",
                        "Label0je457b0d8de34f": "Label",
                        "imgDot": "pageoffdot.png",
                        "lblEmailId": "Email:",
                        "lblHeading": "Credit Cards",
                        "rtxEmailId": "konybank.creditcards@kony.com",
                        "rtxPhoneNumber": "Phone: 0000-0021-0022"
                    }, {
                        "Label0f353b0b69e104e": "||",
                        "Label0je457b0d8de34f": "Label",
                        "imgDot": "pageoffdot.png",
                        "lblEmailId": "Email:",
                        "lblHeading": "Credit Cards",
                        "rtxEmailId": "konybank.creditcards@kony.com",
                        "rtxPhoneNumber": "Phone: 0000-0021-0022"
                    }]
                },
                "privacyPolicy.flxBody": {
                    "left": "0%"
                },
                "privacyPolicy.flxHeader": {
                    "left": "0%"
                },
                "privacyPolicy.flxScrollDetails": {
                    "left": "0%"
                },
                "privacyPolicy.flxSpacing": {
                    "left": "0%"
                },
                "privacyPolicy": {
                    "left": "0%"
                },
                "termsAndConditions.flxBody": {
                    "left": "0%"
                },
                "termsAndConditions.flxHeader": {
                    "left": "0%"
                },
                "termsAndConditions.flxScrollDetails": {
                    "left": "0%"
                },
                "termsAndConditions.flxSpacing": {
                    "left": "0%"
                },
                "termsAndConditions": {
                    "left": "0%"
                },
                "CustomFooterMain": {
                    "centerX": "50%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "CustomFooterMain.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomFooterMain.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                },
                "CustomPopup": {
                    "centerX": "50%",
                    "centerY": "50%"
                },
                "CustomPopup.btnNo": {
                    "right": "41%"
                },
                "CustomPopup.btnYes": {
                    "right": "5%"
                },
                "CustomPopupLogout": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "width": "44.30%",
                    "zIndex": 1100
                }
            }
            this.add(flxHeader, flxFormContent, flxPopup, flxLoading, flxLogout);
        };
        return [{
            "addWidgets": addWidgetsfrmContactUsPrivacyTandC,
            "enabledForIdleTimeout": true,
            "id": "frmContactUsPrivacyTandC",
            "init": controller.AS_Form_bfee161e52bc4ec29b7d4c2bada7e891,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_d45ef6cec3f940f5a8116f4e21d2ca69,
            "postShow": controller.AS_Form_dd0a31c1c5b146dcae49951586c4151b,
            "preShow": function(eventobject) {
                controller.AS_Form_h25a0a7476d94d6386b82106f20b3af7(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AboutUsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_g3ed63b605504d3099f924681f621216,
            "retainScrollPosition": false
        }]
    }
});