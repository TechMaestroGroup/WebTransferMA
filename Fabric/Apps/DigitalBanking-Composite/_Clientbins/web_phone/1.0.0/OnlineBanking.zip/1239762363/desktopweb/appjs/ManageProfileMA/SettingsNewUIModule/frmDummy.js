define("ManageProfileMA/SettingsNewUIModule/frmDummy", function() {
    return function(controller) {
        function addWidgetsfrmDummy() {
            this.setDefaultUnit(kony.flex.DP);
            var btnLogin = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnLogin",
                "isVisible": true,
                "left": "90dp",
                "onClick": controller.AS_Button_a9e9d668e3a04579a6c5a0d1e47378bf,
                "skin": "defBtnNormal",
                "text": "Login",
                "top": "180dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(btnLogin);
        };
        return [{
            "addWidgets": addWidgetsfrmDummy,
            "enabledForIdleTimeout": false,
            "id": "frmDummy",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});