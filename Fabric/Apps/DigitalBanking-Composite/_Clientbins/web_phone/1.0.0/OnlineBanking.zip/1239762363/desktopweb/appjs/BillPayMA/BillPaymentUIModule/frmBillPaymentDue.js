define("BillPayMA/BillPaymentUIModule/frmBillPaymentDue", function() {
    return function(controller) {
        function addWidgetsfrmBillPaymentDue() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeaderMobile": {
                        "text": "T"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblTransactions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblTransactions",
                "isVisible": true,
                "left": "6.07%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPay\")",
                "top": "25dp",
                "width": "88%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSkipRight = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yValue": "Skip to bill pay options"
                },
                "height": "30dp",
                "id": "btnSkipRight",
                "isVisible": true,
                "left": "37%",
                "skin": "btnSkipNavigation",
                "text": "Skip to Payment Options",
                "top": "18dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgSearch",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "search_blue.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Search"
            });
            flxSearch.add(imgSearch);
            flxContentHeader.add(lblTransactions, btnSkipRight, flxSearch);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.ThereisomeerrorintheserverWecouldnotcompleteyourrequestofaddingtheaccount\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxTabsChecking = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "tablist",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "50dp",
                "horizontalScrollIndicator": true,
                "id": "flxTabsChecking",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_HORIZONTAL,
                "skin": "slFbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 5
            }, {
                "paddingInPixel": false
            }, {});
            flxTabsChecking.setDefaultUnit(kony.flex.DP);
            var btnAllPayees = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnAllPayees",
                "isVisible": true,
                "left": "3.7%",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AllPayees\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnPayementDue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": true,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnPayementDue",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummarySelected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummarySelectedHover"
            });
            var btnScheduled = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnScheduled",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.scheduled\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnHistory = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnHistory",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.History\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            var btnManagePayee = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-selected": false,
                        "role": "tab",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnManagePayee",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ManagePayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnAccountSummaryUnselectedHover"
            });
            flxTabsChecking.add(btnAllPayees, btnPayementDue, btnScheduled, btnHistory, btnManagePayee);
            var flxSearchandFilters = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxSearchandFilters",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "Copysknflxffffffnobor0c9e5c72af19e4d",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchandFilters.setDefaultUnit(kony.flex.DP);
            var flxtxtSearchandClearbtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtSearchandClearbtn",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.70%",
                "isModalContainer": false,
                "right": "30.50%",
                "skin": "sknFlxffffffBorder3px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtSearchandClearbtn.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "btnConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "4%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            btnConfirm.setDefaultUnit(kony.flex.DP);
            var lblSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Search "
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSearch",
                "isVisible": true,
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            btnConfirm.add(lblSearch);
            var txtSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Search using keywords such as Name, Bank, Account Type …"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "40dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billPay.SearchMessage\")",
                "secureTextEntry": false,
                "skin": "Copyskntxt0b2e1fe36dece41",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearBtn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxClearBtn",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "width": "5%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClearBtn.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Close"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgCross",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon_1.png",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearBtn.add(imgCross);
            flxtxtSearchandClearbtn.add(btnConfirm, txtSearch, flxClearBtn);
            var flxFiltersList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFiltersList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "72%",
                "isModalContainer": false,
                "right": "271px",
                "skin": "slFbox",
                "top": "30dp",
                "width": "200px",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersList.setDefaultUnit(kony.flex.DP);
            var flxFiltersWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFiltersWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder3px",
                "top": "0",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFiltersWrapper.setDefaultUnit(kony.flex.DP);
            var flxtxtFilters = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxtxtFilters",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxtxtFilters.setDefaultUnit(kony.flex.DP);
            var txtFilters = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "id": "txtFilters",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "secureTextEntry": false,
                "skin": "bbSknTbx455574SSP15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lbltxtFilters = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lbltxtFilters",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.View\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxtxtFilters.add(txtFilters, lbltxtFilters);
            var flxLblType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLblType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "55%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblType.setDefaultUnit(kony.flex.DP);
            var lblType = new kony.ui.Label({
                "height": "40dp",
                "id": "lblType",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AllPayees\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblType.add(lblType);
            var flxDropdownPaymentDue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDropdownPaymentDue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gbb52155891440a4971350aca54624c4,
                "skin": "slFbox",
                "top": "0",
                "width": "20%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdownPaymentDue.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "16dp",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "O",
                "top": "0",
                "width": "16dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdownPaymentDue.add(lblDropdown);
            flxFiltersWrapper.add(flxtxtFilters, flxLblType, flxDropdownPaymentDue);
            var lstBoxFilters = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "id": "lstBoxFilters",
                "isVisible": false,
                "left": "0",
                "masterData": [
                    ["lb1", "All Payees"],
                    ["lb2", "Business Payees"],
                    ["lb3", "Personal Payees"]
                ],
                "skin": "sknlbxaltoffffffB1R2",
                "top": "0",
                "width": "100%",
                "blur": {
                    "enabled": true,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var accountTypesBillPayPaymentDue = new com.InfinityOLB.BillPay.account.accountTypes({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "height": "170dp",
                "id": "accountTypesBillPayPaymentDue",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA",
                "overrides": {
                    "accountTypes": {
                        "height": "170dp",
                        "isVisible": false,
                        "zIndex": 5
                    },
                    "flxAccountTypesSegment": {
                        "zIndex": 5
                    },
                    "imgToolTip": {
                        "isVisible": false,
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFiltersList.add(flxFiltersWrapper, lstBoxFilters, accountTypesBillPayPaymentDue);
            flxSearchandFilters.add(flxtxtSearchandClearbtn, flxFiltersList);
            var flxPayFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxPayFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayFrom.setDefaultUnit(kony.flex.DP);
            var lblPayFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Pay From: "
                },
                "centerY": "50%",
                "id": "lblPayFrom",
                "isVisible": true,
                "left": "42dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Pay From: ",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lstbxPayFrom = new kony.ui.ListBox({
                "centerY": "50%",
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lstbxPayFrom",
                "isVisible": true,
                "left": "150dp",
                "masterData": [
                    ["lb1", "Personal Checking...1234"],
                    ["lb2", "Listbox Two"],
                    ["lb3", "Listbox Three"]
                ],
                "skin": "sknLbxSSP42424215PxBorder727272",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var CopyflxHorizontalLine0d0817beac4d543 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "CopyflxHorizontalLine0d0817beac4d543",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxHorizontalLine0d0817beac4d543.setDefaultUnit(kony.flex.DP);
            CopyflxHorizontalLine0d0817beac4d543.add();
            flxPayFrom.add(lblPayFrom, lstbxPayFrom, CopyflxHorizontalLine0d0817beac4d543);
            var flxHorizontalLine = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine.add();
            var flxBulkBillPayHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxBulkBillPayHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBulkBillPayHeader.setDefaultUnit(kony.flex.DP);
            var flxBillPayAllPayeesWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBillPayAllPayeesWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayAllPayeesWrapper.setDefaultUnit(kony.flex.DP);
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "8%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var imgDropdown = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "7dp",
                "id": "imgDropdown",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "5dp",
                "skin": "slImage",
                "src": "arrow_down.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdown.add(imgDropdown);
            var flxWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWrapper.setDefaultUnit(kony.flex.DP);
            var flxPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPayee",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayee.setDefaultUnit(kony.flex.DP);
            var flxPayeeWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPayeeWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeWrapper.setDefaultUnit(kony.flex.DP);
            var lblPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblPayee",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Payee\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortPayee = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortPayee",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "7dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Payee"
            });
            flxPayeeWrapper.add(lblPayee, imgSortPayee);
            flxPayee.add(flxPayeeWrapper);
            var flxDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "44%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var lblDueDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDueDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DueDate\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortDatee = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortDatee",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknImgPointer5vs",
                "src": "sortingfinal.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Due Date"
            });
            flxDate.add(lblDueDate, imgSortDatee);
            var flxBill = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBill",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "35%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "80dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBill.setDefaultUnit(kony.flex.DP);
            var lblBill = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblBill",
                "isVisible": true,
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Bill\")",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgBill = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgBill",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "19%",
                "skin": "slImage",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Bill"
            });
            flxBill.add(lblBill, imgBill);
            var flxAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAmount",
                "isVisible": true,
                "right": "25dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.amountlabel\")",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmount.add(lblAmount);
            flxWrapper.add(flxPayee, flxDate, flxBill, flxAmount);
            flxBillPayAllPayeesWrapper.add(flxDropdown, flxWrapper);
            flxBulkBillPayHeader.add(flxBillPayAllPayeesWrapper);
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            var flxSegmentContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.setDefaultUnit(kony.flex.DP);
            var segmentBillpay = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segmentBillpay",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegfffff",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxBillPaymentAllPayeesSelected"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "widgetSkin": "sknsegWatchlist",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.add(segmentBillpay);
            var flxNoPayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "441dp",
                "id": "flxNoPayment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPayment.setDefaultUnit(kony.flex.DP);
            var rtxNoPaymentMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxNoPaymentMessage",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.noPaymentDueMessage\")",
                "top": "41dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImginfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxImginfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImginfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Info"
            });
            flxImginfo.add(imgInfo);
            flxNoPayment.add(rtxNoPaymentMessage, flxImginfo);
            flxLeft.add(flxTabsChecking, flxSearchandFilters, flxPayFrom, flxHorizontalLine, flxBulkBillPayHeader, flxHorizontalLine2, flxSegmentContainer, flxNoPayment);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "6.04%",
                "skin": "slFbox",
                "top": "0px",
                "width": "28.40%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxTotalEbillAmountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxTotalEbillAmountDue",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalEbillAmountDue.setDefaultUnit(kony.flex.DP);
            var flxEbillAMountDueHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDueHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEbillAMountDueHeader.setDefaultUnit(kony.flex.DP);
            var lblTotalEbillAmountDue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblTotalEbillAmountDue",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknlLblSSPMedium42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalEbillAmountDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            flxEbillAMountDueHeader.add(lblTotalEbillAmountDue, flxSeperator);
            var flxEbillAMountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxEbillAMountDue.setDefaultUnit(kony.flex.DP);
            var lblBills = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblBills",
                "isVisible": true,
                "left": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.6ebills\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEbillAmountDueValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblEbillAmountDueValue",
                "isVisible": true,
                "right": "7.69%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "$443.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEbillAMountDue.add(lblBills, lblEbillAmountDueValue);
            flxTotalEbillAmountDue.add(flxEbillAMountDueHeader, flxEbillAMountDue);
            var flxAddPayeeMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddPayeeMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayeeMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var flxAddPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Add Payee"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddPayee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayee.setDefaultUnit(kony.flex.DP);
            var lblAddPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAddPayee",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.addPayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            flxAddPayee.add(lblAddPayee, flxSeperator3);
            var flxMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Make One-Time Payment"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var lblMakeOneTimePayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblMakeOneTimePayment",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.MAKEONETIMEPAYMENT\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMakeOneTimePayment.add(lblMakeOneTimePayment);
            flxAddPayeeMakeOneTimePayment.add(flxAddPayee, flxMakeOneTimePayment);
            flxRight.add(flxTotalEbillAmountDue, flxAddPayeeMakeOneTimePayment);
            flxMainContainer.add(flxLeft, flxRight);
            var flxConfirmButton = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxConfirmButton",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmButton.setDefaultUnit(kony.flex.DP);
            var btnBulkConfirm = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue"
                },
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnBulkConfirm",
                "isVisible": true,
                "left": "45%",
                "onClick": controller.AS_Button_h80efc8b19a54629a344df1982dcef41,
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "top": "0px",
                "width": "256dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxConfirmButton.add(btnBulkConfirm);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "5px",
                "centerX": "50%",
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlbla0a0a013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.TermsAndConditions\")",
                "top": "5px",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.add(lblTermsAndConditions);
            flxContent.add(flxMainContainer, flxConfirmButton, flxTermsAndConditions);
            flxMain.add(flxContentHeader, flxDowntimeWarning, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            var flxActivatePopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxActivatePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivatePopup.setDefaultUnit(kony.flex.DP);
            var flxActivate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "370dp",
                "id": "flxActivate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "280dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivate.setDefaultUnit(kony.flex.DP);
            var flxActivateHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxActivateHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffffBorder2px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivateHeader.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "30px",
                "id": "lblHeader",
                "isVisible": true,
                "left": "3.77%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPay\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close My bills "
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "10dp",
                "width": "30dp",
                "zIndex": 5,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCrossIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCrossIcon",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxCross.add(imgCrossIcon);
            flxActivateHeader.add(lblHeader, flxCross);
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0fcc85abdb4b348",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxMiddle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "85px",
                "id": "flxMiddle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddle.setDefaultUnit(kony.flex.DP);
            var lblBillerNameKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "30px",
                "id": "lblBillerNameKey",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.BillerName\")",
                "top": "10px",
                "width": "17%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBillerNameValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "30px",
                "id": "lblBillerNameValue",
                "isVisible": true,
                "left": "21%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AT&T Communication ",
                "top": "10px",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "30px",
                "id": "lblAccountNumberKey",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                "top": "45px",
                "width": "17%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "30px",
                "id": "lblAccountNumberValue",
                "isVisible": true,
                "left": "21%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "AC23658900200",
                "top": "45px",
                "width": "20.90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMiddle.add(lblBillerNameKey, lblBillerNameValue, lblAccountNumberKey, lblAccountNumberValue);
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "117dp",
                "id": "flxWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "0dp",
                "width": "101%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var imgWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "40dp",
                "id": "imgWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3.77%",
                "src": "error_yellow.png",
                "top": "15dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWarningWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarningWrapper.setDefaultUnit(kony.flex.DP);
            var lblWarningOne = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarningOne",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.YouareActivatingtheEBillfeatureforthisBiller\")",
                "top": 15,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarningTwo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarningTwo",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.NowonwardyourBillamountwillbeappearinginthelistautomatically\")",
                "top": 15,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarningThree = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarningThree",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.Doyouwanttocontinue\")",
                "top": 15,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarningWrapper.add(lblWarningOne, lblWarningTwo, lblWarningThree);
            flxWarning.add(imgWarning, flxWarningWrapper);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "110dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknMarketNewsCardComp",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnProceed = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Yes, Activate My Bills"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "50dp",
                "id": "btnProceed",
                "isVisible": true,
                "right": "30dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "258dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "No, Cancel my activation"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "50dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "308dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "top": "30dp",
                "width": "258dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSecondaryFocusSSP3343a815PxHover"
            });
            flxButtons.add(btnProceed, btnCancel);
            flxActivate.add(flxActivateHeader, flxSeparator, flxMiddle, flxWarning, flxButtons);
            flxActivatePopup.add(flxActivate);
            var flxCancelPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.Quit\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AddPayee.Areyousureyouwanttoundo\")",
                        "width": "70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CustomPopupCancel.btnNo.onClick = controller.AS_Button_b17949b25847420fbf0a9e03d2551f9b;
            CustomPopupCancel.btnYes.onClick = controller.AS_Button_c70ad7a3e9b541fc8f5971e10048497b;
            CustomPopupCancel.flxCross.onClick = controller.AS_FlexContainer_edcfcd798c304052943bfd7ef41d5309;
            flxCancelPopup.add(CustomPopupCancel);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxViewEbill = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxViewEbill",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbill.setDefaultUnit(kony.flex.DP);
            var flxViewEbillContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "768dp",
                "id": "flxViewEbillContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "100dp",
                "width": "73%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblTransactions1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblTransactions1",
                "isVisible": true,
                "left": "3%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.EBill\")",
                "top": "19px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "54dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxImgCancel = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel the view bill"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20px",
                "id": "flxImgCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "flxHoverSkinPointer",
                "top": "19dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgCancel.setDefaultUnit(kony.flex.DP);
            var imgCancel = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50.00%",
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancel",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxImgCancel.add(imgCancel);
            flxTitle.add(lblTransactions1, flxSeparator3, flxImgCancel);
            var flxBillDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDetails.setDefaultUnit(kony.flex.DP);
            var flxBillDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBillDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillDate.setDefaultUnit(kony.flex.DP);
            var lblBillDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblBillDate",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillDate\")",
                "top": "5px",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon1",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPostDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPostDateValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "01/02/2107",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillDate.add(lblBillDate, lblColon1, lblPostDateValue);
            var flxBillAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBillAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillAmount.setDefaultUnit(kony.flex.DP);
            var lblBillAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblBillAmount",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillAmount\")",
                "top": "5dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcolon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblcolon2",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "$20.00",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxBillAmount.add(lblBillAmount, lblcolon2, lblAmountValue);
            var flxMemo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMemo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMemo.setDefaultUnit(kony.flex.DP);
            var lblMemo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMemo",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSPRegular727272op8017px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelMemo\")",
                "top": "5dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon3",
                "isVisible": true,
                "left": "5px",
                "skin": "sknSSPRegular727272op8017px",
                "text": ":",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMemoValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMemoValue",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "Max. 100 charcacters allowed",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            flxMemo.add(lblMemo, lblColon3, lblMemoValue);
            flxBillDetails.add(flxBillDate, flxBillAmount, flxMemo);
            var flxSeparator4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "10dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            var flxImg = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            var flxImageContainer1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "470dp",
                "id": "flxImageContainer1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "217dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer1.setDefaultUnit(kony.flex.DP);
            var imgEBill = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "391dp",
                "id": "imgEBill",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "billpay_ebill.png",
                "top": "25dp",
                "width": "398dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImageHolder = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": true,
                "id": "flxImageHolder",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "108dp",
                "width": "66dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageHolder.setDefaultUnit(kony.flex.DP);
            var flxZoom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxZoom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxZoom.setDefaultUnit(kony.flex.DP);
            var imgZoom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "60dp",
                "id": "imgZoom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "icon_zoom_frame.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Zoom"
            });
            flxZoom.add(imgZoom);
            var flxFlip = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFlip",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFlip.setDefaultUnit(kony.flex.DP);
            var imgFlip = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "60dp",
                "id": "imgFlip",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "iconflip.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Flip"
            });
            flxFlip.add(imgFlip);
            var flxDownload = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDownload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "60dp",
                "id": "imgDownload",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "icon_download_frame.png",
                "top": "1dp",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Download"
            });
            flxDownload.add(imgDownload);
            flxImageHolder.add(flxZoom, flxFlip, flxDownload);
            flxImageContainer1.add(imgEBill, flxImageHolder);
            flxImg.add(flxImageContainer1);
            var flxSeparator5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "687dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator5.setDefaultUnit(kony.flex.DP);
            flxSeparator5.add();
            var lblEbillDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": " ",
                    "tagName": "span"
                },
                "id": "lblEbillDetails",
                "isVisible": true,
                "left": "3%",
                "skin": "sknSSPregular42424213Px",
                "text": " Lorem ipsum dolor sit amet, consectetur adipising elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo.Proin sodales pulvinar tempor. Cum sociis antoque penatibus et magnis dis parturient montes, Nam fermentum, nulla luctus pharetra vulputate, fellis tellus mollis orci, sed rhoncus sapien nunc eget. ",
                "top": "10dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 5, 5],
                "paddingInPixel": false
            }, {});
            flxViewEbillContainer.add(flxTitle, flxBillDetails, flxSeparator4, flxImg, flxSeparator5, lblEbillDetails);
            flxViewEbill.add(flxViewEbillContainer);
            flxDialogs.add(flxLogout, flxActivatePopup, flxCancelPopup, flxLoading, flxViewEbill);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1388,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "kony.mb.BillPay.BillPay",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnSkipRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTabsChecking": {
                        "skin": "sknscrollFlxffffffShadowdddcdcnoradius2vs",
                        "segmentProps": []
                    },
                    "btnAllPayees": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnScheduled": {
                        "segmentProps": []
                    },
                    "btnHistory": {
                        "segmentProps": []
                    },
                    "flxSearchandFilters": {
                        "isVisible": false,
                        "skin": "sknFlxf7f7f7Shadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "flxtxtSearchandClearbtn": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "txtSearch": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFiltersWrapper": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayPaymentDue": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountTypesBillPayPaymentDue.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBulkBillPayHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSegmentContainer": {
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "segmentBillpay": {
                        "data": [{
                            "btnActivateEbill": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "btnEbill": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "btnPayBill": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblBill": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblDueDate": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblIcon": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblPayee": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblSeparator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "BillPayMA",
                            "friendlyName": "flxBillPaymentAllPayeesMobileSelected"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "btnActivateEbill": "btnActivateEbill",
                            "btnEbill": "btnEbill",
                            "btnPayBill": "btnPayBill",
                            "flxBill": "flxBill",
                            "flxBillPayAllPayeesWrapper": "flxBillPayAllPayeesWrapper",
                            "flxBillPaymentAllPayeesMobileSelected": "flxBillPaymentAllPayeesMobileSelected",
                            "flxDate": "flxDate",
                            "flxIcon": "flxIcon",
                            "flxPayee": "flxPayee",
                            "flxPayeeWrapper": "flxPayeeWrapper",
                            "flxWrapper": "flxWrapper",
                            "lblBill": "lblBill",
                            "lblDueDate": "lblDueDate",
                            "lblIcon": "lblIcon",
                            "lblPayee": "lblPayee",
                            "lblSeparator": "lblSeparator"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "BillPayMA"
                    },
                    "flxNoPayment": {
                        "skin": "sknFlxffffffShadowdddcdcnoradius",
                        "segmentProps": []
                    },
                    "rtxNoPaymentMessage": {
                        "skin": "sknSSPLightRich42424217Px",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxConfirmButton": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnBulkConfirm": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxActivatePopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxActivate": {
                        "height": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxMiddle": {
                        "height": {
                            "type": "string",
                            "value": "120px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblBillerNameKey": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameValue": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "left": {
                            "type": "string",
                            "value": "3.77%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberKey": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberValue": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "left": {
                            "type": "string",
                            "value": "3.77%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "imgWarning": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxWarningWrapper": {
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "flxBillDate": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBillDate": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblBillAmount": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblMemo": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTransactions": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnSkipRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchandFilters": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayPaymentDue": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "accountTypesBillPayPaymentDue.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxConfirmButton": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnBulkConfirm": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomPopupLogout": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxActivatePopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxActivate": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "right": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameKey": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameValue": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberKey": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberValue": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "imgWarning": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnSkipRight": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchandFilters": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayPaymentDue.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDate": {
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmButton": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "58.20%"
                        },
                        "segmentProps": []
                    },
                    "btnBulkConfirm": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxActivatePopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxActivate": {
                        "height": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "right": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameKey": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblBillerNameValue": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberKey": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberValue": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "imgWarning": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgCancel": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxBillDetails": {
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEbillDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "1388": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchandFilters": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxFiltersList": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxtxtFilters": {
                        "segmentProps": []
                    },
                    "flxLblType": {
                        "width": {
                            "type": "string",
                            "value": "57.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypesBillPayPaymentDue.imgToolTip": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxActivatePopup": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivate": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "right": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "btnProceed": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewEbill": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewEbillContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "height": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": []
                    },
                    "flxImageContainer1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator5": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.lblHeaderMobile": {
                    "text": "T"
                },
                "accountTypesBillPayPaymentDue": {
                    "height": "170dp",
                    "zIndex": 5
                },
                "accountTypesBillPayPaymentDue.flxAccountTypesSegment": {
                    "zIndex": 5
                },
                "accountTypesBillPayPaymentDue.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "CustomPopupCancel": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopupCancel.imgCross": {
                    "height": "15dp"
                },
                "CustomPopupCancel.lblPopupMessage": {
                    "width": "70%"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmBillPaymentDue,
            "enabledForIdleTimeout": true,
            "id": "frmBillPaymentDue",
            "init": controller.AS_Form_h2d3c213e1cc41dca63c19c2ea77544e,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "My Bills",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1388],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});