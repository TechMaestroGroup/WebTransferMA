define("ArrangementsMA/MortgageServicesUIModule/frmChangeRepaymentAccount", function() {
    return function(controller) {
        function addWidgetsfrmChangeRepaymentAccount() {
            this.setDefaultUnit(kony.flex.DP);
            var formChangeRepaymentAccount = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formChangeRepaymentAccount",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formChangeRepaymentAccount",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formChangeRepaymentAccount_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmChangeRepaymentAccount"] && appConfig.componentMetadata["ResourcesMA"]["frmChangeRepaymentAccount"]["formChangeRepaymentAccount"]) || {};
            formChangeRepaymentAccount.serviceParameters = formChangeRepaymentAccount_data.serviceParameters || {};
            formChangeRepaymentAccount.customPopupData = formChangeRepaymentAccount_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formChangeRepaymentAccount.dataFormatting = formChangeRepaymentAccount_data.dataFormatting || {};
            formChangeRepaymentAccount.dataMapping = formChangeRepaymentAccount_data.dataMapping || {};
            formChangeRepaymentAccount.conditionalMappingKey = formChangeRepaymentAccount_data.conditionalMappingKey || "";
            formChangeRepaymentAccount.conditionalMapping = formChangeRepaymentAccount_data.conditionalMapping || {};
            formChangeRepaymentAccount.pageTitle = formChangeRepaymentAccount_data.pageTitle || "Change Repayment Account";
            formChangeRepaymentAccount.pageTitlei18n = formChangeRepaymentAccount_data.pageTitlei18n || "";
            formChangeRepaymentAccount.primaryLinks = formChangeRepaymentAccount_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formChangeRepaymentAccount.flxMainWrapperzIndex = formChangeRepaymentAccount_data.flxMainWrapperzIndex || 2;
            formChangeRepaymentAccount.secondaryLinks = formChangeRepaymentAccount_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formChangeRepaymentAccount.supplementaryLinks = formChangeRepaymentAccount_data.supplementaryLinks || {};
            formChangeRepaymentAccount.pageTitleVisibility = formChangeRepaymentAccount_data.pageTitleVisibility || true;
            formChangeRepaymentAccount.logoConfig = formChangeRepaymentAccount_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formChangeRepaymentAccount.accountText = formChangeRepaymentAccount_data.accountText || "";
            formChangeRepaymentAccount.logoutConfig = formChangeRepaymentAccount_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formChangeRepaymentAccount.profileConfig = formChangeRepaymentAccount_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formChangeRepaymentAccount.activeMenuID = formChangeRepaymentAccount_data.activeMenuID || "";
            formChangeRepaymentAccount.activeSubMenuID = formChangeRepaymentAccount_data.activeSubMenuID || "";
            formChangeRepaymentAccount.backFlag = formChangeRepaymentAccount_data.backFlag || false;
            formChangeRepaymentAccount.hamburgerConfig = formChangeRepaymentAccount_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formChangeRepaymentAccount.backProperties = formChangeRepaymentAccount_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formChangeRepaymentAccount.breadCrumbProperties = formChangeRepaymentAccount_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formChangeRepaymentAccount.genricMessage = formChangeRepaymentAccount_data.genricMessage || {};
            formChangeRepaymentAccount.sessionTimeOutData = formChangeRepaymentAccount_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formChangeRepaymentAccount.footerProperties = formChangeRepaymentAccount_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formChangeRepaymentAccount.copyRight = formChangeRepaymentAccount_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxContMain = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxContMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxShadow4645454Bg",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContMain.setDefaultUnit(kony.flex.DP);
            var flxRepaymentAccDetails = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxRepaymentAccDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentAccDetails.setDefaultUnit(kony.flex.DP);
            var lblRepaymentAccDetails = new kony.ui.Label({
                "id": "lblRepaymentAccDetails",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.NewRepaymentAccountDetails\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator = new kony.ui.Label({
                "id": "lblSeparator",
                "isVisible": true,
                "left": "30dp",
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "49dp",
                "width": "94%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRepaymentAccDetails.add(lblRepaymentAccDetails, lblSeparator);
            var flxAccountList = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxAccountList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountList.setDefaultUnit(kony.flex.DP);
            var lblAccHoldName = new kony.ui.Label({
                "id": "lblAccHoldName",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountHolderNameWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblAccNo = new kony.ui.Label({
                "id": "lblAccNo",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountNumberWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxMaskedAccNo = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxMaskedAccNo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": true,
                "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp",
                "isSensitiveText": false
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblReAccNo = new kony.ui.Label({
                "id": "lblReAccNo",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.ReEenterRepaymentAccountNumberWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxUnmaskedAccNo = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxUnmaskedAccNo",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblBICSWIFT = new kony.ui.Label({
                "id": "lblBICSWIFT",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.bicSwift\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxBICSWIFT = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxBICSWIFT",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblBankName = new kony.ui.Label({
                "id": "lblBankName",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payee.bankname\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxBankName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxBankName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "skin": "sknTbxBkGrndf6f6f6SSP42424215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblLookUp = new kony.ui.Label({
                "id": "lblLookUp",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLabelSSPRegular4981B015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unified.lookUp\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSuppDoc = new kony.ui.Label({
                "id": "lblSuppDoc",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.SupportingDocumentsOptional\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSuppDocInfoIcon = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgSuppDocInfoIcon",
                "isVisible": true,
                "left": "0",
                "src": "infogrey_1x.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSupportingDoc = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSupportingDoc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "304dp",
                "width": "560dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDoc.setDefaultUnit(kony.flex.DP);
            var flxAttachIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxAttachIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "top": "13dp",
                "width": "24dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAttachIcon.setDefaultUnit(kony.flex.DP);
            var lblAttachIcon = new kony.ui.Label({
                "height": "100%",
                "id": "lblAttachIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLblFontIcon",
                "text": "U",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAttachIcon.add(lblAttachIcon);
            var lblSeparatorLine = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "height": "38dp",
                "id": "lblSeparatorLine",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknSeparatore3e3e3",
                "top": "6dp",
                "width": "1dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAttachDoc = new kony.ui.Label({
                "id": "lblAttachDoc",
                "isVisible": true,
                "left": "55dp",
                "skin": "bbSknLblSSP4176A415Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AttachDocuments\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDoc.add(flxAttachIcon, lblSeparatorLine, lblAttachDoc);
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": "30dp",
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "15dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarning = new kony.ui.Label({
                "id": "lblWarning",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.AccountNumberMismatchMessage\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSuppDocInfo = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSuppDocInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowd464545",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.setDefaultUnit(kony.flex.DP);
            var lblAttachmentRules = new kony.ui.Label({
                "id": "lblAttachmentRules",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.attachmentRules\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblClose = new kony.ui.Label({
                "id": "lblClose",
                "isVisible": true,
                "right": "11dp",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "top": 15,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSuppDocInfo = new kony.ui.Label({
                "id": "lblSuppDocInfo",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FileAttachmentErrorMessage\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.add(lblAttachmentRules, lblClose, lblSuppDocInfo);
            flxAccountList.add(lblAccHoldName, tbxName, lblAccNo, tbxMaskedAccNo, lblReAccNo, tbxUnmaskedAccNo, lblBICSWIFT, tbxBICSWIFT, lblBankName, tbxBankName, lblLookUp, lblSuppDoc, imgSuppDocInfoIcon, flxSupportingDoc, lblSeparator1, lblWarning, flxSuppDocInfo);
            var flxCancelAndContinue = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "71dp",
                "id": "flxCancelAndContinue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelAndContinue.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "175dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                "top": "10dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnContinue = new kony.ui.Button({
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.CM.continue\")",
                "top": "10dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Continue"
            });
            flxCancelAndContinue.add(btnCancel, btnContinue);
            flxContMain.add(flxRepaymentAccDetails, flxAccountList, flxCancelAndContinue);
            formChangeRepaymentAccount.flxContentTCCenter.add(flxContMain);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formChangeRepaymentAccount": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "lblRepaymentAccDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "New Repayment Account Details",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "lblAccHoldName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Repayment Account Holder Name:",
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblAccNo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "92dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxMaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblReAccNo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Re-enter Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "172dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxUnmaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular13px",
                        "top": {
                            "type": "string",
                            "value": "195dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "BIC / SWIFT:",
                        "top": {
                            "type": "string",
                            "value": "252dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "275dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBankName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Bank Name:",
                        "top": {
                            "type": "string",
                            "value": "332dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBankName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknTbxBkGrndf6f6f6SSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "355dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblLookUp": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular4176A413px",
                        "text": "Look Up",
                        "top": {
                            "type": "string",
                            "value": "252dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblSuppDoc": {
                        "i18n_text": "i18n.accounts.SupportingDocumentsOptional",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Supporting Documents(Optional)",
                        "top": {
                            "type": "string",
                            "value": "414dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "imgSuppDocInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "202dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "413dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxSupportingDoc": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                        "top": {
                            "type": "string",
                            "value": "441dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxAttachIcon": {
                        "bottom": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "246dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc"]
                    },
                    "lblSeparatorLine": {
                        "bottom": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc"]
                    },
                    "lblSeparator1": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "571dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblWarning": {
                        "isVisible": false,
                        "text": "Account number does not match",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxSuppDocInfo": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblAttachmentRules": {
                        "text": "Attachement Rules",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSuppDocInfo"]
                    },
                    "flxCancelAndContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "571dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "btnCancel": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    },
                    "btnContinue": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    }
                },
                "1024": {
                    "flxContMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "sknFlxShadow4645454Bg",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter"]
                    },
                    "flxRepaymentAccDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "lblRepaymentAccDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "New Repayment Account Details",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "flxAccountList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "lblAccHoldName": {
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Repayment Account Holder Name:",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxName": {
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "placeholder": "",
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "660dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblAccNo": {
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxMaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblReAccNo": {
                        "left": {
                            "type": "string",
                            "value": "372dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Re-enter Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxUnmaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "372dp"
                        },
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "BIC / SWIFT",
                        "top": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBankName": {
                        "left": {
                            "type": "string",
                            "value": "372dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Bank Name:",
                        "top": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBankName": {
                        "left": {
                            "type": "string",
                            "value": "372dp"
                        },
                        "placeholder": "",
                        "skin": "sknTbxBkGrndf6f6f6SSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblLookUp": {
                        "left": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "skin": "ICSknLabelSSPRegular4981B015px",
                        "text": "Look Up",
                        "top": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblSuppDoc": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "Supporting Documents (Optional)",
                        "top": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "imgSuppDocInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "src": "infogrey_1x.png",
                        "top": {
                            "type": "string",
                            "value": "288dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxSupportingDoc": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "322dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "660dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblAttachIcon": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc", "flxAttachIcon"]
                    },
                    "lblSeparatorLine": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "642dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc"]
                    },
                    "lblSeparator1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "509dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "205"
                        },
                        "skin": "sknEE0005SSP13px",
                        "text": "Account number does not match",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxSuppDocInfo": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblClose": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSuppDocInfo"]
                    },
                    "lblSuppDocInfo": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSuppDocInfo"]
                    },
                    "flxCancelAndContinue": {
                        "height": {
                            "type": "string",
                            "value": "91dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "550dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "181dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "141dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    }
                },
                "1366": {
                    "formChangeRepaymentAccount": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxContMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxffffffShadowd464545",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter"]
                    },
                    "flxRepaymentAccDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "lblRepaymentAccDetails": {
                        "i18n_text": "i18n.mortgageAccount.NewRepaymentAccountDetails",
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "text": "New Repayment Account Details",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "flxAccountList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "number",
                            "value": "49"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "lblAccHoldName": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentAccountHolderNameWithColon",
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Repayment Account Holder Name:",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxName": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "placeholder": "",
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblAccNo": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentAccountNumberWithColon",
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxMaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblReAccNo": {
                        "i18n_text": "i18n.mortgageAccount.ReEenterRepaymentAccountNumberWithColon",
                        "left": {
                            "type": "string",
                            "value": "555dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Re-enter Repayment Account Number:",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxUnmaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "555dp"
                        },
                        "placeholder": "",
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBICSWIFT": {
                        "i18n_text": "kony.i18n.verifyDetails.bicSwift",
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "BIC / SWIFT",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "placeholder": "",
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBankName": {
                        "i18n_text": "i18n.payee.bankname",
                        "left": {
                            "type": "string",
                            "value": "555dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Bank Name:",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBankName": {
                        "left": {
                            "type": "string",
                            "value": "555dp"
                        },
                        "placeholder": "",
                        "skin": "sknTbxBkGrndf6f6f6SSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblLookUp": {
                        "i18n_text": "i18n.unified.lookUp",
                        "left": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "skin": "ICSknLabelSSPRegular4981B015px",
                        "text": "Look Up",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblSuppDoc": {
                        "i18n_text": "i18n.accounts.SupportingDocumentOptional",
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "Supporting Documents (Optional)",
                        "top": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "imgSuppDocInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "256dp"
                        },
                        "src": "info_grey.png",
                        "top": {
                            "type": "string",
                            "value": "283dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxSupportingDoc": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "317dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxAttachIcon": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc"]
                    },
                    "lblAttachIcon": {
                        "text": "U",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc", "flxAttachIcon"]
                    },
                    "lblAttachDoc": {
                        "i18n_text": "i18n.ProfileManagement.AttachDocuments",
                        "text": "Attach Documents",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc"]
                    },
                    "lblSeparator1": {
                        "top": {
                            "type": "string",
                            "value": "387dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblWarning": {
                        "i18n_text": "i18n.UnifiedTransfer.AccountNumberMismatchMessage",
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "240"
                        },
                        "skin": "sknlblee0005SSPReg15px",
                        "text": "Account number does not match.",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxSuppDocInfo": {
                        "height": {
                            "type": "string",
                            "value": "124dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxffffffShadowd464545",
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "zIndex": 10,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblAttachmentRules": {
                        "i18n_text": "i18n.UnifiedTransfer.attachmentRules",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Attachment Rules",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSuppDocInfo"]
                    },
                    "lblClose": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSuppDocInfo"]
                    },
                    "lblSuppDocInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "i18n_text": "i18n.accounts.FileAttachmentErrorMessage",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "A Maximum of 5 Attachments are allowed. Only PDF, JPEG format are allowed. The file size should not excedd 2MB.",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "268dp"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSuppDocInfo"]
                    },
                    "flxCancelAndContinue": {
                        "height": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "437dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "206dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "156dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    }
                },
                "1380": {
                    "flxContMain": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "sknFlxShadow4645454Bg",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter"]
                    },
                    "flxRepaymentAccDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "s1bb24340a974e98987aa24654a27407",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "lblRepaymentAccDetails": {
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "text": "New Repayment Account Details",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "Label",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxRepaymentAccDetails"]
                    },
                    "flxAccountList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "lblAccHoldName": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Account Holder Name",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxName": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "placeholder": "Daisy Davis",
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblAccNo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Account Number:",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxMaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "placeholder": "",
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblReAccNo": {
                        "left": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Re-enter Account Number:",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxUnmaskedAccNo": {
                        "left": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "placeholder": "9281 8900 8192 1211",
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "BIC / SWIFT",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBICSWIFT": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "placeholder": "MCRBRUMM000",
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblBankName": {
                        "left": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Bank Name:",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "tbxBankName": {
                        "left": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "placeholder": "Bank of Moscow",
                        "skin": "sknTbxBkGrndf6f6f6SSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblLookUp": {
                        "left": {
                            "type": "string",
                            "value": "537dp"
                        },
                        "skin": "ICSknLabelSSPRegular4981B015px",
                        "text": "Look Up",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "lblSuppDoc": {
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "skin": "ICSknlbl424242SSPSemiBold15px",
                        "text": "Supporting Documents (Optional)",
                        "top": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "imgSuppDocInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "256dp"
                        },
                        "src": "infogrey_1x.png",
                        "top": {
                            "type": "string",
                            "value": "282dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxSupportingDoc": {
                        "top": {
                            "type": "string",
                            "value": "317dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxAttachIcon": {
                        "bottom": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList", "flxSupportingDoc"]
                    },
                    "lblSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "387dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxAccountList"]
                    },
                    "flxCancelAndContinue": {
                        "height": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "437dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain"]
                    },
                    "btnCancel": {
                        "left": {
                            "type": "string",
                            "value": "844dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1014dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccount", "flxContentTCCenter", "flxContMain", "flxCancelAndContinue"]
                    }
                }
            }
            this.compInstData = {
                "formChangeRepaymentAccount": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formChangeRepaymentAccount);
        };
        return [{
            "addWidgets": addWidgetsfrmChangeRepaymentAccount,
            "enabledForIdleTimeout": true,
            "id": "frmChangeRepaymentAccount",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_ee7b45d859784751a3336001379097e5(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});