define(function() {
    return {
        "properties": [],
        "apis": ["isRememberMe"],
        "events": ["cantSignIn"]
    }
});